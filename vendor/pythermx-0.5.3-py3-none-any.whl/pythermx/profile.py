"""Explicit, versioned presentation profiles for PyThermX.

Profiles are an optional convenience for applications that want external
configuration.  Importing :mod:`pythermx` never searches for a profile and this
module deliberately imports the Tk adapter only inside :meth:`tk_style`.
Direct construction of the existing style dataclasses remains fully supported.
"""

from __future__ import annotations

import json
import math
import re
from copy import deepcopy
from dataclasses import dataclass, fields
from importlib.resources import files
from pathlib import Path
from typing import Any, Mapping

from .thermometer_cli import CLIThermometerStyle


PROFILE_SCHEMA_VERSION = "1.1"
SUPPORTED_PROFILE_SCHEMA_VERSIONS = frozenset({"1.0", PROFILE_SCHEMA_VERSION})
_SCHEMA_RESOURCES = {
    "1.0": "schemas/pythermx-profile-1.0.schema.json",
    "1.1": "schemas/pythermx-profile-1.1.schema.json",
}
_DEFAULT_PROFILE_RESOURCE = "profiles/default.json"


@dataclass(frozen=True)
class ProfileIssue:
    """One field-addressed profile validation result."""

    pointer: str
    message: str
    severity: str = "ERROR"
    rule_id: str = "profile.invalid"

    @property
    def blocks_use(self) -> bool:
        return self.severity in {"BLOCKER", "ERROR"}


@dataclass(frozen=True)
class ProfileMigrationReport:
    """Reviewable description of one explicit in-memory profile migration."""

    source_version: str
    target_version: str
    changes: tuple[str, ...]


class ProfileError(ValueError):
    """Base exception for explicit PyThermX profile operations."""


class UnsupportedProfileVersion(ProfileError):
    """The profile declares a schema version this release cannot interpret."""


class InvalidProfile(ProfileError):
    """Profile validation failed before style construction."""

    def __init__(self, issues: tuple[ProfileIssue, ...]) -> None:
        self.issues = issues
        detail = "; ".join(
            f"{issue.pointer or '/'}: {issue.message}"
            for issue in issues
            if issue.blocks_use
        )
        super().__init__(detail or "PyThermX profile is invalid")


@dataclass(frozen=True)
class PyThermXProfile:
    """Validated profile data with factories for the public style objects."""

    _document: dict[str, Any]
    issues: tuple[ProfileIssue, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        """Return a defensive copy suitable for review or serialization."""

        return deepcopy(self._document)

    def cli_style(self, **overrides: Any) -> CLIThermometerStyle:
        """Create a terminal style; explicit overrides have highest priority."""

        values = deepcopy(self._document["terminal"])
        values.update(overrides)
        spinner_frames = values.get("spinner_frames")
        if isinstance(spinner_frames, list):
            values["spinner_frames"] = tuple(spinner_frames)
        _reject_unknown(values, CLIThermometerStyle, "/terminal")
        return CLIThermometerStyle(**values)

    def tk_style(
        self,
        *,
        cancel: Mapping[str, Any] | Any | None = None,
        palette: Mapping[str, Any] | Any | None = None,
        **overrides: Any,
    ) -> Any:
        """Create a Tk style without importing Tkinter until explicitly called.

        ``cancel`` and ``palette`` may be their public dataclass objects or
        mappings whose values override the profile's nested sections.
        """

        from .tk import CancelControlStyle, Palette, TkThermometerStyle

        values = deepcopy(self._document["tkinter"])
        cancel_values = values.pop("cancel")
        palette_values = values.pop("palette")
        values.update(deepcopy(self._document.get("advanced", {})))
        values.update(overrides)
        _reject_unknown(values, TkThermometerStyle, "/tkinter")

        cancel_style = _nested_style(
            cancel_values,
            cancel,
            CancelControlStyle,
            "/tkinter/cancel",
        )
        palette_style = _nested_style(
            palette_values,
            palette,
            Palette,
            "/tkinter/palette",
        )
        return TkThermometerStyle(
            **values,
            cancel=cancel_style,
            palette=palette_style,
        )


def get_profile_schema(version: str = PROFILE_SCHEMA_VERSION) -> dict[str, Any]:
    """Load one supported packaged JSON Schema as a defensive dictionary."""

    try:
        resource_name = _SCHEMA_RESOURCES[version]
    except KeyError as exc:
        supported = ", ".join(sorted(SUPPORTED_PROFILE_SCHEMA_VERSIONS))
        raise UnsupportedProfileVersion(
            f"Unsupported schema version {version!r}; supported: {supported}."
        ) from exc
    resource = files("pythermx").joinpath(resource_name)
    return json.loads(resource.read_text(encoding="utf-8"))


def validate_profile(document: Mapping[str, Any] | Any) -> tuple[ProfileIssue, ...]:
    """Validate profile structure, types, constraints, and cross-field rules."""

    if not isinstance(document, Mapping):
        return (ProfileIssue("", "Profile root must be an object.", rule_id="schema.type"),)

    candidate = deepcopy(dict(document))
    declared_version = _pointer_get(candidate, "/profile_meta/schema_version")
    if declared_version not in SUPPORTED_PROFILE_SCHEMA_VERSIONS:
        supported = ", ".join(sorted(SUPPORTED_PROFILE_SCHEMA_VERSIONS))
        return (
            ProfileIssue(
                "/profile_meta/schema_version",
                f"Unsupported schema version {declared_version!r}; supported: {supported}.",
                severity="BLOCKER",
                rule_id="profile.schema_version",
            ),
        )

    issues: list[ProfileIssue] = []
    _validate_schema_node(get_profile_schema(declared_version), candidate, "", issues)

    width = _pointer_get(candidate, "/tkinter/width")
    minimum_width = _pointer_get(candidate, "/tkinter/minimum_width")
    if _is_integer(width) and _is_integer(minimum_width) and minimum_width > width:
        issues.append(
            ProfileIssue(
                "/tkinter/minimum_width",
                "Minimum width exceeds preferred width; PyThermX will expand the preferred width.",
                severity="WARNING",
                rule_id="profile.layout.minimum_width",
            )
        )
    return tuple(issues)


def profile_from_dict(document: Mapping[str, Any] | Any) -> PyThermXProfile:
    """Validate and copy an in-memory profile document."""

    issues = validate_profile(document)
    version_issue = next(
        (issue for issue in issues if issue.rule_id == "profile.schema_version"),
        None,
    )
    if version_issue is not None:
        raise UnsupportedProfileVersion(version_issue.message)
    blocking = tuple(issue for issue in issues if issue.blocks_use)
    if blocking:
        raise InvalidProfile(blocking)
    return PyThermXProfile(deepcopy(dict(document)), issues)


def migrate_profile(
    document: Mapping[str, Any] | Any,
    target_version: str = PROFILE_SCHEMA_VERSION,
) -> tuple[dict[str, Any], ProfileMigrationReport]:
    """Explicitly migrate a validated profile without rewriting its source.

    The only current transition is schema 1.0 to 1.1. The new motion setting
    is initialized to ``"animated"``, preserving schema 1.0 presentation.
    ``profile_version`` remains consumer-owned and is never changed here.
    """

    source = profile_from_dict(document).as_dict()
    source_version = source["profile_meta"]["schema_version"]
    if target_version not in SUPPORTED_PROFILE_SCHEMA_VERSIONS:
        supported = ", ".join(sorted(SUPPORTED_PROFILE_SCHEMA_VERSIONS))
        raise UnsupportedProfileVersion(
            f"Unsupported target schema version {target_version!r}; supported: {supported}."
        )
    if source_version == target_version:
        return source, ProfileMigrationReport(source_version, target_version, ())
    if (source_version, target_version) != ("1.0", "1.1"):
        raise ProfileError(
            f"No profile migration path from schema {source_version} to {target_version}."
        )

    migrated = deepcopy(source)
    migrated["profile_meta"]["schema_version"] = "1.1"
    migrated["tkinter"]["marquee_motion"] = "animated"
    profile_from_dict(migrated)
    return migrated, ProfileMigrationReport(
        source_version="1.0",
        target_version="1.1",
        changes=(
            "/profile_meta/schema_version: 1.0 -> 1.1",
            "/tkinter/marquee_motion: added 'animated'",
        ),
    )


def load_profile(path: str | Path) -> PyThermXProfile:
    """Explicitly load and validate one UTF-8 JSON profile."""

    profile_path = Path(path)
    try:
        document = json.loads(profile_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ProfileError(f"Cannot load PyThermX profile {profile_path}: {exc}") from exc
    return profile_from_dict(document)


def load_default_profile() -> PyThermXProfile:
    """Load the packaged example/default profile explicitly."""

    resource = files("pythermx").joinpath(_DEFAULT_PROFILE_RESOURCE)
    try:
        document = json.loads(resource.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:  # pragma: no cover - broken wheel
        raise ProfileError(f"Packaged PyThermX default profile is unreadable: {exc}") from exc
    return profile_from_dict(document)


def _validate_schema_node(
    schema: dict[str, Any],
    value: Any,
    pointer: str,
    issues: list[ProfileIssue],
) -> None:
    expected = schema.get("type")
    allowed = expected if isinstance(expected, list) else [expected] if expected else []
    if allowed and not any(_matches_type(value, item) for item in allowed):
        issues.append(
            ProfileIssue(
                pointer,
                f"Expected {expected!r}; received {type(value).__name__}.",
                rule_id="schema.type",
            )
        )
        return

    if "enum" in schema and value not in schema["enum"]:
        issues.append(
            ProfileIssue(
                pointer,
                f"Value must be one of {schema['enum']!r}.",
                rule_id="schema.enum",
            )
        )

    if isinstance(value, dict):
        properties = schema.get("properties", {})
        for required in schema.get("required", []):
            if required not in value:
                issues.append(
                    ProfileIssue(
                        f"{pointer}/{_escape(required)}",
                        "Required field is missing.",
                        rule_id="schema.required",
                    )
                )
        if schema.get("additionalProperties") is False:
            for unknown in value.keys() - properties.keys():
                issues.append(
                    ProfileIssue(
                        f"{pointer}/{_escape(unknown)}",
                        "Field is not supported by this profile schema.",
                        rule_id="schema.additionalProperties",
                    )
                )
        for key, child in value.items():
            child_schema = properties.get(key)
            if child_schema is not None:
                _validate_schema_node(
                    child_schema,
                    child,
                    f"{pointer}/{_escape(key)}",
                    issues,
                )
        return

    if isinstance(value, list):
        minimum_items = schema.get("minItems")
        if minimum_items is not None and len(value) < minimum_items:
            issues.append(
                ProfileIssue(
                    pointer,
                    f"At least {minimum_items} item(s) are required.",
                    rule_id="schema.minItems",
                )
            )
        item_schema = schema.get("items")
        if item_schema:
            for index, item in enumerate(value):
                _validate_schema_node(item_schema, item, f"{pointer}/{index}", issues)
        return

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if not math.isfinite(float(value)):
            issues.append(ProfileIssue(pointer, "Value must be finite.", rule_id="schema.finite"))
            return
        minimum = schema.get("minimum")
        maximum = schema.get("maximum")
        if minimum is not None and value < minimum:
            issues.append(
                ProfileIssue(pointer, f"Value must be at least {minimum}.", rule_id="schema.minimum")
            )
        if maximum is not None and value > maximum:
            issues.append(
                ProfileIssue(pointer, f"Value must be at most {maximum}.", rule_id="schema.maximum")
            )

    if isinstance(value, str):
        minimum_length = schema.get("minLength")
        maximum_length = schema.get("maxLength")
        if minimum_length is not None and len(value) < minimum_length:
            issues.append(
                ProfileIssue(
                    pointer,
                    f"Value must contain at least {minimum_length} character(s).",
                    rule_id="schema.minLength",
                )
            )
        if maximum_length is not None and len(value) > maximum_length:
            issues.append(
                ProfileIssue(
                    pointer,
                    f"Value must contain at most {maximum_length} character(s).",
                    rule_id="schema.maxLength",
                )
            )
        pattern = schema.get("pattern")
        if pattern and re.search(pattern, value) is None:
            issues.append(ProfileIssue(pointer, "Value has an invalid format.", rule_id="schema.pattern"))
        if schema.get("x-ui-kind") == "color" and re.fullmatch(r"#[0-9A-Fa-f]{6}", value) is None:
            issues.append(
                ProfileIssue(pointer, "Use a six-digit color such as #2979FF.", rule_id="schema.color")
            )


def _matches_type(value: Any, expected: str) -> bool:
    if expected == "null":
        return value is None
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "integer":
        return _is_integer(value)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "string":
        return isinstance(value, str)
    if expected == "array":
        return isinstance(value, list)
    if expected == "object":
        return isinstance(value, dict)
    return True


def _nested_style(
    profile_values: dict[str, Any],
    explicit: Mapping[str, Any] | Any | None,
    target: type,
    pointer: str,
) -> Any:
    if explicit is not None and isinstance(explicit, target):
        return explicit
    values = deepcopy(profile_values)
    if explicit is not None:
        if not isinstance(explicit, Mapping):
            raise TypeError(f"{pointer} override must be a mapping or {target.__name__}")
        values.update(explicit)
    _reject_unknown(values, target, pointer)
    return target(**values)


def _reject_unknown(values: Mapping[str, Any], target: type, pointer: str) -> None:
    allowed = {item.name for item in fields(target)}
    unknown = set(values) - allowed
    if unknown:
        raise TypeError(f"Unsupported field(s) at {pointer}: {sorted(unknown)}")


def _pointer_get(document: Mapping[str, Any], pointer: str) -> Any:
    current: Any = document
    try:
        for segment in pointer.strip("/").split("/"):
            current = current[segment]
    except (KeyError, TypeError):
        return None
    return current


def _escape(segment: str) -> str:
    return segment.replace("~", "~0").replace("/", "~1")


def _is_integer(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


__all__ = [
    "PROFILE_SCHEMA_VERSION",
    "SUPPORTED_PROFILE_SCHEMA_VERSIONS",
    "InvalidProfile",
    "ProfileError",
    "ProfileIssue",
    "ProfileMigrationReport",
    "PyThermXProfile",
    "UnsupportedProfileVersion",
    "get_profile_schema",
    "load_default_profile",
    "load_profile",
    "migrate_profile",
    "profile_from_dict",
    "validate_profile",
]
