"""Cooperative cancellation for PyThermX.

PyThermX observes work; it does not own it. The caller owns the loop, the
socket, the subprocess. So this module cannot stop anything, and nothing in it
tries to: **PyThermX never forcefully aborts, terminates or kills a worker.**
What it supplies is the shape of a cooperative protocol - a signal a UI raises
and a worker polls - and honest telemetry for the interval in between.

Deliberately outside :mod:`pythermx.thermometer_core`. The core is a
deterministic measurement accumulator, documented as not thread-safe and frozen
by blob hash; a cancellation token is not a measurement, and putting a
synchronisation primitive inside a class whose contract says "caller
synchronised" would contradict the contract to save one argument at a call site.

Two parties, one direction each
-------------------------------

The split is the point of this module, so it is enforced rather than documented:

* :class:`CancellationSource` is held by the UI or application. It may
  **request**. It cannot acknowledge, and it cannot declare the unwind finished.
* :class:`CancellationToken` is held by the worker. It may **acknowledge** the
  request and **complete** the unwind. It cannot request its own cancellation.

Neither side can forge the other's half. A UI cannot claim a worker has finished
cleaning up, and a worker cannot cancel itself on the user's behalf and report
it as the user's decision.

Three observable states, because two would lie
----------------------------------------------

``requested`` is not ``cancelled``. The gap between them is unbounded - a worker
blocked on a thirty-second read will not poll until it returns - and a UI that
reports ``cancelled`` on the click reports a state the system has not reached.
That is the same defect as rendering ``percent = 0`` for work whose total is
unknown, and it is rejected for the same reason.

===============  ========================================================
``active``       no cancellation has been requested
``requested``    the request is raised; the worker has not yet seen it
``cancelling``   the worker saw it and is unwinding - duration unknown
``cancelled``    the unwind finished
===============  ========================================================

Progress through those states is monotonic. There is no un-cancel and no reset:
un-cancelling is a race by construction, since a worker that polled before the
reset and one that polled after disagree about the same instant. A new task
takes a new source.
"""

from __future__ import annotations

import math
import threading
from dataclasses import dataclass
from enum import Enum
from typing import Optional

__all__ = [
    "CancellationRequested",
    "CancellationSource",
    "CancellationState",
    "CancellationStateError",
    "CancellationStatus",
    "CancellationToken",
    "TerminalOutcome",
]


def _validated_timeout(value: object) -> Optional[float]:
    """Strict timeout validation for :meth:`CancellationToken.wait`.

    Deliberately **not** ``thermometer_core._finite()``. That helper opens with
    ``float(value)``, which cheerfully converts ``True`` to ``1.0`` and
    ``"2.5"`` to ``2.5`` - exactly the two things this contract rejects. Sharing
    it would have re-imported the bug it was meant to prevent, so the check is
    local and type-strict, and the type test precedes any coercion.

    The finiteness half exists because this module previously repeated
    THERM-DEFECT-001: the guard was ``float(timeout)`` then ``if timeout < 0``,
    and **every comparison against NaN is False**, so ``wait(nan)`` sailed
    through and returned instantly - a worker that asked to block did not block.
    """
    if value is None:
        return None
    # Before the int/float test, because bool *is* an int subclass. Without
    # this, wait(True) is silently a one-second timeout.
    if isinstance(value, bool):
        raise TypeError(
            f"timeout must be a real number or None, got bool {value!r}"
        )
    if not isinstance(value, (int, float)):
        raise TypeError(
            f"timeout must be a real number or None, got "
            f"{type(value).__name__} {value!r}"
        )
    if math.isnan(value) or math.isinf(value):
        raise ValueError(f"timeout must be a finite number, got {value!r}")
    if value < 0:
        raise ValueError(f"timeout cannot be negative, got {value!r}")
    return float(value)


class CancellationState(Enum):
    """The observable lifecycle of a cancellation.

    A plain :class:`~enum.Enum` rather than a ``str`` mixin or
    :class:`~enum.StrEnum`. The mixin's ``format()`` behaviour differs across
    the interpreters in our support matrix, and a wire vocabulary that renders
    differently on 3.11 than on 3.13 is a defect waiting for a release. Callers
    cross the wire through :attr:`value`, explicitly, and a test pins the
    strings so they cannot drift.
    """

    ACTIVE = "active"
    REQUESTED = "requested"
    CANCELLING = "cancelling"
    CANCELLED = "cancelled"


class TerminalOutcome(Enum):
    """How an operation ended.

    Cancellation is a third outcome, not a flavour of the other two. Reporting
    it as success claims work that was abandoned; reporting it as failure blames
    the system for the user's decision.
    """

    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


#: Legal forward transitions. Anything absent here is either a no-op repeat or
#: an impossible order; :class:`CancellationSource` tells those two apart.
_ADVANCES_TO = {
    CancellationState.ACTIVE: (CancellationState.REQUESTED,),
    CancellationState.REQUESTED: (
        CancellationState.CANCELLING,
        # A fast unwind may finish before anything renders `cancelling`.
        # Requiring an observable cancelling phase would force a worker with
        # nothing to clean up to publish a state it was never in.
        CancellationState.CANCELLED,
    ),
    CancellationState.CANCELLING: (CancellationState.CANCELLED,),
    CancellationState.CANCELLED: (),
}


class CancellationStateError(RuntimeError):
    """An impossible transition was attempted.

    Raised for call orders that cannot arise from a race - acknowledging a
    request nobody made, or completing an unwind that never started. Genuine
    races (two clicks, two threads requesting at once) are idempotent instead,
    because they are legitimate and a caller cannot prevent them.
    """


class CancellationRequested(Exception):
    """Raised by :meth:`CancellationToken.raise_if_requested`.

    Deliberately not a subclass of :class:`KeyboardInterrupt` or
    :class:`SystemExit`: a cancelled operation is an ordinary control-flow
    outcome that surrounding code should be able to catch without also
    swallowing an operator's Ctrl+C.
    """


@dataclass(frozen=True)
class CancellationStatus:
    """Immutable point-in-time telemetry.

    What crosses a wire or a widget boundary. Carries no lock, no event and no
    authority - a status can be copied, serialised and rendered freely, and
    holding one grants nobody the ability to cancel anything.
    """

    state: CancellationState

    @property
    def is_requested(self) -> bool:
        """True once cancellation has been asked for, at any later stage."""
        return self.state is not CancellationState.ACTIVE

    @property
    def is_terminal(self) -> bool:
        return self.state is CancellationState.CANCELLED

    @property
    def wire_value(self) -> str:
        """The string form used in a state document."""
        return self.state.value


#: The status every operation starts from. Shared because it is immutable, and
#: because reading 1.0 documents that predate cancellation must produce exactly
#: this rather than something merely equal to it.
ACTIVE_STATUS = CancellationStatus(CancellationState.ACTIVE)


class CancellationToken:
    """The worker's half of the protocol: poll, acknowledge, complete.

    Obtained from :attr:`CancellationSource.token`; never constructed directly,
    because a token that is not bound to a source is a token nobody can trip,
    and code holding one would poll forever against a signal that cannot arrive.
    """

    __slots__ = ("_source",)

    def __init__(self, source: "CancellationSource") -> None:
        if not isinstance(source, CancellationSource):
            raise TypeError(
                "a CancellationToken is obtained from CancellationSource.token, "
                "not constructed directly"
            )
        self._source = source

    # -- polling ----------------------------------------------------------

    @property
    def is_requested(self) -> bool:
        """True from the moment cancellation is requested, and forever after."""
        return self._source._requested.is_set()

    @property
    def state(self) -> CancellationState:
        return self._source.state

    @property
    def status(self) -> CancellationStatus:
        return self._source.status

    def wait(self, timeout: Optional[float] = None) -> bool:
        """Block until cancellation is requested, or *timeout* elapses.

        The reason this module wraps :class:`threading.Event` rather than a
        flag: a polling worker needs an interruptible sleep. ``wait(0.5)`` in
        place of ``time.sleep(0.5)`` turns a half-second of unresponsiveness
        into an immediate return, without anyone reasoning about memory
        ordering.

        ``timeout`` is validated strictly - see :func:`_validated_timeout`.
        ``None``, zero and positive finite numbers are accepted; ``bool``,
        non-numeric types, NaN and the infinities are not.

        Returns True if cancellation was requested.
        """
        return self._source._requested.wait(_validated_timeout(timeout))

    def raise_if_requested(self) -> None:
        """Raise :class:`CancellationRequested` if cancellation was asked for.

        For workers whose unwind is an ordinary ``try``/``finally``. A worker
        with real cleanup to sequence should test :attr:`is_requested` and call
        :meth:`acknowledge` instead, so the UI can report the unwind honestly.
        """
        if self.is_requested:
            raise CancellationRequested("cancellation was requested")

    # -- acknowledgement (the worker's authority, not the requester's) -----

    def acknowledge(self) -> bool:
        """Report that the worker has seen the request and begun unwinding.

        Moves ``requested`` to ``cancelling``. Idempotent: a second call while
        already unwinding returns False rather than failing, since a worker may
        legitimately reach this line more than once.

        Raises :class:`CancellationStateError` if nothing was ever requested -
        that cannot happen from a race, only from a bug, and swallowing it would
        conceal the defect.
        """
        return self._source._advance(
            CancellationState.CANCELLING,
            require_requested="acknowledge",
        )

    def complete(self) -> bool:
        """Report that the unwind has finished. Moves the state to ``cancelled``."""
        return self._source._advance(
            CancellationState.CANCELLED,
            require_requested="complete",
        )

    def __repr__(self) -> str:
        return f"<CancellationToken {self.state.value}>"


class CancellationSource:
    """The requester's half of the protocol: raise the signal, read the state.

    Held by whatever the user acts on - a Tk button, a SIGINT handler, an HTTP
    route. Hand :attr:`token` to the worker.
    """

    __slots__ = ("_lock", "_requested", "_state", "_token", "__weakref__")

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # The latch that makes wait() possible. Set once, never cleared.
        self._requested = threading.Event()
        self._state = CancellationState.ACTIVE
        self._token = CancellationToken(self)

    @property
    def token(self) -> CancellationToken:
        """The worker's view. Safe to share across threads."""
        return self._token

    @property
    def state(self) -> CancellationState:
        with self._lock:
            return self._state

    @property
    def status(self) -> CancellationStatus:
        """Immutable telemetry for renderers and serialisers."""
        with self._lock:
            state = self._state
        return ACTIVE_STATUS if state is CancellationState.ACTIVE else CancellationStatus(state)

    @property
    def is_requested(self) -> bool:
        return self._requested.is_set()

    def request(self) -> bool:
        """Ask for cancellation.

        Returns True if this call raised the signal, False if it was already
        raised. Idempotent by design: two buttons, two threads, or a double
        click are races the caller cannot prevent, so they must not be errors.

        Has no effect once the unwind is complete - a request that arrives after
        the operation already finished cancelling does not reopen it.
        """
        with self._lock:
            if self._state is not CancellationState.ACTIVE:
                return False
            self._state = CancellationState.REQUESTED
            # Inside the lock, so a thread that observes the state has
            # necessarily observed the latch too.
            self._requested.set()
            return True

    def _advance(self, target: CancellationState, *, require_requested: str) -> bool:
        """Move the lifecycle forward. Used by the token, not by the requester."""
        with self._lock:
            current = self._state
            if current is CancellationState.ACTIVE:
                raise CancellationStateError(
                    f"cannot {require_requested}() a cancellation that was never "
                    "requested; the worker's half of the protocol only becomes "
                    "available after CancellationSource.request()"
                )
            if current is target:
                return False
            if target not in _ADVANCES_TO[current]:
                # Backwards, or skipping a completed terminal state.
                raise CancellationStateError(
                    f"cannot {require_requested}(): {current.value} does not "
                    f"advance to {target.value}"
                )
            self._state = target
            return True

    def __repr__(self) -> str:
        return f"<CancellationSource {self.state.value}>"
