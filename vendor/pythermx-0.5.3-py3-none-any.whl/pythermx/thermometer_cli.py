"""Terminal renderer for :class:`ThermometerCore`."""

from __future__ import annotations

import contextlib
import shutil
import signal
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, replace
from typing import IO, Iterator, Optional

from .cancellation import CancellationSource
from .thermometer_core import ThermometerCore, ThermometerState
from .thermometer_fields import MODE_INDETERMINATE

DEFAULT_SPINNER_FRAMES = ("\\", "|", "/", "-")

#: Terminal status word for a cancelled run, beside "OK" and "FAIL".
CANCELLED_STATUS = "CANCELLED"

#: Attribute marking a PyThermX SIGINT handler and carrying its escalation
#: target, so nested contexts can look past each other to the real handler.
_ULTIMATE = "_pythermx_ultimate_sigint_handler"

__all__ = [
    "CANCELLED_STATUS",
    "CLIThermometer",
    "CLIThermometerStyle",
    "capture_sigint",
]


@contextlib.contextmanager
def capture_sigint(
    source: CancellationSource,
    *,
    stream: Optional[IO[str]] = None,
    notice: str = "\n[Cancellation requested...]\n",
) -> Iterator[CancellationSource]:
    """Route the first Ctrl+C into *source* instead of a ``KeyboardInterrupt``.

    A terminal has no cancel button; Ctrl+C is the gesture. Turning it into a
    cooperative request lets a worker unwind at a point it chose, rather than
    taking an exception at whatever bytecode boundary the signal happened to
    land on.

    **Two stages, deliberately.** The first SIGINT requests cancellation and is
    swallowed. The second re-raises through the handler that was installed
    before this context, so an unresponsive worker can never trap the operator:
    someone who presses Ctrl+C twice always gets out.

    **Restores the exact previous handler**, not ``SIG_DFL``. Nesting works
    because each context restores what it found, LIFO. A caller who had
    installed ``SIG_IGN`` or a custom handler gets that back, not our guess at
    what they wanted.

    **Main thread only.** ``signal.signal`` cannot install from another thread,
    and this raises rather than warning-and-continuing: a no-op would hand the
    caller a cancellation guarantee that silently does not exist.
    """
    if not isinstance(source, CancellationSource):
        raise TypeError(
            f"capture_sigint() requires a CancellationSource, got "
            f"{type(source).__name__}"
        )
    if threading.current_thread() is not threading.main_thread():
        raise RuntimeError(
            "capture_sigint() must be used on the main thread; signal handlers "
            "cannot be installed elsewhere, and silently doing nothing would "
            "promise a cancellation that never arrives"
        )

    target = stream if stream is not None else sys.stderr
    previous = signal.getsignal(signal.SIGINT)

    # Escalate past any enclosing PyThermX contexts, straight to whatever was
    # installed before the outermost one (THERM-A010-02).
    #
    # Nesting otherwise defeats the guarantee: each handler owned an
    # independent "have I already been pressed" flag, so the inner handler's
    # second press was delivered to the outer *PyThermX* handler, which read it
    # as its own first press and requested its own source instead of raising.
    # An operator inside two contexts needed three presses to escape, and
    # inside N contexts, N+1. The second press must always be the last one.
    ultimate = getattr(previous, _ULTIMATE, previous)
    escalating = False

    def handler(signum, frame):
        nonlocal escalating
        if escalating:
            _delegate(ultimate, signum, frame)
            return
        escalating = True
        source.request()
        try:
            target.write(notice)
            target.flush()
        except (BrokenPipeError, ConnectionError, ValueError):
            # A closed or redirected stream must not turn Ctrl+C into a crash.
            pass

    # Marks this as a PyThermX handler and carries the escalation target, so a
    # context nested inside this one can look past us to the real handler.
    setattr(handler, _ULTIMATE, ultimate)

    try:
        signal.signal(signal.SIGINT, handler)
    except (ValueError, OSError) as error:
        # Installation failed; the previous handler is untouched. Reported
        # rather than swallowed, so the caller knows Ctrl+C is not captured.
        raise RuntimeError(f"could not install a SIGINT handler: {error}") from error

    try:
        yield source
    finally:
        # Unconditional, including when the body raises. A context manager that
        # leaked a handler would corrupt the next one's idea of "previous".
        signal.signal(signal.SIGINT, previous)


def _delegate(previous, signum, frame) -> None:
    """Escalate the second Ctrl+C to whatever was installed before us."""
    if callable(previous):
        previous(signum, frame)
        return
    if previous is signal.SIG_IGN:
        # The caller had chosen to ignore SIGINT. Honouring that would leave an
        # operator with no way out, so escalation wins over the prior choice -
        # that is the whole point of the second press.
        raise KeyboardInterrupt
    # SIG_DFL, or anything unrecognised.
    raise KeyboardInterrupt


@dataclass(frozen=True)
class CLIThermometerStyle:
    """Terminal presentation settings."""

    width: int = 40
    fill_char: str = "#"
    empty_char: str = "-"
    left_bracket: str = "["
    right_bracket: str = "]"
    show_percent: bool = True
    show_value: bool = True
    show_label: bool = True
    non_tty_min_interval_s: float = 0.5
    show_count: bool = True
    count_format: str = "{:,.0f}"
    unit: Optional[str] = None
    show_elapsed: bool = False
    show_rate: bool = False
    spinner_frames: tuple[str, ...] = DEFAULT_SPINNER_FRAMES
    spinner_interval_s: float = 0.1
    min_redraw_interval_s: float = 0.0
    promoted_separator: str = "-"
    retain_history: bool = False


class CLIThermometer:
    """Render determinate bars or indeterminate activity to a text stream."""

    def __init__(
        self,
        model: ThermometerCore,
        *,
        style: CLIThermometerStyle = CLIThermometerStyle(),
        stream: Optional[IO[str]] = None,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._model = model
        self._style = self._sanitize_style(style)
        self._stream = stream if stream is not None else sys.stderr
        if not callable(clock):
            raise TypeError("clock must be callable")
        self._clock = clock
        self._is_tty = bool(getattr(self._stream, "isatty", lambda: False)())
        self._last_len = 0
        self._started = False
        self._finished = False
        self._last_render_ts: Optional[float] = None
        self._last_non_tty_print_ts: Optional[float] = None
        self._write_lock = threading.RLock()
        self._worker_error: Optional[BaseException] = None

    def start(self) -> None:
        with self._write_lock:
            self._started = True
            self._finished = False

    def tick(self, *, message: str = "") -> None:
        """Caller-driven animation/update point."""
        self.render(message=message)

    def render(self, *, message: str = "") -> None:
        """Render once, respecting redraw throttles."""
        self._raise_worker_error()
        self._render(message=message, from_worker=False)

    def finish(self, *, ok: bool = True, message: str = "") -> None:
        """Write a final status line and restore the terminal line."""
        self._terminate("OK" if ok else "FAIL", message)

    def finish_cancelled(self, *, message: str = "") -> None:
        """End the run as a cancellation.

        A dedicated method rather than a third boolean on :meth:`finish`,
        because ``ok=True, cancelled=True`` is a contradiction that should not
        be expressible. Cancellation is a third outcome: reporting it as
        success claims work that was abandoned, and reporting it as failure
        blames the system for the user's decision.

        Note what this method does *not* do: it presents a terminal outcome, it
        does not establish one. ``CancellationToken.complete()`` establishes the
        clean unwind. Call this only after that has succeeded - if cleanup
        raised, the outcome is a failure and belongs in ``finish(ok=False)``.
        """
        self._terminate(CANCELLED_STATUS, message)

    def _terminate(self, status: str, message: str) -> None:
        """One implementation behind both terminal methods."""
        self._raise_worker_error()
        final_message = status if not message else f"{status} | {message}"
        with self._write_lock:
            self._finished = True
            line = self._build_line(message=final_message)
            if self._is_tty:
                if self._style.retain_history:
                    self._write_history(line)
                else:
                    self._write_inline(self._fit_inline_line(line))
                    self._stream.write("\n")
                    self._stream.flush()
                    self._last_len = 0
            else:
                self._stream.write(line + "\n")
                self._stream.flush()

    def auto_refresh(self) -> _AutoRefresh:
        """Return an opt-in context manager that animates while callers block."""
        return _AutoRefresh(self)

    def _render(self, *, message: str, from_worker: bool) -> None:
        with self._write_lock:
            if self._finished:
                return
            if from_worker and self._style.retain_history:
                return
            if not self._started:
                self._started = True
            now = float(self._clock())
            if self._is_tty:
                if (
                    self._last_render_ts is not None
                    and now - self._last_render_ts < self._style.min_redraw_interval_s
                ):
                    return
                line = self._build_line(message=message)
                if self._style.retain_history:
                    self._write_history(line)
                else:
                    self._write_inline(self._fit_inline_line(line))
                self._last_render_ts = now
                return

            # Auto-refresh animation is deliberately TTY-only. A caller-driven
            # render still emits bounded log lines when output is redirected.
            if from_worker:
                return
            if (
                self._last_non_tty_print_ts is None
                or now - self._last_non_tty_print_ts
                >= self._style.non_tty_min_interval_s
            ):
                self._stream.write(self._build_line(message=message) + "\n")
                self._stream.flush()
                self._last_non_tty_print_ts = now

    def _build_line(self, *, message: str = "") -> str:
        snap = self._model.snapshot()
        if snap.mode == MODE_INDETERMINATE:
            parts = self._build_indeterminate_parts(snap)
        else:
            parts = self._build_determinate_parts(snap)
        if message:
            parts.append(message)
        return " | ".join(parts)

    def _build_determinate_parts(self, snap: ThermometerState) -> list[str]:
        assert snap.percent is not None and snap.total is not None
        width = self._effective_width(self._style.width)
        pct = max(0.0, min(100.0, snap.percent))
        filled = max(0, min(width, int(round((pct / 100.0) * width))))
        bar = (
            self._style.left_bracket
            + self._style.fill_char * filled
            + self._style.empty_char * (width - filled)
            + self._style.right_bracket
        )
        parts = [bar]
        if self._style.show_percent:
            parts.append(f"{pct:6.1f}%")
        if self._style.show_value:
            value = f"{snap.current:g}/{snap.total:g}"
            if snap.promoted_from is not None:
                unit = self._display_unit(snap)
                found = self._format_count(snap.promoted_from)
                separator = self._style.promoted_separator
                value = f"{found}{self._unit_suffix(unit)} found {separator} {value}"
            parts.append(value)
        label = snap.phase or snap.label
        if self._style.show_label and label:
            parts.append(str(label))
        self._append_timing(parts, snap)
        return parts

    def _build_indeterminate_parts(self, snap: ThermometerState) -> list[str]:
        elapsed = snap.elapsed_s
        frame_index = int(elapsed / self._style.spinner_interval_s)
        frame = self._style.spinner_frames[frame_index % len(self._style.spinner_frames)]
        parts = [frame]
        label = snap.phase or snap.label
        if self._style.show_label and label:
            parts.append(str(label))
        if self._style.show_count:
            count = self._format_count(snap.current)
            parts.append(count + self._unit_suffix(self._display_unit(snap)))
        self._append_timing(parts, snap)
        return parts

    def _append_timing(self, parts: list[str], snap: ThermometerState) -> None:
        if self._style.show_elapsed:
            parts.append(f"{snap.elapsed_s:.1f}s")
        if self._style.show_rate and snap.elapsed_s > 0:
            rate = self._format_count(snap.current / snap.elapsed_s)
            unit = self._display_unit(snap)
            suffix = f" {unit}/s" if unit else "/s"
            parts.append(rate + suffix)

    def _display_unit(self, snap: ThermometerState) -> Optional[str]:
        return self._style.unit if self._style.unit is not None else snap.unit

    @staticmethod
    def _unit_suffix(unit: Optional[str]) -> str:
        return f" {unit}" if unit else ""

    def _format_count(self, value: float) -> str:
        return self._style.count_format.format(value)

    def _write_inline(self, line: str) -> None:
        line = self._fit_inline_line(line)
        max_width = max(1, self._terminal_columns() - 1)
        pad_length = min(
            max(0, self._last_len - len(line)),
            max(0, max_width - len(line)),
        )
        pad = " " * pad_length
        self._stream.write("\r" + line + pad)
        self._stream.flush()
        self._last_len = len(line)

    def _write_history(self, line: str) -> None:
        self._stream.write(line + "\n")
        self._stream.flush()
        self._last_len = 0

    def _fit_inline_line(self, line: str) -> str:
        """Keep one logical redraw inside one physical terminal row."""
        max_width = max(1, self._terminal_columns() - 1)
        if len(line) <= max_width:
            return line
        if max_width <= 3:
            return line[:max_width]

        marker = "..."
        tail_width = min(30, max(1, max_width // 3))
        head_width = max_width - len(marker) - tail_width
        return line[:head_width] + marker + line[-tail_width:]

    @staticmethod
    def _terminal_columns() -> int:
        try:
            return max(1, shutil.get_terminal_size(fallback=(120, 20)).columns)
        except Exception:
            return 120

    def _effective_width(self, desired: int) -> int:
        desired = max(10, int(desired))
        columns = self._terminal_columns()
        return min(desired, max(10, columns - 40))

    def _raise_worker_error(self) -> None:
        if self._worker_error is not None:
            error = self._worker_error
            self._worker_error = None
            raise error

    @staticmethod
    def _sanitize_style(style: CLIThermometerStyle) -> CLIThermometerStyle:
        frames = tuple(frame for frame in style.spinner_frames if frame)
        spinner_interval = float(style.spinner_interval_s)
        redraw_interval = float(style.min_redraw_interval_s)
        non_tty_interval = float(style.non_tty_min_interval_s)
        count_format = style.count_format
        try:
            count_format.format(1234.0)
        except (IndexError, KeyError, TypeError, ValueError, AttributeError):
            count_format = "{:,.0f}"
        return replace(
            style,
            width=max(10, int(style.width)),
            fill_char=style.fill_char or "#",
            empty_char=style.empty_char or "-",
            left_bracket=style.left_bracket or "[",
            right_bracket=style.right_bracket or "]",
            show_percent=bool(style.show_percent),
            show_value=bool(style.show_value),
            show_label=bool(style.show_label),
            non_tty_min_interval_s=(
                non_tty_interval if non_tty_interval > 0 else 0.5
            ),
            show_count=bool(style.show_count),
            count_format=count_format,
            show_elapsed=bool(style.show_elapsed),
            show_rate=bool(style.show_rate),
            spinner_frames=frames or DEFAULT_SPINNER_FRAMES,
            spinner_interval_s=(spinner_interval if spinner_interval > 0 else 0.1),
            min_redraw_interval_s=(redraw_interval if redraw_interval >= 0 else 0.0),
            promoted_separator=str(style.promoted_separator or "-"),
            retain_history=bool(style.retain_history),
        )


class _AutoRefresh:
    """Idempotent, bounded worker owned by one CLI renderer."""

    def __init__(self, renderer: CLIThermometer) -> None:
        self._renderer = renderer
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def __enter__(self) -> _AutoRefresh:
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        self.stop()
        return False

    def start(self) -> None:
        with self._renderer._write_lock:
            if (
                not self._renderer._is_tty
                or self._renderer._finished
                or self._renderer._style.retain_history
            ):
                return
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="pythermx-auto-refresh",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=max(0.1, self._renderer._style.spinner_interval_s * 2))

    def _run(self) -> None:
        interval = self._renderer._style.spinner_interval_s
        while not self._stop_event.wait(interval):
            try:
                self._renderer._render(message="", from_worker=True)
            except BaseException as error:
                self._renderer._worker_error = error
                self._stop_event.set()
                return
