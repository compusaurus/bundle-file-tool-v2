"""Honest, phase-aware rate and remaining-time estimation."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from .thermometer_core import ThermometerState

__all__ = ["ProgressEstimate", "ProgressEstimator"]


def _finite(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite")
    return number


@dataclass(frozen=True)
class ProgressEstimate:
    """One immutable estimate. ``None`` means the value is not credible yet."""

    rate_per_s: Optional[float] = None
    eta_s: Optional[float] = None
    sample_count: int = 0

    @property
    def ready(self) -> bool:
        return self.rate_per_s is not None


class ProgressEstimator:
    """Observe snapshots and estimate rate/ETA without changing core state.

    Samples restart after reset, promotion, total changes, or a backwards
    absolute correction. Indeterminate work never receives an ETA.
    """

    def __init__(
        self,
        *,
        smoothing: float = 0.3,
        min_samples: int = 2,
        min_sample_interval_s: float = 0.0,
    ) -> None:
        self.smoothing = _finite(smoothing, "smoothing")
        if not 0.0 < self.smoothing <= 1.0:
            raise ValueError("smoothing must be > 0 and <= 1")
        if isinstance(min_samples, bool) or not isinstance(min_samples, int):
            raise TypeError("min_samples must be an integer")
        if min_samples < 1:
            raise ValueError("min_samples must be >= 1")
        self.min_samples = min_samples
        self.min_sample_interval_s = _finite(
            min_sample_interval_s, "min_sample_interval_s"
        )
        if self.min_sample_interval_s < 0:
            raise ValueError("min_sample_interval_s cannot be negative")
        self.reset()

    def reset(self) -> None:
        self._last_elapsed: Optional[float] = None
        self._last_current: Optional[float] = None
        self._last_mode: Optional[str] = None
        self._last_total: Optional[float] = None
        self._last_promoted_from: Optional[float] = None
        self._rate: Optional[float] = None
        self._sample_count = 0
        self._last_state: Optional[ThermometerState] = None

    def observe(self, state: ThermometerState) -> ProgressEstimate:
        if not isinstance(state, ThermometerState):
            raise TypeError("ProgressEstimator requires a ThermometerState")
        elapsed = _finite(state.elapsed_s, "state.elapsed_s")
        current = _finite(state.current, "state.current")
        if elapsed < 0 or current < 0:
            raise ValueError("state elapsed and current values cannot be negative")

        phase_changed = self._last_elapsed is not None and (
            elapsed < self._last_elapsed
            or state.mode != self._last_mode
            or state.total != self._last_total
            or state.promoted_from != self._last_promoted_from
        )
        if phase_changed:
            self.reset()

        if self._last_elapsed is not None and self._last_current is not None:
            delta_elapsed = elapsed - self._last_elapsed
            delta_current = current - self._last_current
            if delta_current < 0:
                self._rate = None
                self._sample_count = 0
            elif (
                delta_current > 0
                and delta_elapsed > 0
                and delta_elapsed >= self.min_sample_interval_s
            ):
                instantaneous = delta_current / delta_elapsed
                self._rate = (
                    instantaneous
                    if self._rate is None
                    else self.smoothing * instantaneous
                    + (1.0 - self.smoothing) * self._rate
                )
                self._sample_count += 1

        self._last_elapsed = elapsed
        self._last_current = current
        self._last_mode = state.mode
        self._last_total = state.total
        self._last_promoted_from = state.promoted_from
        self._last_state = state
        return self.estimate(state)

    def estimate(
        self, state: Optional[ThermometerState] = None
    ) -> ProgressEstimate:
        state = self._last_state if state is None else state
        if state is None:
            return ProgressEstimate()
        if not isinstance(state, ThermometerState):
            raise TypeError("ProgressEstimator requires a ThermometerState")
        rate = self._ready_rate()
        if state.total is not None and state.current >= state.total:
            return ProgressEstimate(rate, 0.0, self._sample_count)
        eta = None
        if (
            state.mode != "indeterminate"
            and state.total is not None
            and rate is not None
            and rate > 0
        ):
            eta = max(0.0, (state.total - state.current) / rate)
        return ProgressEstimate(rate, eta, self._sample_count)

    def _ready_rate(self) -> Optional[float]:
        if (
            self._sample_count >= self.min_samples
            and self._rate is not None
            and math.isfinite(self._rate)
            and self._rate > 0
        ):
            return self._rate
        return None
