"""Convenience adapters for iterables, async iterables, files, and callables."""

from __future__ import annotations

import inspect
import operator
import time
from collections.abc import AsyncIterable, AsyncIterator, Callable, Iterable, Iterator, Mapping
from typing import Any, Generic, IO, Optional, TypeVar

from .cancellation import (
    CancellationRequested,
    CancellationSource,
    CancellationState,
)
from .config import resolve_cli_style
from .estimation import ProgressEstimator
from .thermometer_cli import CLIThermometer, CLIThermometerStyle
from .thermometer_core import ThermometerCore

T = TypeVar("T")
R = TypeVar("R")

__all__ = [
    "ProgressAsyncIterator",
    "ProgressIterator",
    "ProgressRun",
    "infer_total",
    "run_with_progress",
    "run_with_progress_async",
    "track",
    "track_async",
    "track_file",
]


def infer_total(iterable: object) -> Optional[int]:
    """Return a useful positive length, or ``None`` when it is unknown."""
    try:
        value = len(iterable)  # type: ignore[arg-type]
    except (TypeError, AttributeError):
        try:
            value = operator.length_hint(iter(iterable), 0)  # type: ignore[arg-type]
        except (TypeError, AttributeError):
            return None
    return int(value) if value > 0 else None


def _resolved_step(step: float | Callable[[Any, int], float], item: Any, index: int) -> float:
    return step(item, index) if callable(step) else step


class ProgressRun:
    """Own one composed model/renderer/estimator/cancellation run."""

    def __init__(
        self,
        total: Optional[float] = None,
        label: Optional[str] = None,
        *,
        unit: Optional[str] = None,
        phase: Optional[str] = None,
        model: Optional[ThermometerCore] = None,
        source: Optional[CancellationSource] = None,
        renderer: CLIThermometer | bool | None = None,
        render: bool = True,
        style: CLIThermometerStyle | Mapping[str, Any] | None = None,
        stream: Optional[IO[str]] = None,
        clock: Callable[[], float] = time.monotonic,
        estimator: Optional[ProgressEstimator] = None,
        estimation: Optional[Mapping[str, Any]] = None,
        show_eta: Optional[bool] = None,
        throw_on_cancel: bool = True,
    ) -> None:
        self.model = model or ThermometerCore(
            total, label, unit=unit, phase=phase, clock=clock
        )
        self.source = source or CancellationSource()
        self.token = self.source.token
        self.estimator = estimator or ProgressEstimator(**dict(estimation or {}))
        self.throw_on_cancel = bool(throw_on_cancel)
        self._started = False
        self._ended = False

        if renderer is False or not render:
            self.renderer: Optional[CLIThermometer] = None
        elif isinstance(renderer, CLIThermometer):
            self.renderer = renderer
        else:
            if style is None:
                selected = CLIThermometerStyle()
            elif isinstance(style, CLIThermometerStyle):
                selected = style
            elif isinstance(style, Mapping):
                selected = resolve_cli_style(style)
            else:
                raise TypeError("style must be CLIThermometerStyle or a mapping")
            if show_eta is not None:
                selected = selected.with_options(show_eta=bool(show_eta))
            self.renderer = CLIThermometer(
                self.model,
                style=selected,
                stream=stream,
                clock=clock,
                estimator=self.estimator,
            )

    @property
    def started(self) -> bool:
        return self._started

    @property
    def ended(self) -> bool:
        return self._ended

    def start(self) -> bool:
        if self._ended or self._started:
            return False
        self._started = True
        if self.renderer is not None:
            self.renderer.start()
        return True

    def render(self, message: str = ""):
        if not self._started:
            self.start()
        snapshot = self.model.snapshot()
        estimate = self.estimator.observe(snapshot)
        if self.renderer is not None:
            self.renderer.render(message=message)
        return snapshot, estimate

    def update(self, value: float, message: str = ""):
        self.token.raise_if_requested()
        self.model.update(value)
        return self.render(message)

    def increment(self, delta: float = 1.0, message: str = ""):
        self.token.raise_if_requested()
        self.model.increment(delta)
        return self.render(message)

    def complete(self, message: str = "") -> bool:
        if self._ended:
            return False
        if self.token.is_requested:
            return self.cancel(message or "Cancelled")
        self._ended = True
        if self.renderer is not None:
            self.renderer.finish(ok=True, message=message)
        return True

    def fail(self, error: object) -> bool:
        if self._ended:
            return False
        self._ended = True
        message = str(error)
        if self.renderer is not None:
            self.renderer.finish(ok=False, message=message)
        return True

    def cancel(self, message: str = "Cancelled") -> bool:
        if self._ended:
            return False
        if self.source.state is CancellationState.ACTIVE:
            self.source.request()
        if self.source.state is CancellationState.REQUESTED:
            self.token.acknowledge()
        if self.source.state is CancellationState.CANCELLING:
            self.token.complete()
        self._ended = True
        if self.renderer is not None:
            self.renderer.finish_cancelled(message=message)
        return True

    def close(self) -> bool:
        if self._ended:
            return False
        self._ended = True
        if self.renderer is not None:
            self.renderer.close()
        return True


class ProgressIterator(Iterator[T], Generic[T]):
    """Iterator wrapper with inspectable model, source, token, and run."""

    def __init__(
        self,
        iterable: Iterable[T],
        *,
        step: float | Callable[[T, int], float] = 1.0,
        complete_message: str = "",
        cancel_message: str = "Cancelled",
        **options: Any,
    ) -> None:
        self._iterator = iter(iterable)
        total = options.pop("total", infer_total(iterable))
        self.run = ProgressRun(total=total, **options)
        self.model = self.run.model
        self.source = self.run.source
        self.token = self.run.token
        self._step = step
        self._complete_message = complete_message
        self._cancel_message = cancel_message
        self._pending: Optional[tuple[T, int]] = None
        self._index = 0
        self.run.start()

    def __iter__(self) -> "ProgressIterator[T]":
        return self

    def __next__(self) -> T:
        try:
            if self._pending is not None:
                item, index = self._pending
                self.run.increment(_resolved_step(self._step, item, index))
                self._pending = None
            self.token.raise_if_requested()
            item = next(self._iterator)
        except StopIteration:
            self.run.complete(self._complete_message)
            raise
        except CancellationRequested:
            self.run.cancel(self._cancel_message)
            if self.run.throw_on_cancel:
                raise
            raise StopIteration from None
        except Exception as error:
            self.run.fail(error)
            raise
        self._pending = (item, self._index)
        self._index += 1
        return item

    def close(self) -> None:
        closer = getattr(self._iterator, "close", None)
        if callable(closer):
            closer()
        self.run.close()

    def __enter__(self) -> "ProgressIterator[T]":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        if exc_value is not None and isinstance(exc_value, Exception):
            self.run.fail(exc_value)
        else:
            self.close()
        return False


class ProgressAsyncIterator(AsyncIterator[T], Generic[T]):
    """Async iterator wrapper for async or ordinary iterables."""

    def __init__(
        self,
        iterable: AsyncIterable[T] | Iterable[T],
        *,
        step: float | Callable[[T, int], float] = 1.0,
        complete_message: str = "",
        cancel_message: str = "Cancelled",
        **options: Any,
    ) -> None:
        self._async_iterator = (
            iterable.__aiter__() if isinstance(iterable, AsyncIterable) else None
        )
        self._iterator = iter(iterable) if self._async_iterator is None else None
        total = options.pop("total", infer_total(iterable))
        self.run = ProgressRun(total=total, **options)
        self.model = self.run.model
        self.source = self.run.source
        self.token = self.run.token
        self._step = step
        self._complete_message = complete_message
        self._cancel_message = cancel_message
        self._pending: Optional[tuple[T, int]] = None
        self._index = 0
        self.run.start()

    def __aiter__(self) -> "ProgressAsyncIterator[T]":
        return self

    async def __anext__(self) -> T:
        import asyncio

        try:
            if self._pending is not None:
                item, index = self._pending
                self.run.increment(_resolved_step(self._step, item, index))
                self._pending = None
            self.token.raise_if_requested()
            if self._async_iterator is not None:
                item = await self._async_iterator.__anext__()
            else:
                assert self._iterator is not None
                item = next(self._iterator)
        except (StopIteration, StopAsyncIteration):
            self.run.complete(self._complete_message)
            raise StopAsyncIteration from None
        except CancellationRequested:
            self.run.cancel(self._cancel_message)
            if self.run.throw_on_cancel:
                raise
            raise StopAsyncIteration from None
        except asyncio.CancelledError:
            self.source.request()
            self.run.cancel(self._cancel_message)
            raise
        except Exception as error:
            self.run.fail(error)
            raise
        self._pending = (item, self._index)
        self._index += 1
        return item

    async def aclose(self) -> None:
        closer = getattr(self._async_iterator, "aclose", None)
        if callable(closer):
            await closer()
        else:
            sync_closer = getattr(self._iterator, "close", None)
            if callable(sync_closer):
                sync_closer()
        self.run.close()

    async def __aenter__(self) -> "ProgressAsyncIterator[T]":
        return self

    async def __aexit__(self, exc_type, exc_value, traceback) -> bool:
        if exc_value is not None and isinstance(exc_value, Exception):
            self.run.fail(exc_value)
        else:
            await self.aclose()
        return False


def track(iterable: Iterable[T], **options: Any) -> ProgressIterator[T]:
    return ProgressIterator(iterable, **options)


def track_async(
    iterable: AsyncIterable[T] | Iterable[T], **options: Any
) -> ProgressAsyncIterator[T]:
    return ProgressAsyncIterator(iterable, **options)


def track_file(file: Iterable[T], **options: Any) -> ProgressIterator[T]:
    options.setdefault("unit", "bytes")
    options.setdefault("step", lambda chunk, _index: len(chunk))
    return ProgressIterator(file, **options)


def run_with_progress(action: Callable[[ProgressRun], R], **options: Any) -> R:
    run_options = dict(options)
    complete_message = str(run_options.pop("complete_message", ""))
    cancel_message = str(run_options.pop("cancel_message", "Cancelled"))
    run = ProgressRun(**run_options)
    run.start()
    try:
        result = action(run)
        if inspect.isawaitable(result):
            run.close()
            raise TypeError("run_with_progress() received an awaitable; use run_with_progress_async()")
        run.token.raise_if_requested()
        run.complete(complete_message)
        return result
    except CancellationRequested:
        run.cancel(cancel_message)
        raise
    except Exception as error:
        run.fail(error)
        raise
    finally:
        if not run.ended:
            run.close()


async def run_with_progress_async(
    action: Callable[[ProgressRun], R], **options: Any
) -> R:
    import asyncio

    run_options = dict(options)
    complete_message = str(run_options.pop("complete_message", ""))
    cancel_message = str(run_options.pop("cancel_message", "Cancelled"))
    run = ProgressRun(**run_options)
    run.start()
    try:
        result = action(run)
        if inspect.isawaitable(result):
            result = await result
        run.token.raise_if_requested()
        run.complete(complete_message)
        return result
    except (CancellationRequested, asyncio.CancelledError):
        if run.source.state is CancellationState.ACTIVE:
            run.source.request()
        run.cancel(cancel_message)
        raise
    except Exception as error:
        run.fail(error)
        raise
    finally:
        if not run.ended:
            run.close()
