"""JSON-ready serialization for :class:`ThermometerState`.

The supported web surface is a document contract, not a server. There is no
Python-side web UI toolkit, so the only thing a library can usefully supply is
the shape of the state a renderer consumes; transport belongs to the consumer.

Two properties are load-bearing and both are enforced rather than documented:

**Unknown progress serialises as ``null``, never ``0``.** A renderer handed
``0`` draws an empty bar and tells the user nothing has happened, when the truth
is that nothing can be known.

**The output is strict JSON.** Python's encoder emits the bare tokens ``NaN``
and ``Infinity`` unless told otherwise, and neither is JSON. The core admits
non-finite work values (THERM-DEFECT-001, scheduled 0.3.1), so this module is
the boundary that stops one reaching the wire.

Snapshots travel; models do not. :func:`from_dict` reconstructs a
``ThermometerState``, which is a frozen dataclass, and never a
``ThermometerCore``, which owns an injected clock and a live run.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from typing import Any, Mapping, Optional

from .cancellation import (
    ACTIVE_STATUS,
    CancellationState,
    CancellationStatus,
    TerminalOutcome,
)
from .thermometer_core import ThermometerState
from .thermometer_fields import (
    MODE_DETERMINATE,
    MODE_INDETERMINATE,
    ST_CANCELLATION_STATE,
    ST_CURRENT,
    ST_ELAPSED_S,
    ST_LABEL,
    ST_MODE,
    ST_PERCENT,
    ST_PHASE,
    ST_PROMOTED_FROM,
    ST_STATE_VERSION,
    ST_TERMINAL_OUTCOME,
    ST_TOTAL,
    ST_UNIT,
    STATE_VERSION_V1_0,
    STATE_VERSION_V1_1,
)

__all__ = [
    "ProgressEnvelope",
    "STATE_KEYS",
    "STATE_KEYS_V1_0",
    "STATE_KEYS_V1_1",
    "SUPPORTED_STATE_MAJOR",
    "UnsupportedStateVersion",
    "envelope_from_dict",
    "envelope_to_dict",
    "envelope_to_json",
    "from_dict",
    "to_dict",
    "to_json",
]

#: The ten measurement keys a v1.0 document carries.
STATE_KEYS_V1_0 = frozenset(
    {
        ST_STATE_VERSION,
        ST_MODE,
        ST_CURRENT,
        ST_TOTAL,
        ST_PERCENT,
        ST_LABEL,
        ST_UNIT,
        ST_PHASE,
        ST_ELAPSED_S,
        ST_PROMOTED_FROM,
    }
)

#: v1.1 adds cancellation telemetry additively - the ten above plus two.
STATE_KEYS_V1_1 = STATE_KEYS_V1_0 | {ST_CANCELLATION_STATE, ST_TERMINAL_OUTCOME}

#: Backward-compatible alias, bound to **v1.0** and not to the current schema.
#:
#: Deliberate: the legacy ``to_dict()`` still emits v1.0, so a caller using
#: ``STATE_KEYS`` to check what this library writes through the legacy path
#: keeps getting the right answer. Code validating an envelope must name
#: ``STATE_KEYS_V1_1`` explicitly rather than inherit a moving target.
STATE_KEYS = STATE_KEYS_V1_0

SUPPORTED_STATE_MAJOR = 1

# Two legitimate computation orders - (current / total) * 100 and
# current * 100 / total - disagree by at most one ulp, measured at 2.1e-16
# relative. 1e-12 leaves roughly 4,500x headroom over that while staying far
# too tight to admit a display-rounded value such as 33.3. A document carries
# state, not presentation.
PERCENT_REL_TOL = 1e-12
PERCENT_ABS_TOL = 1e-12

_VERSION_RE = re.compile(r"^(\d+)\.(\d+)$")
_MODES = (MODE_DETERMINATE, MODE_INDETERMINATE)


class UnsupportedStateVersion(ValueError):
    """Raised for a malformed or unsupported ``state_version``.

    A ``ValueError`` subclass so that callers who only guard against bad input
    generally still catch it, and public so that callers who want to
    distinguish a version problem from any other rejection can.
    """


# ---------------------------------------------------------------------------
# Validation - one implementation, used in both directions
# ---------------------------------------------------------------------------

def _reject(field: str, why: str) -> None:
    raise ValueError(f"{field}: {why}")


def _number(document: Mapping[str, Any], field: str) -> float:
    """Return a finite float, rejecting booleans and non-finite values."""
    value = document[field]
    # bool is a subclass of int in Python, so True would otherwise pass as 1.
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _reject(field, f"expected a number, got {type(value).__name__}")
    value = float(value)
    if not math.isfinite(value):
        _reject(field, "must be finite")
    return value


def _optional_text(document: Mapping[str, Any], field: str) -> Optional[str]:
    value = document[field]
    if value is not None and not isinstance(value, str):
        _reject(field, f"expected a string or null, got {type(value).__name__}")
    return value


def _state_version(document: Mapping[str, Any]) -> tuple[int, int]:
    """Accept 1.<nonnegative integer>; a missing field defaults to 1.0.

    Absence carries no major version of its own - it means the document
    predates the field, which can only have been within major 1.

    Returns ``(major, minor)`` as **integers**. The components are compared
    numerically and never lexically: ``"1.10" < "1.9"`` as strings, which would
    silently route a tenth minor revision down the v1.0 branch.
    """
    raw = document.get(ST_STATE_VERSION, STATE_VERSION_V1_0)
    if not isinstance(raw, str):
        raise UnsupportedStateVersion(
            f"state_version must be a string, got {type(raw).__name__}"
        )
    match = _VERSION_RE.match(raw)
    if match is None:
        raise UnsupportedStateVersion(f"malformed state_version {raw!r}")
    major, minor = int(match.group(1)), int(match.group(2))
    if major != SUPPORTED_STATE_MAJOR:
        raise UnsupportedStateVersion(
            f"unsupported state_version {raw!r}; this build supports "
            f"{SUPPORTED_STATE_MAJOR}.x"
        )
    return major, minor


#: Gate H legality matrix: which terminal outcomes each cancellation state
#: admits. Nine of sixteen combinations are legal.
#:
#: The ownership rule behind it: ``complete()`` *establishes* the clean domain
#: outcome, and ``finish_cancelled()`` merely presents it. So ``cancelled``
#: with a null outcome is not a transient worth serialising - it is an
#: incomplete envelope, and the coordinator must assemble a coherent one before
#: it reaches the wire.
_LEGAL_OUTCOMES: dict = {
    # No cancellation requested: any ordinary ending, but not `cancelled`.
    CancellationState.ACTIVE: (None, TerminalOutcome.COMPLETED, TerminalOutcome.FAILED),
    # `completed` is the race - work committed before the worker polled.
    # `failed` outranks an earlier request.
    CancellationState.REQUESTED: (None, TerminalOutcome.COMPLETED, TerminalOutcome.FAILED),
    # Unwinding. Cleanup may fail; abandoned work cannot be a normal completion.
    CancellationState.CANCELLING: (None, TerminalOutcome.FAILED),
    # `complete()` asserts a clean, sealed unwind. Nothing else is consistent.
    CancellationState.CANCELLED: (TerminalOutcome.CANCELLED,),
}


def _enum_from_wire(raw: Any, enum, field: str):
    """Map a wire string onto an enum member, rejecting anything else."""
    if not isinstance(raw, str):
        _reject(field, f"expected a string, got {type(raw).__name__}")
    for member in enum:
        if member.value == raw:
            return member
    allowed = ", ".join(repr(m.value) for m in enum)
    _reject(field, f"expected one of {allowed}, got {raw!r}")


def _validate_cancellation(document: Mapping[str, Any]) -> None:
    """Enforce the Gate H matrix on a v1.1+ document."""
    state = _enum_from_wire(
        document[ST_CANCELLATION_STATE], CancellationState, ST_CANCELLATION_STATE
    )
    raw_outcome = document[ST_TERMINAL_OUTCOME]
    outcome = (
        None
        if raw_outcome is None
        else _enum_from_wire(raw_outcome, TerminalOutcome, ST_TERMINAL_OUTCOME)
    )
    if outcome not in _LEGAL_OUTCOMES[state]:
        legal = ", ".join(
            "null" if o is None else repr(o.value) for o in _LEGAL_OUTCOMES[state]
        )
        _reject(
            ST_TERMINAL_OUTCOME,
            f"{('null' if outcome is None else repr(outcome.value))} is not a "
            f"legal outcome while cancellation_state is {state.value!r}; "
            f"legal here: {legal}",
        )


def _validate(document: Mapping[str, Any]) -> tuple[int, int]:
    """Enforce every snapshot invariant. Returns the accepted ``(major, minor)``.

    **Readers require; they do not demand exactness.** Each minor's required
    key set must be present, and any additional key is tolerated at every
    supported minor. Strict set equality was considered and rejected: 0.3.1
    accepts a 1.0 document carrying extra keys, so requiring equality would
    make 0.4.0 reject documents its predecessor accepted. Writers are exact;
    readers are tolerant.
    """
    major, minor = _state_version(document)
    required = STATE_KEYS_V1_0 if minor == 0 else STATE_KEYS_V1_1

    missing = sorted(required - {ST_STATE_VERSION} - set(document))
    if missing:
        _reject("document", f"missing required keys {missing}")

    mode = document[ST_MODE]
    if mode not in _MODES:
        _reject(ST_MODE, f"expected one of {_MODES}, got {mode!r}")

    current = _number(document, ST_CURRENT)
    if current < 0:
        _reject(ST_CURRENT, "must be >= 0")

    elapsed = _number(document, ST_ELAPSED_S)
    if elapsed < 0:
        _reject(ST_ELAPSED_S, "must be >= 0")

    for field in (ST_LABEL, ST_UNIT, ST_PHASE):
        _optional_text(document, field)

    total = document[ST_TOTAL]
    percent = document[ST_PERCENT]

    if mode == MODE_INDETERMINATE:
        # The honest-reporting rule, enforced rather than trusted.
        if total is not None:
            _reject(ST_TOTAL, "must be null in indeterminate mode")
        if percent is not None:
            _reject(ST_PERCENT, "must be null in indeterminate mode")
    else:
        if total is None:
            _reject(ST_TOTAL, "must not be null in determinate mode")
        if percent is None:
            _reject(ST_PERCENT, "must not be null in determinate mode")
        total = _number(document, ST_TOTAL)
        percent = _number(document, ST_PERCENT)
        if total <= 0:
            _reject(ST_TOTAL, "must be > 0")
        if current > total:
            _reject(ST_CURRENT, f"must be <= total ({current} > {total})")
        if not 0.0 <= percent <= 100.0:
            _reject(ST_PERCENT, "must be within 0..100")
        expected = (current / total) * 100.0
        if not math.isclose(
            percent, expected, rel_tol=PERCENT_REL_TOL, abs_tol=PERCENT_ABS_TOL
        ):
            _reject(
                ST_PERCENT,
                f"{percent!r} is not coherent with current/total ({expected!r})",
            )

    if document[ST_PROMOTED_FROM] is not None:
        promoted = _number(document, ST_PROMOTED_FROM)
        if promoted < 0:
            _reject(ST_PROMOTED_FROM, "must be >= 0")

    if minor >= 1:
        _validate_cancellation(document)

    return major, minor


# ---------------------------------------------------------------------------
# Public surface
# ---------------------------------------------------------------------------

def to_dict(state: ThermometerState) -> dict:
    """Return a JSON-ready document for ``state``, validated before release."""
    document = {
        ST_STATE_VERSION: STATE_VERSION_V1_0,
        ST_MODE: state.mode,
        ST_CURRENT: float(state.current),
        ST_TOTAL: None if state.total is None else float(state.total),
        ST_PERCENT: None if state.percent is None else float(state.percent),
        ST_LABEL: state.label,
        ST_UNIT: state.unit,
        ST_PHASE: state.phase,
        ST_ELAPSED_S: float(state.elapsed_s),
        ST_PROMOTED_FROM: (
            None if state.promoted_from is None else float(state.promoted_from)
        ),
    }
    _validate(document)
    return document


def to_json(state: ThermometerState, **kwargs: Any) -> str:
    """Serialise ``state`` as strict JSON.

    ``allow_nan`` is reserved: the strict-JSON guarantee is the point of this
    function, so it cannot be relaxed through ``**kwargs``. Default output is
    pure ASCII, so a redirected non-UTF-8 consumer cannot fail on it.
    """
    if "allow_nan" in kwargs:
        raise TypeError(
            "allow_nan is reserved by to_json(); non-finite values are rejected "
            "by to_dict() and cannot be emitted"
        )
    return json.dumps(to_dict(state), allow_nan=False, **kwargs)


def _state_from(document: Mapping[str, Any]) -> ThermometerState:
    """Build the measurement half. Assumes the document is already validated."""
    total = document[ST_TOTAL]
    percent = document[ST_PERCENT]
    promoted_from = document[ST_PROMOTED_FROM]
    return ThermometerState(
        current=float(document[ST_CURRENT]),
        total=None if total is None else float(total),
        percent=None if percent is None else float(percent),
        label=document[ST_LABEL],
        mode=document[ST_MODE],
        unit=document[ST_UNIT],
        phase=document[ST_PHASE],
        elapsed_s=float(document[ST_ELAPSED_S]),
        promoted_from=None if promoted_from is None else float(promoted_from),
    )


def from_dict(document: Mapping[str, Any]) -> ThermometerState:
    """Rebuild a :class:`ThermometerState` from a validated document.

    **The return type is unchanged in 0.4.0 and will stay that way.** Adding
    cancellation to the schema was not a licence to change what an existing
    public function hands back; a caller upgrading for a new feature must not
    have to rewrite code that never used it. Cancellation telemetry is reached
    through :func:`envelope_from_dict`, which is additive rather than breaking.

    Unknown keys are ignored, so an older consumer survives a newer additive
    producer. Unknown *major* versions are not ignored - see
    :class:`UnsupportedStateVersion`.
    """
    if not isinstance(document, Mapping):
        raise TypeError(
            f"expected a mapping, got {type(document).__name__}"
        )
    _validate(document)
    return _state_from(document)


# ---------------------------------------------------------------------------
# The envelope: measurement plus cancellation telemetry, added in 0.4.0
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ProgressEnvelope:
    """A complete observation: what the work is doing, and whether it is being
    stopped.

    Passive throughout. It carries a :class:`CancellationStatus`, which is
    immutable telemetry, and never a :class:`CancellationSource` or
    :class:`CancellationToken`. That is the security boundary: an inbound
    document describes a cancellation, and deserialising it must never be able
    to *cause* one in the receiving process.
    """

    state: ThermometerState
    cancellation: CancellationStatus = ACTIVE_STATUS
    terminal_outcome: Optional[TerminalOutcome] = None


def envelope_to_dict(envelope: ProgressEnvelope) -> dict:
    """Return a JSON-ready v1.1 document, validated before release.

    Writers are exact: this emits the twelve v1.1 keys and nothing else, while
    readers tolerate additions. Exactness here is what makes the Gate H
    equality assertions meaningful.
    """
    if not isinstance(envelope, ProgressEnvelope):
        raise TypeError(
            f"expected a ProgressEnvelope, got {type(envelope).__name__}"
        )
    document = to_dict(envelope.state)
    document[ST_STATE_VERSION] = STATE_VERSION_V1_1
    document[ST_CANCELLATION_STATE] = envelope.cancellation.state.value
    document[ST_TERMINAL_OUTCOME] = (
        None if envelope.terminal_outcome is None else envelope.terminal_outcome.value
    )
    # Re-validated as a 1.1 document, so an illegal state/outcome pairing is
    # caught on the way out rather than by whoever receives it.
    _validate(document)
    return document


def envelope_to_json(envelope: ProgressEnvelope, **kwargs: Any) -> str:
    """Serialise ``envelope`` as strict JSON. ``allow_nan`` is reserved."""
    if "allow_nan" in kwargs:
        raise TypeError(
            "allow_nan is reserved by envelope_to_json(); non-finite values are "
            "rejected by envelope_to_dict() and cannot be emitted"
        )
    return json.dumps(envelope_to_dict(envelope), allow_nan=False, **kwargs)


def envelope_from_dict(document: Mapping[str, Any]) -> ProgressEnvelope:
    """Rebuild a :class:`ProgressEnvelope` from any supported ``1.x`` document.

    A v1.0 document predates cancellation, so it is read as active work with no
    terminal outcome. That is a statement about the schema, not a guess about
    the operation: a producer that could not express cancellation cannot have
    been reporting one.
    """
    if not isinstance(document, Mapping):
        raise TypeError(
            f"expected a mapping, got {type(document).__name__}"
        )
    _, minor = _validate(document)
    state = _state_from(document)

    if minor == 0:
        return ProgressEnvelope(
            state=state, cancellation=ACTIVE_STATUS, terminal_outcome=None
        )

    status = CancellationStatus(
        _enum_from_wire(
            document[ST_CANCELLATION_STATE], CancellationState, ST_CANCELLATION_STATE
        )
    )
    raw_outcome = document[ST_TERMINAL_OUTCOME]
    outcome = (
        None
        if raw_outcome is None
        else _enum_from_wire(raw_outcome, TerminalOutcome, ST_TERMINAL_OUTCOME)
    )
    return ProgressEnvelope(
        state=state, cancellation=status, terminal_outcome=outcome
    )
