"""Tkinter adapter for :class:`ThermometerCore`.

THERM-SPEC-002 rev C section 4. Imported explicitly and never from
``pythermx/__init__.py``: Tkinter is packaged separately on several Linux
distributions and omitted from minimal container images, and ``import pythermx``
must keep working without it.

**This adapter creates no threads.** ``AutoRefresh`` needed a timer thread
because a caller blocked in I/O has no event loop to borrow; Tk *is* an event
loop, so ``after()`` suffices. No daemon thread, no bounded join, no shared
write lock, and none of the hazard class section 6.1 was written to contain.

Two supported integration patterns:

**Pattern 1** - the consumer already owns a worker and a queue. It translates
its own events on the UI thread and drives the widget directly, never touching
:class:`TkThermometerChannel`. Nothing is passed into service work because this
module supplies nothing at that layer.

**Pattern 2** - the consumer has no event plumbing. ``live()`` yields a channel
whose commands carry only immutable scalars or a frozen :class:`PhaseSpec`, so a
worker cannot reach the deliberately non-thread-safe model at all. Model
construction and mutation happen only on the UI thread, inside the pump.
"""

from __future__ import annotations

import math
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk
from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from typing import Any, Callable, Optional

from .cancellation import CancellationSource, CancellationState
from .estimation import ProgressEstimate, ProgressEstimator
from .presentation import (
    LEXICON_DEFAULTS,
    format_count,
    format_percent,
    merge_lexicon,
    normalize_locale,
)
from .thermometer_core import ThermometerCore, ThermometerState
from .thermometer_fields import MODE_INDETERMINATE

__all__ = [
    "CancelControlStyle",
    "PhaseSpec",
    "TkThermometer",
    "TkThermometerChannel",
    "TkThermometerStyle",
    "compose_status",
    "resolve_cancel_placement",
]

DEFAULT_QUEUE_CAPACITY = 10_000
DEFAULT_DRAIN_BUDGET = 256
DEFAULT_PUMP_INTERVAL_MS = 40

# Public configuration vocabulary. Strings rather than an Enum so a consumer
# can load the values directly from its own TOML/JSON/application settings.
CANCEL_BUTTON_TEXT = "Cancel"
CANCEL_VISIBILITIES = frozenset({"hidden", "while_active", "always"})
CANCEL_PLACEMENTS = frozenset({"auto", "left", "right", "below"})
STATUS_POSITIONS = frozenset({"above", "below", "hidden"})
STATUS_ALIGNMENTS = frozenset({"left", "center", "right"})
MARQUEE_MOTIONS = frozenset({"animated", "reduced"})


# ---------------------------------------------------------------------------
# Value types
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class PhaseSpec:
    """An immutable request to begin a new phase.

    A live ``ThermometerCore`` must never cross the channel: it is mutable and
    deliberately not thread-safe, so a worker could post one and keep mutating
    it afterwards. This carries the description instead, and the pump builds the
    model on the UI thread.
    """

    total: Optional[float] = None
    label: Optional[str] = None
    unit: Optional[str] = None
    phase: Optional[str] = None
    current: float = 0.0


@dataclass(frozen=True)
class Palette:
    background: str = "#141414"
    track: str = "#2B2B2B"
    fill: str = "#00C853"
    marquee: str = "#2979FF"
    text: str = "#E6E6E6"


@dataclass(frozen=True)
class CancelControlStyle:
    """Presentation policy for the optional Tk Cancel button.

    ``visibility`` is ``"hidden"``, ``"while_active"`` or ``"always"``.
    A while-active button remains present but disabled during the requested
    and cancelling states, avoiding a geometry jump while a worker unwinds;
    it is removed only when the widget reaches a terminal outcome.

    ``placement="auto"`` keeps the button beside the thermometer when there
    is room and stacks it below when the parent narrows. The source is still a
    constructor argument on :class:`TkThermometer`: presentation must never
    manufacture workflow control.
    """

    visibility: str = "hidden"
    placement: str = "auto"
    text: str = CANCEL_BUTTON_TEXT
    gap: int = 8
    min_width_chars: int = 10


@dataclass(frozen=True)
class TkThermometerStyle:
    """Presentation and pump settings. Validated once at construction."""

    # ``width`` and ``height`` retain their established meaning and defaults.
    # The new settings make width a preferred logical size: constrained
    # parents may shrink it to ``minimum_width`` and ``stretch=True`` also
    # lets it consume additional horizontal space.
    width: int = 760
    height: int = 64
    minimum_width: int = 180
    stretch: bool = False
    bar_thickness: int = 24
    padding: int = 10
    status_position: str = "above"
    status_alignment: str = "left"
    show_percent: bool = True
    show_value: bool = True
    show_count: bool = True
    show_label: bool = True
    show_elapsed: bool = False
    show_rate: bool = False
    show_eta: bool = False
    count_format: str = "{:,.0f}"
    unit: Optional[str] = None
    promoted_separator: str = "-"
    locale: str = "en-US"
    percent_precision: int = 1
    value_separator: str = "/"
    field_separator: str = " | "
    elapsed_suffix: str = "s"
    rate_suffix: str = "/s"
    eta_prefix: str = "ETA "
    lexicon: Mapping[str, str] = field(
        default_factory=lambda: merge_lexicon(LEXICON_DEFAULTS)
    )
    marquee_fraction: float = 0.28
    marquee_period_s: float = 1.6
    pump_interval_ms: int = DEFAULT_PUMP_INTERVAL_MS
    drain_budget: int = DEFAULT_DRAIN_BUDGET
    queue_capacity: int = DEFAULT_QUEUE_CAPACITY
    palette: Palette = Palette()
    cancel: CancelControlStyle = CancelControlStyle()
    # ``reduced`` keeps indeterminate and cancelling activity visible without
    # moving it. Automatic OS preference discovery belongs to the application.
    marquee_motion: str = "animated"


def _positive_int(value: Any, default: int) -> int:
    # bool is an int in Python, so queue_capacity=True would become 1.
    if isinstance(value, bool) or not isinstance(value, int):
        return default
    return value if value > 0 else default


def _positive_float(value: Any, default: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return default
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        return default
    return value


def _nonnegative_int(value: Any, default: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        return default
    return value if value >= 0 else default


def _choice(value: Any, choices: frozenset[str], default: str) -> str:
    return value if isinstance(value, str) and value in choices else default


def sanitize_cancel_style(style: Any) -> CancelControlStyle:
    """Return a deterministic, usable Cancel-control configuration."""
    if not isinstance(style, CancelControlStyle):
        return CancelControlStyle()
    text = style.text if isinstance(style.text, str) and style.text else CANCEL_BUTTON_TEXT
    return replace(
        style,
        visibility=_choice(style.visibility, CANCEL_VISIBILITIES, "hidden"),
        placement=_choice(style.placement, CANCEL_PLACEMENTS, "auto"),
        text=text,
        gap=_nonnegative_int(style.gap, 8),
        min_width_chars=_positive_int(style.min_width_chars, 10),
    )


def sanitize_style(style: TkThermometerStyle) -> TkThermometerStyle:
    """Fall back to documented defaults for any invalid setting.

    Safety behaviour, not cosmetics. ``queue.Queue(maxsize=0)`` is *unbounded*,
    so a ``queue_capacity`` of 0 would silently defeat the memory bound this
    setting exists to provide; ``drain_budget=0`` would accept commands and
    never apply them.
    """
    fraction = style.marquee_fraction
    if (
        isinstance(fraction, bool)
        or not isinstance(fraction, (int, float))
        or not math.isfinite(fraction)
        or not 0.0 < float(fraction) < 1.0
    ):
        fraction = 0.28

    count_format = style.count_format
    try:
        count_format.format(1234.0)
    except (AttributeError, IndexError, KeyError, TypeError, ValueError):
        count_format = "{:,.0f}"

    separator = style.promoted_separator
    if not isinstance(separator, str) or not separator:
        separator = "-"

    minimum_width = _positive_int(style.minimum_width, 180)
    preferred_width = _positive_int(style.width, 760)
    preferred_width = max(preferred_width, minimum_width)

    return replace(
        style,
        width=preferred_width,
        height=_positive_int(style.height, 64),
        minimum_width=minimum_width,
        stretch=bool(style.stretch),
        bar_thickness=_positive_int(style.bar_thickness, 24),
        padding=_nonnegative_int(style.padding, 10),
        status_position=_choice(style.status_position, STATUS_POSITIONS, "above"),
        status_alignment=_choice(style.status_alignment, STATUS_ALIGNMENTS, "left"),
        show_percent=bool(style.show_percent),
        show_value=bool(style.show_value),
        show_count=bool(style.show_count),
        show_label=bool(style.show_label),
        show_elapsed=bool(style.show_elapsed),
        show_rate=bool(style.show_rate),
        show_eta=bool(style.show_eta),
        count_format=count_format,
        promoted_separator=separator,
        locale=normalize_locale(style.locale),
        percent_precision=(
            max(0, min(20, int(style.percent_precision)))
            if isinstance(style.percent_precision, int)
            else 1
        ),
        value_separator=(
            style.value_separator if isinstance(style.value_separator, str) else "/"
        ),
        field_separator=(
            style.field_separator
            if isinstance(style.field_separator, str)
            else " | "
        ),
        elapsed_suffix=(
            style.elapsed_suffix if isinstance(style.elapsed_suffix, str) else "s"
        ),
        rate_suffix=(
            style.rate_suffix if isinstance(style.rate_suffix, str) else "/s"
        ),
        eta_prefix=(
            style.eta_prefix if isinstance(style.eta_prefix, str) else "ETA "
        ),
        lexicon=merge_lexicon(style.lexicon),
        marquee_fraction=float(fraction),
        marquee_period_s=_positive_float(style.marquee_period_s, 1.6),
        pump_interval_ms=_positive_int(style.pump_interval_ms, DEFAULT_PUMP_INTERVAL_MS),
        drain_budget=_positive_int(style.drain_budget, DEFAULT_DRAIN_BUDGET),
        queue_capacity=_positive_int(style.queue_capacity, DEFAULT_QUEUE_CAPACITY),
        cancel=sanitize_cancel_style(style.cancel),
        marquee_motion=_choice(style.marquee_motion, MARQUEE_MOTIONS, "animated"),
    )


# ---------------------------------------------------------------------------
# Geometry and text - pure, so they are testable without a display
# ---------------------------------------------------------------------------

def resolve_cancel_placement(
    requested: str,
    *,
    available_width: int,
    preferred_bar_width: int,
    button_width: int,
    gap: int,
) -> str:
    """Resolve responsive Cancel placement without consulting Tk.

    An explicit placement is returned unchanged. ``auto`` chooses ``right``
    only when the preferred thermometer and button fit side by side; otherwise
    it chooses ``below``. The same rule therefore behaves predictably under
    Windows, Linux and macOS without branching on an operating-system name.
    """
    if requested in {"left", "right", "below"}:
        return requested
    required = max(0, preferred_bar_width) + max(0, button_width) + max(0, gap)
    return "right" if max(0, available_width) >= required else "below"


def determinate_span(percent: float, left: float, right: float) -> tuple[float, float]:
    percent = max(0.0, min(100.0, percent))
    return left, left + (right - left) * (percent / 100.0)


def marquee_span(
    elapsed_s: float, left: float, right: float, fraction: float, period_s: float
) -> tuple[float, float]:
    """Slide a fixed-width block, derived from elapsed time.

    Position comes from the clock rather than a frame counter, so it animates on
    any redraw schedule and never implies progress that has not happened.
    """
    track = right - left
    block = track * fraction
    travel = track - block
    if travel <= 0:
        return left, right
    phase = (elapsed_s % period_s) / period_s
    offset = (1.0 - abs(2.0 * phase - 1.0)) * travel      # triangle wave
    return left + offset, left + offset + block


def activity_span(
    elapsed_s: float,
    left: float,
    right: float,
    fraction: float,
    period_s: float,
    motion: str,
) -> tuple[float, float]:
    """Return animated or reduced-motion activity geometry.

    Reduced motion uses the same fixed block width as the marquee but centers
    it permanently. Status text still communicates the indeterminate or
    cancelling state, so the stationary block is activity—not a percentage.
    """
    if motion != "reduced":
        return marquee_span(elapsed_s, left, right, fraction, period_s)
    track = right - left
    block = track * fraction
    if block >= track:
        return left, right
    offset = (track - block) / 2.0
    return left + offset, left + offset + block


def compose_status(
    snapshot: ThermometerState,
    style: TkThermometerStyle,
    estimate: Optional[ProgressEstimate] = None,
) -> str:
    """Compose the status line in the CLI renderer's field order."""
    unit = style.unit if style.unit is not None else snapshot.unit
    suffix = f" {unit}" if unit else ""
    parts: list[str] = []

    if snapshot.percent is not None and snapshot.total is not None:
        if style.show_percent:
            parts.append(
                format_percent(
                    snapshot.percent,
                    style.percent_precision,
                    style.locale,
                )
            )
        if style.show_value:
            current = format_count(snapshot.current, style.count_format, style.locale)
            total = format_count(snapshot.total, style.count_format, style.locale)
            value = f"{current}{style.value_separator}{total}"
            if snapshot.promoted_from is not None:
                found = format_count(
                    snapshot.promoted_from,
                    style.count_format,
                    style.locale,
                )
                value = (
                    f"{found}{suffix} {style.lexicon['found']} "
                    f"{style.promoted_separator} {value}"
                )
            parts.append(value)
    elif style.show_count:
        parts.append(
            format_count(snapshot.current, style.count_format, style.locale) + suffix
        )

    label = snapshot.phase or snapshot.label
    if style.show_label and label:
        parts.append(str(label))

    if style.show_elapsed:
        parts.append(f"{snapshot.elapsed_s:.1f}{style.elapsed_suffix}")
    if style.show_rate and snapshot.elapsed_s > 0:
        rate = format_count(
            snapshot.current / snapshot.elapsed_s,
            style.count_format,
            style.locale,
        )
        parts.append(
            rate
            + (
                f" {unit}{style.rate_suffix}"
                if unit
                else style.rate_suffix
            )
        )
    if style.show_eta and estimate is not None and estimate.eta_s is not None:
        parts.append(
            f"{style.eta_prefix}{estimate.eta_s:.{style.percent_precision}f}"
            f"{style.elapsed_suffix}"
        )

    return style.field_separator.join(parts)


# ---------------------------------------------------------------------------
# Channel
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class _Command:
    kind: str
    args: tuple = ()
    kwargs: tuple = ()          # tuple of pairs, so the command stays hashable


#: The cancellation boundary marker. Not a state mutation - it carries no
#: effect, it only tells the pump where the pre-cancellation stream ends.
_BARRIER = "\x00barrier"

#: Product vocabulary, ratified by Ringo (THERM-ANALYSIS-008). Constants rather
#: than literals at the call sites so the strings have one definition.
CANCEL_STATUS_TEXT = {
    CancellationState.REQUESTED: "Cancellation requested...",
    CancellationState.CANCELLING: "Cancelling...",
    CancellationState.CANCELLED: "Cancelled",
}


class TkThermometerChannel:
    """The worker-facing posting surface for Pattern 2.

    Belongs to exactly one ``live()`` generation and closes permanently when
    that generation exits, so a slow producer from an earlier run cannot post
    into a later one. Every method returns ``True`` when the command was
    accepted and ``False`` when it was not; none raises, because a producer
    should not crash on a race it cannot see.
    """

    def __init__(self, capacity: int) -> None:
        self._queue: queue.Queue = queue.Queue(maxsize=capacity)
        # One lock covers the acceptance flag *and* the enqueue, so the two
        # cannot be observed out of order. Without it "pre-barrier" is not
        # decidable: a producer could pass the acceptance check, be descheduled,
        # and enqueue after the barrier was placed - so a command accepted
        # before cancellation would land after it (THERM-A008-09).
        #
        # Not a contradiction of "the adapter creates no threads". It creates
        # none; it is *posted to* by threads the caller owns, and that is
        # exactly what needs synchronising.
        self._lock = threading.Lock()
        self._closed = False
        self._accepting = True
        self._barrier_placed = False

    # -- lifecycle (UI thread) -------------------------------------------

    def close(self) -> None:
        """Close permanently and release any commands still queued."""
        with self._lock:
            self._closed = True
            self._accepting = False
        while True:
            try:
                self._queue.get_nowait()
            except queue.Empty:
                break

    @property
    def closed(self) -> bool:
        with self._lock:
            return self._closed

    @property
    def accepting(self) -> bool:
        """False once cancellation has closed the channel to ordinary commands."""
        with self._lock:
            return self._accepting

    @property
    def barrier_placed(self) -> bool:
        with self._lock:
            return self._barrier_placed

    def place_cancellation_barrier(self) -> bool:
        """Stop accepting ordinary commands and mark the boundary. UI thread.

        Returns True if this call placed the barrier. Idempotent, and a no-op
        on an already-closed channel.

        The marker is enqueued under the same lock that closes acceptance, so
        everything the pump reads before it was accepted before cancellation.
        A full queue cannot take the marker; acceptance is closed regardless, so
        the pump treats "not accepting and drained" as the same boundary.
        """
        with self._lock:
            if not self._accepting or self._closed:
                return False
            self._accepting = False
            self._barrier_placed = True
            try:
                self._queue.put_nowait(_Command(_BARRIER))
            except queue.Full:
                pass
            return True

    def qsize(self) -> int:
        return self._queue.qsize()

    # -- posting (any thread) --------------------------------------------

    def _post(self, kind: str, *args: Any, **kwargs: Any) -> bool:
        command = _Command(kind, args, tuple(sorted(kwargs.items())))
        with self._lock:
            if not self._accepting:
                return False
            try:
                self._queue.put_nowait(command)
            except queue.Full:
                return False
            return True

    def post_begin(self, spec: PhaseSpec) -> bool:
        if not isinstance(spec, PhaseSpec):
            raise TypeError("post_begin() requires a PhaseSpec; a live model must not cross the channel")
        return self._post("begin", spec)

    def post_increment(self, delta: float = 1.0) -> bool:
        return self._post("increment", delta)

    def post_update(self, value: float) -> bool:
        return self._post("update", value)

    def post_promote(self, total: float, *, current: float = 0.0, phase: Optional[str] = None) -> bool:
        return self._post("promote", total, current=current, phase=phase)

    def post_reset(self) -> bool:
        return self._post("reset")

    def post_set_total(self, total: float) -> bool:
        return self._post("set_total", total)

    def post_set_label(self, label: Optional[str]) -> bool:
        return self._post("set_label", label)

    def post_set_unit(self, unit: Optional[str]) -> bool:
        return self._post("set_unit", unit)

    def post_set_phase(self, phase: Optional[str]) -> bool:
        return self._post("set_phase", phase)

    def post_message(self, text: str) -> bool:
        return self._post("message", text)


class _Live:
    """Context manager for one pump generation."""

    def __init__(self, widget: "TkThermometer") -> None:
        self._widget = widget
        self._channel: Optional[TkThermometerChannel] = None

    def __enter__(self) -> TkThermometerChannel:
        self._channel = self._widget._start_live()
        return self._channel

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        self._widget._stop_live()
        if exc_type is not None:
            # The body's exception is always primary. A latched pump error is
            # not discarded - it stays latched and surfaces from the next
            # UI-thread render(), tick() or finish().
            return False
        self._widget._raise_pump_error()
        return False


# ---------------------------------------------------------------------------
# Widget
# ---------------------------------------------------------------------------

class TkThermometer(tk.Frame):
    """Render a PyThermX snapshot in either mode."""

    def __init__(
        self,
        master: tk.Misc,
        model: ThermometerCore,
        *,
        style: TkThermometerStyle = TkThermometerStyle(),
        clock: Callable[[], float] = time.monotonic,
        show_cancel: Optional[bool] = None,
        cancellation_source: Optional[CancellationSource] = None,
        estimator: Optional[ProgressEstimator] = None,
    ) -> None:
        self._style = sanitize_style(style)
        control = self._style.cancel
        # ``show_cancel`` is the 0.4.0 compatibility surface. Omitted callers
        # use the structured style; an explicit bool still wins. The original
        # True layout stacked the button below, so the untouched legacy call
        # retains that geometry while a configured control may choose auto.
        if show_cancel is True:
            legacy_defaults = control == CancelControlStyle()
            control = replace(
                control,
                visibility=(
                    "while_active"
                    if control.visibility == "hidden"
                    else control.visibility
                ),
                placement="below" if legacy_defaults else control.placement,
            )
        elif show_cancel is False:
            control = replace(control, visibility="hidden")
        self._cancel_style = control
        super().__init__(master, bg=self._style.palette.background)

        if not callable(clock):
            raise TypeError("clock must be callable")
        if cancellation_source is not None and not isinstance(
            cancellation_source, CancellationSource
        ):
            raise TypeError(
                "cancellation_source must be a CancellationSource, got "
                f"{type(cancellation_source).__name__}"
            )
        # The renderer does not own workflow control. A button that
        # manufactured its own source would hand the worker no way to obtain
        # the matching token, so the cancel would signal nothing.
        if self._cancel_style.visibility != "hidden" and cancellation_source is None:
            raise ValueError(
                "a visible Cancel button requires an explicit "
                "cancellation_source; the widget does not own the workflow, "
                "so it cannot create one the worker could poll"
            )

        self._clock = clock
        self._model = model
        self._finished = False
        self._channel: Optional[TkThermometerChannel] = None
        self._pump_token: Optional[str] = None
        self._pump_error: Optional[BaseException] = None
        self._message = ""
        self._cancel_source = cancellation_source
        self._estimator = (
            estimator
            if estimator is not None
            else ProgressEstimator()
            if self._style.show_eta
            else None
        )
        self._cancel_state: Optional[CancellationState] = (
            None if cancellation_source is None else CancellationState.ACTIVE
        )
        self._cancel_button: Optional[ttk.Button] = None
        self._show_cancel = self._cancel_style.visibility != "hidden"
        # Empty is an internal, one-shot sentinel.  ``None`` is the resolved
        # placement when cancellation is hidden, so initializing with None
        # made the first layout look unchanged and left the canvas ungridded.
        self._cancel_placement: Optional[str] = ""

        palette = self._style.palette
        self._canvas = tk.Canvas(
            self,
            width=self._style.width,
            height=self._style.height,
            bg=palette.background,
            highlightthickness=0,
        )

        self._left = self._style.padding
        self._right = self._style.width - self._style.padding
        self._top = self._style.height - self._style.padding - self._style.bar_thickness
        self._bottom = self._style.height - self._style.padding

        self._track = self._canvas.create_rectangle(
            self._left, self._top, self._right, self._bottom,
            # The track fill is intentionally subdued, but it cannot also be
            # the component boundary: the factory track/background pair is
            # only 1.30:1.  The status-text colour supplies a distinct outline
            # while the fill and marquee retain their contrast against the
            # track itself.
            fill=palette.track, outline=palette.text,
        )
        self._bar = self._canvas.create_rectangle(
            self._left, self._top, self._left, self._bottom,
            fill=palette.fill, outline=palette.fill,
        )
        self._status = self._canvas.create_text(
            self._left, self._style.padding, anchor="nw", fill=palette.text,
            text="", font="TkFixedFont",
        )

        # Opt-in, because it changes the widget's geometry: an existing layout
        # that packed a 0.3.x thermometer must not resize on upgrade.
        if self._show_cancel:
            self._cancel_button = ttk.Button(
                self,
                text=self._cancel_style.text,
                width=self._cancel_style.min_width_chars,
                command=self.request_cancel,
            )

        # Grid is private to the component; the caller still places this whole
        # frame with pack/grid/place. Configure events make only the internal
        # arrangement responsive.
        initial_width = self._style.width
        if self._cancel_button is not None:
            initial_width += self._cancel_button.winfo_reqwidth() + self._cancel_style.gap
        self._layout_controls(available_width=initial_width)
        self._reflow_canvas(self._style.width, self._style.height)
        self.bind("<Configure>", self._on_container_configure, add="+")
        self._canvas.bind("<Configure>", self._on_canvas_configure, add="+")

        self.render()

    # -- component layout ----------------------------------------------

    @property
    def cancel_placement(self) -> Optional[str]:
        """The currently resolved placement, or None when no button exists."""
        return self._cancel_placement

    def _cancel_should_be_mapped(self) -> bool:
        if self._cancel_button is None:
            return False
        return not (
            self._cancel_style.visibility == "while_active" and self._finished
        )

    def _layout_controls(self, *, available_width: int) -> None:
        button = self._cancel_button
        if button is None:
            placement = None
            button_width = 0
        else:
            button_width = button.winfo_reqwidth()
            placement = resolve_cancel_placement(
                self._cancel_style.placement,
                available_width=available_width,
                preferred_bar_width=self._style.width,
                button_width=button_width,
                gap=self._cancel_style.gap,
            )

        if placement != self._cancel_placement:
            self._canvas.grid_forget()
            if button is not None:
                button.grid_forget()
            for index in (0, 1):
                self.grid_columnconfigure(index, weight=0, minsize=0)
                self.grid_rowconfigure(index, weight=0, minsize=0)

            canvas_sticky = "ew" if self._style.stretch else "w"
            if placement == "left":
                button.grid(row=0, column=0, padx=(0, self._cancel_style.gap))
                self._canvas.grid(row=0, column=1, sticky=canvas_sticky)
                self.grid_columnconfigure(1, weight=1 if self._style.stretch else 0)
            elif placement == "right":
                self._canvas.grid(row=0, column=0, sticky=canvas_sticky)
                button.grid(row=0, column=1, padx=(self._cancel_style.gap, 0))
                self.grid_columnconfigure(0, weight=1 if self._style.stretch else 0)
            elif placement == "below":
                self._canvas.grid(row=0, column=0, sticky=canvas_sticky)
                button.grid(row=1, column=0, pady=(self._cancel_style.gap, 0))
                self.grid_columnconfigure(0, weight=1 if self._style.stretch else 0)
            else:
                self._canvas.grid(row=0, column=0, sticky=canvas_sticky)
                self.grid_columnconfigure(0, weight=1 if self._style.stretch else 0)
            self._cancel_placement = placement

        if button is not None:
            if self._cancel_should_be_mapped():
                button.grid()
            else:
                button.grid_remove()

        reserved = 0
        if placement in {"left", "right"}:
            reserved = button_width + self._cancel_style.gap
        available_for_canvas = max(1, available_width - reserved)
        if self._style.stretch:
            target_width = max(self._style.minimum_width, available_for_canvas)
        else:
            target_width = max(
                self._style.minimum_width,
                min(self._style.width, available_for_canvas),
            )
        if int(float(self._canvas.cget("width"))) != target_width:
            self._canvas.configure(width=target_width)

    def _on_container_configure(self, event: tk.Event) -> None:
        self._layout_controls(available_width=max(1, int(event.width)))

    def _on_canvas_configure(self, event: tk.Event) -> None:
        self._reflow_canvas(max(1, int(event.width)), max(1, int(event.height)))
        if not self._finished:
            self._draw(self._message)

    def _reflow_canvas(self, width: int, height: int) -> None:
        padding = min(self._style.padding, max(0, (height - 1) // 2))
        self._left = min(self._style.padding, max(0, (width - 1) // 2))
        self._right = max(self._left + 1, width - self._left)

        position = self._style.status_position
        status_space = 20 if position != "hidden" else 0
        available_bar_height = max(1, height - (2 * padding) - status_space)
        thickness = min(self._style.bar_thickness, available_bar_height)

        if position == "below":
            self._top = padding
            self._bottom = self._top + thickness
            status_y = height - padding
            vertical_anchor = "s"
        elif position == "hidden":
            self._top = max(0, (height - thickness) / 2)
            self._bottom = self._top + thickness
            status_y = 0
            vertical_anchor = "n"
        else:
            self._bottom = height - padding
            self._top = self._bottom - thickness
            status_y = padding
            vertical_anchor = "n"

        alignment = self._style.status_alignment
        if alignment == "center":
            status_x = width / 2
            horizontal_anchor = ""
        elif alignment == "right":
            status_x = width - self._left
            horizontal_anchor = "e"
        else:
            status_x = self._left
            horizontal_anchor = "w"

        anchor = vertical_anchor + horizontal_anchor
        self._canvas.coords(
            self._track, self._left, self._top, self._right, self._bottom
        )
        self._canvas.coords(self._status, status_x, status_y)
        self._canvas.itemconfigure(
            self._status,
            anchor=anchor,
            state="hidden" if position == "hidden" else "normal",
        )

    def _sync_cancel_button(self) -> None:
        button = self._cancel_button
        if button is None:
            return
        source_active = (
            self._cancel_source is not None
            and self._cancel_source.state is CancellationState.ACTIVE
        )
        button.configure(state=tk.NORMAL if source_active and not self._finished else tk.DISABLED)
        if self._cancel_should_be_mapped():
            button.grid()
        else:
            button.grid_remove()

    # -- state -----------------------------------------------------------

    @property
    def model(self) -> ThermometerCore:
        return self._model

    @property
    def style(self) -> TkThermometerStyle:
        return self._style

    @property
    def finished(self) -> bool:
        return self._finished

    def set_model(self, model: ThermometerCore) -> None:
        """Replace the displayed model. UI thread only.

        Starts a new display generation, which clears the finished state.
        """
        self._model = model
        self._finished = False
        self._message = ""
        self._sync_cancel_button()
        self.render()

    # -- rendering -------------------------------------------------------

    def render(self, *, message: str = "") -> None:
        self._raise_pump_error()
        if self._finished:
            return
        # Pattern 1 has no live() pump to observe controller transitions. A
        # caller-driven render is therefore an observation point too, so a
        # worker acknowledgement is visible regardless of integration style.
        self._observe_cancellation()
        self._draw(message or self._message)

    def tick(self, *, message: str = "") -> None:
        self.render(message=message)

    def finish(self, *, ok: bool = True, message: str = "") -> None:
        """Write one final state and end the run."""
        self._raise_pump_error()
        if self._finished:
            return
        status = self._style.lexicon["ok"] if ok else self._style.lexicon["fail"]
        self._draw(
            f"{status}{self._style.field_separator}{message}" if message else status
        )
        self._finished = True
        self._sync_cancel_button()
        self._stop_live()

    def _draw(self, message: str) -> None:
        snapshot = self._model.snapshot()
        estimate = self._estimator.observe(snapshot) if self._estimator else None
        palette = self._style.palette
        # An unwind has no known total, so `cancelling` draws a marquee even
        # for determinate work - the same honesty rule that forbids reporting
        # a percentage for work whose total is unknown. `requested` keeps the
        # real geometry frozen at the last value actually completed.
        if self._cancel_state is CancellationState.CANCELLING:
            x1, x2 = activity_span(
                snapshot.elapsed_s, self._left, self._right,
                self._style.marquee_fraction, self._style.marquee_period_s,
                self._style.marquee_motion,
            )
            self._canvas.coords(self._bar, x1, self._top, x2, self._bottom)
            self._canvas.itemconfig(
                self._bar, fill=palette.marquee, outline=palette.marquee
            )
            text = compose_status(snapshot, self._style, None)
            if message:
                text = (
                    f"{text}{self._style.field_separator}{message}" if text else message
                )
            self._canvas.itemconfig(self._status, text=text)
            return
        if snapshot.percent is None:
            x1, x2 = activity_span(
                snapshot.elapsed_s, self._left, self._right,
                self._style.marquee_fraction, self._style.marquee_period_s,
                self._style.marquee_motion,
            )
            colour = palette.marquee
        else:
            x1, x2 = determinate_span(snapshot.percent, self._left, self._right)
            colour = palette.fill
        self._canvas.coords(self._bar, x1, self._top, x2, self._bottom)
        self._canvas.itemconfig(self._bar, fill=colour, outline=colour)

        text = compose_status(snapshot, self._style, estimate)
        if message:
            text = f"{text}{self._style.field_separator}{message}" if text else message
        self._canvas.itemconfig(self._status, text=text)

    # -- pump ------------------------------------------------------------

    def live(self) -> _Live:
        """Return a context manager that runs the pump and yields a channel."""
        return _Live(self)

    def _start_live(self) -> TkThermometerChannel:
        if self._channel is not None:
            raise RuntimeError(
                "live() is already active on this widget; nesting is not supported. "
                "Reference counting was rejected: an inner context that silently "
                "does nothing, or that stops an outer one, is a bug either way."
            )
        self._channel = TkThermometerChannel(self._style.queue_capacity)
        self._schedule()
        return self._channel

    def _stop_live(self) -> None:
        if self._pump_token is not None:
            try:
                self.after_cancel(self._pump_token)
            except (tk.TclError, ValueError):
                pass
            self._pump_token = None
        if self._channel is not None:
            self._channel.close()
            self._channel = None

    def _schedule(self) -> None:
        # Reschedule even with an empty queue. Without a pending callback Tk
        # blocks in C and a pending SIGINT is not raised until some other event
        # arrives - on Windows that can be indefinitely.
        self._pump_token = self.after(self._style.pump_interval_ms, self._pump)

    def _pump(self) -> None:
        self._pump_token = None
        channel = self._channel
        if channel is None:
            return

        # Observed first, so the tick that notices cancellation is the tick
        # that seals the barrier and performs the finite drain. Observing
        # afterwards would spend one more budgeted slice on a stream that is
        # already known to be abandoned.
        moved = self._observe_cancellation()

        # State-Effect Drain. Once cancellation has closed the channel the
        # command stream is finite - nothing more can be accepted - so it is
        # drained entirely rather than in slices. Ordinary operation stays
        # bounded per tick, so a hot producer cannot starve Tk's event loop.
        #
        # The queue holds *semantic mutations*, not frames: dropping entries
        # would lose accumulated increments and whole promotions, leaving the
        # bar reporting less work than actually completed. So every command is
        # applied; only the intermediate repaints are suppressed.
        draining = not channel.accepting
        budget = None if draining else self._style.drain_budget

        applied = 0
        while budget is None or applied < budget:
            try:
                command = channel._queue.get_nowait()
            except queue.Empty:
                break
            if command.kind == _BARRIER:
                break
            try:
                self._apply(command)
            except BaseException as error:      # noqa: BLE001 - latched, not swallowed
                self._pump_error = error
                self._stop_live()
                return
            applied += 1

        # One collapsed render: the true final geometry, drawn once.
        if (applied or moved) and not self._finished:
            self._draw(self._message)
        if self._channel is not None:
            self._schedule()

    # -- cancellation ----------------------------------------------------

    def _observe_cancellation(self) -> bool:
        """Track the source's lifecycle. Returns True if the state moved.

        The UI shows only states it actually observes, so a worker that unwinds
        with nothing to clean up goes straight from "Cancellation requested..."
        to "Cancelled" without inventing a "Cancelling..." phase it was never
        in. Status is read from the source rather than posted as an ordinary
        command - cancellation is not a progress mutation, and routing it
        through the queue would put it behind the very backlog the barrier
        exists to flush.

        **The barrier is sealed here, not at the button** (THERM-A010-01).
        Cancellation belongs to the *source*, so any authorised requester -
        a menu item, a controller, a SIGINT bridge, a remote call - must close
        the channel exactly as the button does. Sealing only in
        ``request_cancel()`` made the guarantee depend on which entry point
        happened to raise the signal, and a worker went on posting progress
        while the widget displayed "Cancellation requested...".

        Sealing runs on every observation of a non-active state, not only on a
        transition. A ``live()`` generation opened *after* its source was
        already requested has a brand-new channel that has never been sealed,
        and there is no state change left to trigger it. ``place_cancellation_
        barrier()`` is idempotent, so the repeat costs one lock acquisition.
        """
        source = self._cancel_source
        if source is None:
            return False
        state = source.state
        if state is not CancellationState.ACTIVE:
            channel = self._channel
            if channel is not None:
                channel.place_cancellation_barrier()
        if state is self._cancel_state:
            return False
        self._cancel_state = state
        self._sync_cancel_button()
        text = CANCEL_STATUS_TEXT.get(state)
        if text is not None:
            self._message = text
        return True

    def request_cancel(self) -> bool:
        """Raise the cancellation signal and close the command stream.

        What the Cancel button calls. Safe to call directly - a keyboard
        shortcut or menu item is as legitimate a trigger as the button.
        """
        source = self._cancel_source
        if source is None:
            raise RuntimeError(
                "this widget has no cancellation_source; construct it with "
                "TkThermometer(..., cancellation_source=CancellationSource())"
            )
        raised = source.request()
        channel = self._channel
        if channel is not None:
            channel.place_cancellation_barrier()
        if self._cancel_button is not None:
            self._sync_cancel_button()
        self._observe_cancellation()
        if not self._finished:
            self._draw(self._message)
        return raised

    @property
    def cancellation_source(self) -> Optional[CancellationSource]:
        return self._cancel_source

    def finish_cancelled(self, *, message: str = "Cancelled") -> None:
        """End the run as a cancellation.

        Separate from ``finish(ok=...)`` rather than a third boolean on it:
        ``ok=True, cancelled=True`` is a contradiction that should not be
        expressible.
        """
        self._raise_pump_error()
        if self._finished:
            return
        self._draw(message)
        self._finished = True
        self._sync_cancel_button()
        self._stop_live()

    def _apply(self, command: _Command) -> None:
        kind, args = command.kind, command.args
        kwargs = dict(command.kwargs)
        if kind == "begin":
            spec: PhaseSpec = args[0]
            model = ThermometerCore(
                total=spec.total, label=spec.label,
                unit=spec.unit, phase=spec.phase, clock=self._clock,
            )
            # Apply current BEFORE installation, so a phase that begins at a
            # nonzero value is never displayed as zero first.
            if spec.current:
                model.update(spec.current)
            self.set_model(model)
        elif kind == "increment":
            self._model.increment(*args)
        elif kind == "update":
            self._model.update(*args)
        elif kind == "promote":
            self._model.promote(args[0], **kwargs)
        elif kind == "reset":
            self._model.reset()
        elif kind == "set_total":
            self._model.set_total(*args)
        elif kind == "set_label":
            self._model.set_label(*args)
        elif kind == "set_unit":
            self._model.set_unit(*args)
        elif kind == "set_phase":
            self._model.set_phase(*args)
        elif kind == "message":
            self._message = args[0]
        else:                                   # pragma: no cover - unreachable
            raise ValueError(f"unknown command {kind!r}")

    def _raise_pump_error(self) -> None:
        if self._pump_error is not None:
            error = self._pump_error
            self._pump_error = None
            raise error
