"""Thermometer JSON field and enum value constants.


Governance intent:
- Avoid scattered dict key string literals.
- Keep schema evolution additive (new constants appended).


This module is UI-agnostic and safe for both Tkinter and Web adapters.
"""


from __future__ import annotations


__all__ = [
    name
    for name in (
        "CONFIG_VERSION_V1_0",
        "CFG_CONFIG_VERSION",
        "CFG_MIN_VALUE",
        "CFG_MAX_VALUE",
        "CFG_MODE",
        "CFG_ORIENTATION",
        "CFG_SEGMENTS",
        "CFG_THRESHOLDS",
        "CFG_LABELS",
        "LBL_SHOW_VALUE",
        "LBL_SHOW_PERCENT",
        "SEG_START",
        "SEG_END",
        "SEG_COLOR",
        "SEG_LABEL",
        "THR_VALUE",
        "THR_COLOR",
        "THR_LABEL",
        "ST_VALUE",
        "ST_STATUS",
        "ST_MESSAGE",
        "ST_SEVERITY",
        "ST_STARTED_AT",
        "ST_UPDATED_AT",
        "ST_INDETERMINATE_PHASE",
        "MODE_DETERMINATE",
        "MODE_INDETERMINATE",
        "ORIENT_HORIZONTAL",
        "ORIENT_VERTICAL",
        "STATUS_IDLE",
        "STATUS_RUNNING",
        "STATUS_COMPLETE",
        "STATUS_ERROR",
        "SEV_OK",
        "SEV_WARN",
        "SEV_CRITICAL",
    )
]


# ==============================
# Schema versioning
# ==============================
CONFIG_VERSION_V1_0 = "1.0"


# ==============================
# Dict keys: Config
# ==============================
CFG_CONFIG_VERSION = "config_version"
CFG_MIN_VALUE = "min_value"
CFG_MAX_VALUE = "max_value"
CFG_MODE = "mode"
CFG_ORIENTATION = "orientation"
CFG_SEGMENTS = "segments"
CFG_THRESHOLDS = "thresholds"
CFG_LABELS = "labels"


# Labels sub-object
LBL_SHOW_VALUE = "show_value"
LBL_SHOW_PERCENT = "show_percent"


# Segment object keys
SEG_START = "start"
SEG_END = "end"
SEG_COLOR = "color"
SEG_LABEL = "label"


# Threshold object keys
THR_VALUE = "value"
THR_COLOR = "color"
THR_LABEL = "label"


# ==============================
# Dict keys: State
# ==============================
ST_VALUE = "value"
ST_STATUS = "status"
ST_MESSAGE = "message"
ST_SEVERITY = "severity"


# Optional additive (v1.x)
ST_STARTED_AT = "started_at"
ST_UPDATED_AT = "updated_at"
ST_INDETERMINATE_PHASE = "indeterminate_phase"


# ==============================
# Enum values (strings)
# ==============================
MODE_DETERMINATE = "determinate"
MODE_INDETERMINATE = "indeterminate"


ORIENT_HORIZONTAL = "horizontal"
ORIENT_VERTICAL = "vertical"


STATUS_IDLE = "idle"
STATUS_RUNNING = "running"
STATUS_COMPLETE = "complete"
STATUS_ERROR = "error"


SEV_OK = "ok"
SEV_WARN = "warn"
SEV_CRITICAL = "critical"


# ==============================
# Dict keys: State document (v1)
# ==============================
# Added in 0.3.0 for pythermx.serialization. The keys mirror the field names of
# ThermometerState so that the model, the renderers and the wire share one
# vocabulary. Serialising `current` as the older ST_VALUE would give one concept
# two names, which is the defect withdrawn from rev A of THERM-SPEC-001.
#
# The ST_* constants above this block predate the model and describe a shape
# that was never implemented. They remain declared and reserved.
ST_STATE_VERSION = "state_version"
ST_MODE = "mode"
ST_CURRENT = "current"
ST_TOTAL = "total"
ST_PERCENT = "percent"
ST_LABEL = "label"
ST_UNIT = "unit"
ST_PHASE = "phase"
ST_ELAPSED_S = "elapsed_s"
ST_PROMOTED_FROM = "promoted_from"

# Cancellation telemetry, added additively in schema 1.1 (0.4.0).
#
# One field, not two. An earlier draft carried both `cancel_requested` and a
# state whose value could already say `requested`, which admits documents that
# disagree with themselves. The predicate is derived from the state instead.
ST_CANCELLATION_STATE = "cancellation_state"
ST_TERMINAL_OUTCOME = "terminal_outcome"


# ==============================
# Schema versioning: State document
# ==============================
STATE_VERSION_V1_0 = "1.0"
STATE_VERSION_V1_1 = "1.1"
