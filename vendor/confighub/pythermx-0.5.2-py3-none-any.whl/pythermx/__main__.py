"""``python -m pythermx`` - ask an installed PyThermX what it is.

PyThermX is a library and ships no console script. This module exists because
version identity is central to how the project is delivered - two independent
counters, a release-contract gate, markers verified at install time - and yet
until 0.5.0 the only way to ask an installed copy its version was to write
Python. Every build record, and Gate E itself, used ``python -c "import
pythermx…"``.

``python -m`` rather than an entry point in ``[project.scripts]``: there is no
command name to reserve on ``PATH``, no launcher shim to go stale, and it works
wherever the package is importable - including a staged install where
``Scripts/`` is not on ``PATH``, which is exactly when someone wants to check.

**The version is read from :data:`pythermx.__version__` and never from
``importlib.metadata``.** That distinction is the whole design, and it is not
theoretical. ``importlib.metadata`` reports what the *distribution metadata*
said when the package was installed; an editable install whose tree has since
moved on reports the old number. Measured on the build machine immediately
after the 0.4.0 release:

    .venv     __version__=0.4.0   importlib.metadata=0.3.1   agree=False
    .venv312  __version__=0.4.0   importlib.metadata=0.4.0   agree=True
    .venv313  __version__=0.4.0   importlib.metadata=0.4.0   agree=True

So this module holds no version literal of its own and consults no cache. It is
a *reader* of the single source, which is why nothing here can drift out of step
with the package it reports on.
"""

from __future__ import annotations

import argparse
import sys

from . import __version__


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m pythermx",
        description="PyThermX - structured progress for Python.",
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="print the version and nothing else, for scripts and installers",
    )
    return parser


SUMMARY = """PyThermX {version} - structured progress for Python

  Progress that does not lie. Work with an unknown total reports no percentage
  at all, then promotes to a real one on the same bar once the total is known.
  Cancellation is cooperative: the library carries the signal and never aborts
  a worker itself.

Surfaces
  from pythermx import CLIThermometer          terminal
  from pythermx.tk import TkThermometer        Tkinter
  from pythermx import envelope_to_json        web - a document contract
  from pythermx import CancellationSource      cooperative cancellation

Try it from a project or delivery-kit checkout
  python demos/run.py --all                    every surface, unattended
  python demos/showcase.py                     every surface, on screen

Documentation in a project or delivery-kit checkout
  docs/guide.md, README.md, CHANGELOG.md
"""


def main(argv: list[str] | None = None) -> int:
    arguments = _build_parser().parse_args(argv)

    if arguments.version:
        # Bare, on stdout, with no decoration: this is the form a script or an
        # installer parses, and anything else here becomes their problem.
        print(__version__)
        return 0

    print(SUMMARY.format(version=__version__), end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
