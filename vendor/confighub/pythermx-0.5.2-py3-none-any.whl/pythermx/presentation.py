"""Portable presentation primitives shared by PyThermX renderers.

The helpers are deliberately independent of :mod:`locale`: changing the
process locale is global, thread-hostile state.  The compact BCP-47 handling
below covers the profiles demonstrated by both ThermX implementations while
leaving unfamiliar locales in the stable ``en-US`` representation.
"""

from __future__ import annotations

from types import MappingProxyType
from typing import Any, Mapping


LEXICON_DEFAULTS: Mapping[str, str] = MappingProxyType(
    {
        "ok": "OK",
        "fail": "FAIL",
        "cancelled": "CANCELLED",
        "found": "found",
    }
)


def merge_lexicon(value: Mapping[str, Any] | None) -> Mapping[str, str]:
    """Return an immutable, field-limited terminology mapping."""

    merged = dict(LEXICON_DEFAULTS)
    if value is not None:
        for key in LEXICON_DEFAULTS:
            if key in value:
                merged[key] = str(value[key])
    return MappingProxyType(merged)


def normalize_locale(value: Any) -> str:
    """Normalize a profile locale without consulting process-global state."""

    if not isinstance(value, str) or not value.strip():
        return "en-US"
    return value.strip().replace("_", "-")


def localize_number_text(text: str, locale: str) -> str:
    """Apply the separators used by the shared demonstration locales."""

    language = normalize_locale(locale).split("-", 1)[0].lower()
    if language == "de":
        return text.replace(",", "\x00").replace(".", ",").replace("\x00", ".")
    if language == "fr":
        return text.replace(",", "\u202f").replace(".", ",")
    return text


def format_count(value: float, pattern: str, locale: str) -> str:
    """Format one count with a validated Python format string and locale."""

    try:
        rendered = pattern.format(value)
    except (AttributeError, IndexError, KeyError, TypeError, ValueError):
        rendered = "{:,.0f}".format(value)
    return localize_number_text(rendered, locale)


def format_percent(value: float, precision: int, locale: str) -> str:
    """Format a clamped percentage using the shared precision contract."""

    safe_precision = max(0, min(20, int(precision)))
    rendered = f"{max(0.0, min(100.0, value)):6.{safe_precision}f}%"
    return localize_number_text(rendered, locale)


__all__ = [
    "LEXICON_DEFAULTS",
    "format_count",
    "format_percent",
    "localize_number_text",
    "merge_lexicon",
    "normalize_locale",
]
