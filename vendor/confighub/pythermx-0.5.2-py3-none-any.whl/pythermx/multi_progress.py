"""Concurrent multi-row terminal rendering for PyThermX."""

from __future__ import annotations

import sys
import threading
import time
from collections.abc import Callable, Mapping
from typing import Any, IO, Optional

from .cancellation import (
    CancellationSource,
    CancellationState,
    TerminalOutcome,
)
from .config import resolve_cli_style
from .estimation import ProgressEstimator
from .thermometer_cli import CLIThermometer, CLIThermometerStyle
from .thermometer_core import ThermometerCore

__all__ = ["CLIMultiProgress", "MultiProgressTask"]


class _NullStream:
    def isatty(self) -> bool:
        return False

    def write(self, _text: str) -> int:
        return 0

    def flush(self) -> None:
        return None


class MultiProgressTask:
    """One independently controlled row in :class:`CLIMultiProgress`."""

    def __init__(
        self,
        owner: "CLIMultiProgress",
        task_id: str,
        *,
        total: Optional[float] = None,
        label: Optional[str] = None,
        unit: Optional[str] = None,
        phase: Optional[str] = None,
        model: Optional[ThermometerCore] = None,
        source: Optional[CancellationSource] = None,
        style: CLIThermometerStyle | Mapping[str, Any] | None = None,
        estimator: Optional[ProgressEstimator] = None,
        estimation: Optional[Mapping[str, Any]] = None,
        message: str = "",
    ) -> None:
        self._owner = owner
        self.id = task_id
        self.model = model or ThermometerCore(
            total,
            label if label is not None else task_id,
            unit=unit,
            phase=phase,
            clock=owner._clock,
        )
        self.source = source or CancellationSource()
        self.token = self.source.token
        if style is None:
            self.style = owner._style
        elif isinstance(style, CLIThermometerStyle):
            self.style = style
        elif isinstance(style, Mapping):
            self.style = owner._style.with_options(**dict(style))
        else:
            raise TypeError("style must be CLIThermometerStyle or a mapping")
        selected_estimation = dict(owner._estimation)
        selected_estimation.update(dict(estimation or {}))
        self.estimator = estimator or ProgressEstimator(**selected_estimation)
        self.message = str(message)
        self.terminal_outcome: Optional[TerminalOutcome] = None
        self.finished = False
        self._renderer = CLIThermometer(
            self.model,
            style=self.style,
            stream=_NullStream(),
            clock=owner._clock,
            estimator=self.estimator,
        )

    def update(self, value: float, message: Optional[str] = None) -> "MultiProgressTask":
        self._ensure_active()
        self.model.update(value)
        if message is not None:
            self.message = message
        self._owner.render()
        return self

    def increment(
        self, delta: float = 1.0, message: Optional[str] = None
    ) -> "MultiProgressTask":
        self._ensure_active()
        self.model.increment(delta)
        if message is not None:
            self.message = message
        self._owner.render()
        return self

    def promote(
        self,
        total: float,
        *,
        current: float = 0.0,
        phase: Optional[str] = None,
        message: Optional[str] = None,
    ) -> "MultiProgressTask":
        self._ensure_active()
        self.model.promote(total, current=current, phase=phase)
        if message is not None:
            self.message = message
        self._owner.render()
        return self

    def reset(self, message: str = "") -> "MultiProgressTask":
        if self.finished:
            raise RuntimeError(f"multi-progress task {self.id!r} is finished")
        self.model.reset()
        self.estimator.reset()
        self.message = message
        self._owner.render()
        return self

    def request_cancel(self, message: str = "Cancellation requested") -> bool:
        if self.finished:
            return False
        changed = self.source.request()
        if changed:
            self.message = message
        self._owner.render()
        return changed

    def acknowledge_cancellation(self, message: str = "Cancelling") -> bool:
        if self.finished:
            return False
        changed = self.token.acknowledge()
        if changed:
            self.message = message
        self._owner.render()
        return changed

    def finish(self, *, ok: bool = True, message: str = "") -> bool:
        if self.finished:
            return False
        self.finished = True
        self.terminal_outcome = (
            TerminalOutcome.COMPLETED if ok else TerminalOutcome.FAILED
        )
        status = self.style.lexicon["ok"] if ok else self.style.lexicon["fail"]
        self.message = (
            f"{status}{self.style.field_separator}{message}" if message else status
        )
        self._owner.render(force=True)
        return True

    def fail(self, error: object) -> bool:
        return self.finish(ok=False, message=str(error))

    def finish_cancelled(self, message: str = "") -> bool:
        if self.finished:
            return False
        self.token.complete()
        self.finished = True
        self.terminal_outcome = TerminalOutcome.CANCELLED
        status = self.style.lexicon["cancelled"]
        self.message = (
            f"{status}{self.style.field_separator}{message}" if message else status
        )
        self._owner.render(force=True)
        return True

    def remove(self) -> bool:
        return self._owner.remove_task(self.id)

    def snapshot(self) -> Mapping[str, Any]:
        state = self.model.snapshot()
        return {
            "id": self.id,
            "state": state,
            "cancellation": self.source.status,
            "terminal_outcome": self.terminal_outcome,
            "message": self.message,
            "estimate": self.estimator.estimate(state),
            "finished": self.finished,
        }

    def _line(self) -> str:
        return self._renderer._fit_inline_line(
            self._renderer._build_line(message=self.message)
        )

    def _ensure_active(self) -> None:
        if self.finished:
            raise RuntimeError(f"multi-progress task {self.id!r} is finished")
        self.token.raise_if_requested()


class CLIMultiProgress:
    """Render several independent ThermX models as one terminal block."""

    def __init__(
        self,
        *,
        stream: Optional[IO[str]] = None,
        clock: Callable[[], float] = time.monotonic,
        style: CLIThermometerStyle | Mapping[str, Any] | None = None,
        estimation: Optional[Mapping[str, Any]] = None,
        task_separator: str = " | ",
        non_tty_min_interval_s: Optional[float] = None,
    ) -> None:
        if not callable(clock):
            raise TypeError("clock must be callable")
        self._stream = stream if stream is not None else sys.stderr
        self._clock = clock
        if style is None:
            self._style = CLIThermometerStyle()
        elif isinstance(style, CLIThermometerStyle):
            self._style = style
        elif isinstance(style, Mapping):
            self._style = resolve_cli_style(style)
        else:
            raise TypeError("style must be CLIThermometerStyle or a mapping")
        self._estimation = dict(estimation or {})
        self._task_separator = str(task_separator)
        self._non_tty_min_interval_s = (
            self._style.non_tty_min_interval_s
            if non_tty_min_interval_s is None
            else float(non_tty_min_interval_s)
        )
        if self._non_tty_min_interval_s < 0:
            raise ValueError("non_tty_min_interval_s cannot be negative")
        self._is_tty = bool(getattr(self._stream, "isatty", lambda: False)())
        self._tasks: dict[str, MultiProgressTask] = {}
        self._last_line_count = 0
        self._last_non_tty_print_ts: Optional[float] = None
        self._closed = False
        self._write_lock = threading.RLock()

    @property
    def size(self) -> int:
        return len(self._tasks)

    @property
    def tasks(self) -> tuple[MultiProgressTask, ...]:
        return tuple(self._tasks.values())

    @property
    def finished(self) -> bool:
        return bool(self._tasks) and all(task.finished for task in self._tasks.values())

    def add_task(self, task_id: str, **options: Any) -> MultiProgressTask:
        with self._write_lock:
            if self._closed:
                raise RuntimeError("multi-progress renderer is closed")
            if not isinstance(task_id, str) or not task_id:
                raise TypeError("task_id must be a non-empty string")
            if task_id in self._tasks:
                raise ValueError(f"duplicate multi-progress task id: {task_id}")
            task = MultiProgressTask(self, task_id, **options)
            self._tasks[task_id] = task
            self.render(force=True)
            return task

    def get_task(self, task_id: str) -> Optional[MultiProgressTask]:
        return self._tasks.get(task_id)

    def remove_task(self, task_id: str) -> bool:
        with self._write_lock:
            removed = self._tasks.pop(task_id, None) is not None
            if removed:
                self.render(force=True)
            return removed

    def render(self, *, force: bool = False) -> bool:
        with self._write_lock:
            if self._closed:
                return False
            now = float(self._clock())
            lines = [
                f"{task.id}{self._task_separator}{task._line()}"
                for task in self._tasks.values()
            ]
            if self._is_tty:
                self._render_tty(lines)
                self._stream.flush()
                return True
            if (
                not force
                and self._last_non_tty_print_ts is not None
                and now - self._last_non_tty_print_ts
                < self._non_tty_min_interval_s
            ):
                return False
            for line in lines:
                self._stream.write(line + "\n")
            self._stream.flush()
            self._last_non_tty_print_ts = now
            return True

    def _render_tty(self, lines: list[str]) -> None:
        previous = self._last_line_count
        if previous > 1:
            self._stream.write(f"\x1b[{previous - 1}A")
        if previous:
            self._stream.write("\r")
        rows = max(previous, len(lines))
        for index in range(rows):
            self._stream.write("\x1b[2K")
            if index < len(lines):
                self._stream.write(lines[index])
            if index < rows - 1:
                self._stream.write("\n")
        if rows > len(lines) and lines:
            self._stream.write(f"\x1b[{rows - len(lines)}A\r")
        self._last_line_count = len(lines)

    def auto_refresh(self, interval_s: Optional[float] = None) -> "_MultiAutoRefresh":
        return _MultiAutoRefresh(
            self,
            self._style.spinner_interval_s if interval_s is None else interval_s,
        )

    def snapshot(self) -> tuple[Mapping[str, Any], ...]:
        return tuple(task.snapshot() for task in self._tasks.values())

    def close(self) -> bool:
        with self._write_lock:
            if self._closed:
                return False
            if self._is_tty and self._last_line_count:
                self._stream.write("\n")
                self._stream.flush()
            self._last_line_count = 0
            self._closed = True
            return True

    def __enter__(self) -> "CLIMultiProgress":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        self.close()
        return False


class _MultiAutoRefresh:
    def __init__(self, renderer: CLIMultiProgress, interval_s: float) -> None:
        self._renderer = renderer
        self._interval_s = float(interval_s)
        if self._interval_s <= 0:
            raise ValueError("auto-refresh interval must be > 0")
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="pythermx-multi-refresh",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=max(0.1, self._interval_s * 2))
        self._thread = None

    close = stop

    def _run(self) -> None:
        while not self._stop.wait(self._interval_s):
            self._renderer.render()

    def __enter__(self) -> "_MultiAutoRefresh":
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        self.stop()
        return False
