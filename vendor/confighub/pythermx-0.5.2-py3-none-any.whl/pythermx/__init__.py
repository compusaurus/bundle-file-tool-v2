"""PyThermX — structured progress for Python.

The supported public API combines an interface-neutral progress model with a
terminal renderer, a Tkinter adapter (supported since 0.3.0) and a web
*document contract* — the shape of the state a renderer consumes, not a
transport.

Cooperative cancellation arrives in 0.4.0. PyThermX never forcefully aborts a
worker; it carries a signal the worker polls, and reports the interval between
the request and the unwind honestly. See :mod:`pythermx.cancellation`.

``import pythermx`` never imports Tkinter, so the package installs and runs
unchanged where Tk is absent.
"""

from __future__ import annotations

from . import adapters, cancellation, config, estimation, multi_progress, profile, serialization, thermometer_fields
from .cancellation import (
    CancellationRequested,
    CancellationSource,
    CancellationState,
    CancellationStateError,
    CancellationStatus,
    CancellationToken,
    TerminalOutcome,
)
from .config import (
    CLI_LEXICON_DEFAULTS,
    CLI_PRESETS,
    CLI_STYLE_DEFAULTS,
    PresentationResolver,
    create_presentation_resolver,
    resolve_cli_style,
)
from .thermometer_cli import CLIThermometer, CLIThermometerStyle
from .estimation import ProgressEstimate, ProgressEstimator
from .adapters import (
    ProgressAsyncIterator,
    ProgressIterator,
    ProgressRun,
    infer_total,
    run_with_progress,
    run_with_progress_async,
    track,
    track_async,
    track_file,
)
from .multi_progress import CLIMultiProgress, MultiProgressTask
from .serialization import (
    STATE_KEYS,
    STATE_KEYS_V1_0,
    STATE_KEYS_V1_1,
    ProgressEnvelope,
    UnsupportedStateVersion,
    envelope_from_dict,
    envelope_to_dict,
    envelope_to_json,
    from_dict,
    to_dict,
    to_json,
)
from .thermometer_core import ThermometerCore, ThermometerState
from .profile import (
    PROFILE_SCHEMA_VERSION,
    SUPPORTED_PROFILE_SCHEMA_VERSIONS,
    InvalidProfile,
    ProfileError,
    ProfileIssue,
    ProfileMigrationReport,
    PyThermXProfile,
    UnsupportedProfileVersion,
    get_profile_schema,
    load_default_profile,
    load_profile,
    migrate_profile,
    profile_from_dict,
    validate_profile,
)

__version__ = "0.5.2"

__all__ = [
    # Cancellation (0.4.0)
    "CancellationRequested",
    "CancellationSource",
    "CancellationState",
    "CancellationStateError",
    "CancellationStatus",
    "CancellationToken",
    "TerminalOutcome",
    "cancellation",
    # Immutable presentation configuration
    "CLI_LEXICON_DEFAULTS",
    "CLI_PRESETS",
    "CLI_STYLE_DEFAULTS",
    "PresentationResolver",
    "config",
    "create_presentation_resolver",
    "resolve_cli_style",
    # Renderers and model
    "CLIThermometer",
    "CLIThermometerStyle",
    "ThermometerCore",
    "ThermometerState",
    "ProgressEstimate",
    "ProgressEstimator",
    "estimation",
    "ProgressAsyncIterator",
    "ProgressIterator",
    "ProgressRun",
    "adapters",
    "infer_total",
    "run_with_progress",
    "run_with_progress_async",
    "track",
    "track_async",
    "track_file",
    "CLIMultiProgress",
    "MultiProgressTask",
    "multi_progress",
    # Optional external presentation profiles
    "PROFILE_SCHEMA_VERSION",
    "SUPPORTED_PROFILE_SCHEMA_VERSIONS",
    "InvalidProfile",
    "ProfileError",
    "ProfileIssue",
    "ProfileMigrationReport",
    "PyThermXProfile",
    "UnsupportedProfileVersion",
    "get_profile_schema",
    "load_default_profile",
    "load_profile",
    "migrate_profile",
    "profile",
    "profile_from_dict",
    "validate_profile",
    # Serialization
    "ProgressEnvelope",
    "STATE_KEYS",
    "STATE_KEYS_V1_0",
    "STATE_KEYS_V1_1",
    "UnsupportedStateVersion",
    "envelope_from_dict",
    "envelope_to_dict",
    "envelope_to_json",
    "from_dict",
    "serialization",
    "thermometer_fields",
    "to_dict",
    "to_json",
    "__version__",
]
