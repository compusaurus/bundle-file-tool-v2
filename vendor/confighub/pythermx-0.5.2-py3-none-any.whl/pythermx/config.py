"""Immutable, opt-in configuration resolution for PyThermX presentation.

Resolution follows the same governed order as NodeThermX:

``library defaults -> profile/application defaults -> preset -> explicit``.

Python keeps the resolver explicit instead of introducing process-global
mutable configuration.  Direct style construction remains supported.
"""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Mapping

from .presentation import LEXICON_DEFAULTS, merge_lexicon


def _frozen_mapping(value: Mapping[str, Any]) -> Mapping[str, Any]:
    frozen: dict[str, Any] = {}
    for key, child in value.items():
        if isinstance(child, Mapping):
            frozen[key] = _frozen_mapping(child)
        elif isinstance(child, list):
            frozen[key] = tuple(child)
        else:
            frozen[key] = child
    return MappingProxyType(frozen)


CLI_LEXICON_DEFAULTS = LEXICON_DEFAULTS

CLI_STYLE_DEFAULTS = _frozen_mapping(
    {
        "width": 40,
        "fill_char": "#",
        "empty_char": "-",
        "left_bracket": "[",
        "right_bracket": "]",
        "show_percent": True,
        "show_value": True,
        "show_label": True,
        "non_tty_min_interval_s": 0.5,
        "show_count": True,
        "count_format": "{:,.0f}",
        "unit": None,
        "show_elapsed": False,
        "show_rate": False,
        "show_eta": False,
        "spinner_frames": ("|", "/", "-", "\\"),
        "spinner_interval_s": 0.1,
        "min_redraw_interval_s": 0.0,
        "promoted_separator": "-",
        "retain_history": False,
        "locale": "en-US",
        "percent_precision": 1,
        "value_separator": "/",
        "field_separator": " | ",
        "elapsed_suffix": "s",
        "rate_suffix": "/s",
        "eta_prefix": "ETA ",
        "lexicon": CLI_LEXICON_DEFAULTS,
    }
)

CLI_PRESETS = _frozen_mapping(
    {
        "ascii": {},
        "unicode": {
            "fill_char": "█",
            "empty_char": "░",
            "left_bracket": "▕",
            "right_bracket": "▏",
            "spinner_frames": ("◐", "◓", "◑", "◒"),
        },
        "minimal": {
            "show_value": False,
            "show_label": False,
            "show_count": False,
            "show_elapsed": False,
            "show_rate": False,
            "show_eta": False,
        },
        "verbose": {"show_elapsed": True, "show_rate": True, "show_eta": True},
        "ci": {"retain_history": True, "spinner_frames": (".",)},
    }
)

_OPTION_NAMES = frozenset(CLI_STYLE_DEFAULTS) | {"preset"}


def _copy_options(value: Mapping[str, Any] | None) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise TypeError("CLI style options must be a mapping")
    unknown = set(value) - _OPTION_NAMES
    if unknown:
        raise TypeError(f"Unknown CLI style option(s): {sorted(unknown)}")
    copied = dict(value)
    if "spinner_frames" in copied:
        copied["spinner_frames"] = tuple(copied["spinner_frames"])
    if "lexicon" in copied and copied["lexicon"] is not None:
        copied["lexicon"] = dict(copied["lexicon"])
    return copied


def _apply_layer(target: dict[str, Any], layer: Mapping[str, Any] | None) -> None:
    values = _copy_options(layer)
    preset_name = values.pop("preset", None)
    if preset_name is not None:
        try:
            preset = CLI_PRESETS[preset_name]
        except (KeyError, TypeError) as exc:
            raise ValueError(f"Unknown CLI preset: {preset_name!r}") from exc
        _merge_values(target, preset)
    _merge_values(target, values)


def _merge_values(target: dict[str, Any], values: Mapping[str, Any]) -> None:
    for key, value in values.items():
        if key == "lexicon":
            current = dict(target.get("lexicon", CLI_LEXICON_DEFAULTS))
            if value is not None:
                unknown = set(value) - set(CLI_LEXICON_DEFAULTS)
                if unknown:
                    raise TypeError(f"Unknown CLI lexicon option(s): {sorted(unknown)}")
                current.update({name: str(item) for name, item in value.items()})
            target[key] = current
        elif key == "spinner_frames":
            target[key] = tuple(value)
        else:
            target[key] = value


@dataclass(frozen=True)
class PresentationResolver:
    """One isolated configuration context suitable for apps and tests."""

    _defaults: Mapping[str, Any]

    def resolve_cli_style_options(
        self,
        overrides: Mapping[str, Any] | None = None,
        **explicit: Any,
    ) -> Mapping[str, Any]:
        values = dict(CLI_STYLE_DEFAULTS)
        values["lexicon"] = dict(CLI_LEXICON_DEFAULTS)
        _apply_layer(values, self._defaults)
        combined = _copy_options(overrides)
        combined.update(explicit)
        _apply_layer(values, combined)
        values["lexicon"] = merge_lexicon(values.get("lexicon"))
        values["spinner_frames"] = tuple(values["spinner_frames"])
        return _frozen_mapping(values)

    def cli_style(
        self,
        overrides: Mapping[str, Any] | None = None,
        **explicit: Any,
    ):
        from .thermometer_cli import CLIThermometerStyle

        values = dict(self.resolve_cli_style_options(overrides, **explicit))
        return CLIThermometerStyle(**values)

    def with_options(
        self,
        *,
        defaults: Mapping[str, Any] | None = None,
        lexicon: Mapping[str, Any] | None = None,
    ) -> "PresentationResolver":
        values = dict(self._defaults)
        _apply_layer(values, defaults)
        if lexicon is not None:
            _merge_values(values, {"lexicon": lexicon})
        return PresentationResolver(_frozen_mapping(values))


def create_presentation_resolver(
    *,
    defaults: Mapping[str, Any] | None = None,
    lexicon: Mapping[str, Any] | None = None,
) -> PresentationResolver:
    """Create an isolated resolver; no process or filesystem state is read."""

    values: dict[str, Any] = {}
    _apply_layer(values, defaults)
    if lexicon is not None:
        _merge_values(values, {"lexicon": lexicon})
    return PresentationResolver(_frozen_mapping(values))


def resolve_cli_style(
    options: Mapping[str, Any] | None = None,
    **explicit: Any,
):
    """Resolve a style directly from library defaults and explicit options."""

    return create_presentation_resolver().cli_style(options, **explicit)


__all__ = [
    "CLI_LEXICON_DEFAULTS",
    "CLI_PRESETS",
    "CLI_STYLE_DEFAULTS",
    "PresentationResolver",
    "create_presentation_resolver",
    "resolve_cli_style",
]
