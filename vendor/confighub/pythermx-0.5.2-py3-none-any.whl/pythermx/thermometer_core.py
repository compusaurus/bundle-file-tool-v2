"""UI-agnostic progress state for determinate and indeterminate work."""

from __future__ import annotations

import math
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Optional

from .thermometer_fields import MODE_DETERMINATE, MODE_INDETERMINATE

__all__ = ["ThermometerCore", "ThermometerState"]


def _finite(value: float, what: str) -> float:
    """Return ``value`` as a float, rejecting NaN and the infinities.

    THERM-DEFECT-001. Every guard in this module was of the form ``if x < 0``
    or ``if total <= 0``, and every comparison against ``NaN`` is ``False``, so
    a non-finite value passed each one untouched. The result was a model that
    could report ``mode == "determinate"`` with a ``NaN`` percentage, which a
    renderer would then draw.

    One helper rather than a check per method, so a new entry point cannot be
    added without one.
    """
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{what} must be a finite number, got {value!r}")
    return value


@dataclass(frozen=True)
class ThermometerState:
    """Immutable snapshot suitable for any renderer.

    The first four fields retain their 0.1.0 order so existing positional
    construction remains valid.
    """

    current: float
    total: Optional[float]
    percent: Optional[float]
    label: Optional[str] = None
    mode: str = MODE_DETERMINATE
    unit: Optional[str] = None
    phase: Optional[str] = None
    elapsed_s: float = 0.0
    promoted_from: Optional[float] = None


class ThermometerCore:
    """Track progress without depending on a user-interface toolkit."""

    def __init__(
        self,
        total: Optional[float],
        label: Optional[str] = None,
        *,
        unit: Optional[str] = None,
        phase: Optional[str] = None,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if total is not None:
            total = _finite(total, "total")
            if total <= 0:
                raise ValueError("total must be > 0")

        self._mode = MODE_INDETERMINATE if total is None else MODE_DETERMINATE
        self._total = None if total is None else float(total)
        self._current = 0.0
        self._label = label
        self._unit = unit
        self._phase = phase
        self._promoted_from: Optional[float] = None
        if not callable(clock):
            raise TypeError("clock must be callable")
        self._clock = clock
        self._started_at = _finite(clock(), "the clock reading")

    @property
    def mode(self) -> str:
        return self._mode

    @property
    def total(self) -> Optional[float]:
        return self._total

    @property
    def current(self) -> float:
        return self._current

    @property
    def percent(self) -> Optional[float]:
        if self._total is None:
            return None
        return (self._current / self._total) * 100.0

    @property
    def label(self) -> Optional[str]:
        return self._label

    @property
    def unit(self) -> Optional[str]:
        return self._unit

    @property
    def phase(self) -> Optional[str]:
        return self._phase

    @property
    def elapsed_s(self) -> float:
        # max() would mask a NaN reading as 0.0, because NaN > 0.0 is False.
        # That is accidental, not a guarantee, so read it through the guard.
        return max(0.0, _finite(self._clock(), "the clock reading") - self._started_at)

    @property
    def promoted_from(self) -> Optional[float]:
        return self._promoted_from

    def set_total(self, total: float) -> None:
        """Change a determinate total, clamping current progress if needed."""
        if self._mode == MODE_INDETERMINATE:
            raise ValueError("cannot set a total in indeterminate mode; use promote()")
        total = _finite(total, "total")
        if total <= 0:
            raise ValueError("total must be > 0")
        self._total = float(total)
        if self._current > self._total:
            self._current = self._total

    def set_label(self, label: Optional[str]) -> None:
        self._label = label

    def set_unit(self, unit: Optional[str]) -> None:
        self._unit = unit

    def set_phase(self, phase: Optional[str]) -> None:
        self._phase = phase

    def update(self, value: float) -> None:
        """Set an absolute work value, including a lower corrected value."""
        value = _finite(value, "current value")
        if value < 0:
            raise ValueError("current value cannot be negative")
        self._current = value if self._total is None else min(value, self._total)

    def increment(self, delta: float = 1.0) -> None:
        """Add work, clamping only in determinate mode."""
        delta = _finite(delta, "delta")
        if delta < 0:
            raise ValueError("delta cannot be negative")
        value = self._current + delta
        self._current = value if self._total is None else min(value, self._total)

    def promote(
        self,
        total: float,
        *,
        current: float = 0.0,
        phase: Optional[str] = None,
    ) -> None:
        """Transition once from indeterminate to determinate progress."""
        if self._mode != MODE_INDETERMINATE:
            raise ValueError("only indeterminate progress can be promoted")
        total = _finite(total, "total")
        if total <= 0:
            raise ValueError("total must be > 0")
        current = _finite(current, "current value")
        if current < 0:
            raise ValueError("current value cannot be negative")

        self._promoted_from = self._current
        self._total = total
        self._current = min(current, self._total)
        self._mode = MODE_DETERMINATE
        if phase is not None:
            self._phase = phase

    def reset(self) -> None:
        """Reset this run without changing its mode or work description."""
        self._current = 0.0
        self._promoted_from = None
        self._started_at = _finite(self._clock(), "the clock reading")

    def snapshot(self) -> ThermometerState:
        """Return an immutable snapshot of the current state."""
        return ThermometerState(
            current=self._current,
            total=self._total,
            percent=self.percent,
            label=self._label,
            mode=self._mode,
            unit=self._unit,
            phase=self._phase,
            elapsed_s=self.elapsed_s,
            promoted_from=self._promoted_from,
        )
