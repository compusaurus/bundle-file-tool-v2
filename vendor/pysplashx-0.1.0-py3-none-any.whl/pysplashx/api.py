"""High-level host API that keeps Qt imports lazy."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from .profile import SplashProfile, load_profile


class SplashStatus(str, Enum):
    STARTED = "started"
    DISABLED = "disabled"


@dataclass(frozen=True)
class SplashResult:
    status: SplashStatus
    reason: str = ""

    @property
    def started(self) -> bool:
        return self.status is SplashStatus.STARTED


class Splash:
    """Optional splash facade for standalone and host-owned native use."""

    def __init__(self, profile: SplashProfile, *, enabled: bool | None = None) -> None:
        self.profile = profile
        self._enabled_override = enabled
        self._orchestrator: Any | None = None

    @classmethod
    def from_profile(
        cls,
        profile_path: str | Path | None = None,
        *,
        enabled: bool | None = None,
    ) -> Splash:
        return cls(load_profile(profile_path), enabled=enabled)

    def _controller(self) -> Any:
        if self._orchestrator is None:
            from .core.orchestrator import SplashOrchestrator

            self._orchestrator = SplashOrchestrator(
                profile=self.profile, enabled=self._enabled_override
            )
        return self._orchestrator

    def start(self) -> SplashResult:
        """Start in an existing host QApplication without entering its loop."""

        if not self.profile.enabled_for("native", self._enabled_override):
            return SplashResult(SplashStatus.DISABLED, "disabled by native host policy")
        self._controller().start()
        return SplashResult(SplashStatus.STARTED)

    def run(self) -> SplashResult:
        """Run a standalone blocking splash that owns its QApplication."""

        if not self.profile.enabled_for("native", self._enabled_override):
            return SplashResult(SplashStatus.DISABLED, "disabled by native host policy")
        self._controller().run()
        return SplashResult(SplashStatus.STARTED)

    def close(self) -> None:
        """Close only objects owned by this splash instance."""

        if self._orchestrator is not None:
            self._orchestrator.close()
