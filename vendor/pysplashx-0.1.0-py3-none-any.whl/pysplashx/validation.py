# =============================================================================
# Module       : qc_validator.py
# Path         : splash_V2/scripts/qc_validator.py
# Project      : SplashKit V2 Lite (Core Media Edition)
# Description  : Lite profile validation runner. Performs three checks:
#                required key presence, temporal bounds sanity, and media /
#                mask file existence. No hashing, no signature validation,
#                no governance enforcement. Informational output only.
# Version      : 2.2-Lite
# Schema Ver.  : 2.2
# Spec Ref.    : splash_kit_v_2_lite_core_specification.md §10
# Lifecycle    : Proposed
# Catalog Ref. : QCValidator (4 methods)
#                (see deliverable_2_element_preservation_statement_r1.md §C.4)
# Author       : John (Lead Developer)
# Date         : 2025-12-11
# Framework    : PySide6 (resolved: Ringo, 2025-12-11) — not used in this module
# Governance   : George's Governance Standard for Maximum Compliance v2.0
# Dependencies : splash_ids (stdlib only; no Qt imports in this module)
# Notes        : Can be run standalone from the command line:
#                  python -m scripts.qc_validator <path/to/splash_profile.json>
#                Exit code 0 = all checks passed. Exit code 1 = one or more failures.
# =============================================================================

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path

from .splash_ids import (
    CFG_MEDIA_TYPE_VIDEO,
    CFG_SHAPE_PNG_MASK,
    KEY_END_POS_MS,
    KEY_FILENAME,
    KEY_GEOMETRY,
    KEY_IMAGE,
    KEY_MASK_PATH,
    KEY_MASK_SETTINGS,
    KEY_MEDIA,
    KEY_MEDIA_SOURCES,
    KEY_MEDIA_TYPE,
    KEY_SHAPE,
    KEY_START_POS_MS,
    KEY_TEMPORAL,
    KEY_VIDEO,
    REQUIRED_KEYS,
)

# ---------------------------------------------------------------------------
# Result data structures
# ---------------------------------------------------------------------------


@dataclass
class CheckResult:
    """Outcome of a single validation check."""

    name: str
    passed: bool
    messages: list[str] = field(default_factory=list)


@dataclass
class ValidationReport:
    """Aggregated results from all QCValidator checks."""

    profile_path: str
    results: list[CheckResult] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        """True only if every individual check passed."""
        return all(r.passed for r in self.results)

    @property
    def failure_count(self) -> int:
        return sum(1 for r in self.results if not r.passed)


# ---------------------------------------------------------------------------
# QCValidator
# ---------------------------------------------------------------------------


class QCValidator:
    """
    Lite profile validation runner.

    Loads a splash_profile.json and runs three independent checks.
    Results are accumulated and returned as a ValidationReport via report().

    Usage:
        validator = QCValidator("splash_profile.json")
        report = validator.report()
        if not report.passed:
            sys.exit(1)
    """

    def __init__(self, profile_path: str | Path) -> None:
        """
        Load and parse the profile at initialisation time so all checks
        operate on the same in-memory dict.

        Args:
            profile_path: Path to the splash_profile.json file to validate.

        Raises:
            FileNotFoundError: If the file does not exist.
            json.JSONDecodeError: If the file is not valid JSON.
        """
        self._profile_path = Path(profile_path)
        self._profile_dir = self._profile_path.resolve().parent

        if not self._profile_path.exists():
            raise FileNotFoundError(f"Profile not found: {self._profile_path}")

        with self._profile_path.open(encoding="utf-8") as fh:
            self._profile: dict = json.load(fh)

    # ------------------------------------------------------------------
    # Public checks — each returns a CheckResult, never raises
    # ------------------------------------------------------------------

    def check_required_keys(self) -> CheckResult:
        """
        Verify that every dot-notation path in REQUIRED_KEYS is present
        in the loaded profile.

        A dot-notation path such as "media.media_type" is resolved by
        walking the nested dict level by level.

        Returns:
            CheckResult with passed=True if all keys are present.
            Lists each missing key in messages on failure.
        """
        missing: list[str] = []

        for dot_path in REQUIRED_KEYS:
            node: dict = self._profile
            found = True
            for part in dot_path.split("."):
                if not isinstance(node, dict) or part not in node:
                    found = False
                    break
                node = node[part]
            if not found:
                missing.append(dot_path)

        if missing:
            return CheckResult(
                name="check_required_keys",
                passed=False,
                messages=[f"Missing required key: {k}" for k in missing],
            )

        return CheckResult(
            name="check_required_keys",
            passed=True,
            messages=["All required keys present."],
        )

    def check_temporal_bounds(self) -> CheckResult:
        """
        Verify that end_pos_ms >= start_pos_ms for video media.

        Only evaluated when media_type is video and a temporal block exists.
        Skipped (pass) for image media type.

        Returns:
            CheckResult with passed=True if bounds are valid or check is
            not applicable.
        """
        media: dict = self._profile.get(KEY_MEDIA, {})
        media_type: str = media.get(KEY_MEDIA_TYPE, CFG_MEDIA_TYPE_VIDEO)

        if media_type != CFG_MEDIA_TYPE_VIDEO:
            return CheckResult(
                name="check_temporal_bounds",
                passed=True,
                messages=["Not applicable — media_type is not video."],
            )

        temporal: dict = media.get(KEY_VIDEO, {}).get(KEY_TEMPORAL, {})
        start: int = temporal.get(KEY_START_POS_MS, 0)
        end: int = temporal.get(KEY_END_POS_MS, 0)

        # end_pos_ms == 0 is the sentinel for "play to natural end" — always valid
        if end != 0 and end < start:
            return CheckResult(
                name="check_temporal_bounds",
                passed=False,
                messages=[f"end_pos_ms ({end}) must be >= start_pos_ms ({start})."],
            )

        return CheckResult(
            name="check_temporal_bounds",
            passed=True,
            messages=[f"Temporal bounds valid — start: {start}ms, end: {end}ms."],
        )

    def check_file_existence(self) -> CheckResult:
        """
        Verify that every path in media_sources exists on disk, and that
        mask_path exists when shape is png_mask.

        Reports each missing file individually so the developer can
        resolve all absences in a single pass.

        Returns:
            CheckResult with passed=True if all referenced files exist.
        """
        messages: list[str] = []
        passed = True

        # --- media: resolve folder+filename for active media_type ---
        media_cfg: dict = self._profile.get(KEY_MEDIA, {})
        media_type: str = media_cfg.get(KEY_MEDIA_TYPE, CFG_MEDIA_TYPE_VIDEO)
        folders: list[str] = media_cfg.get(KEY_MEDIA_SOURCES, [])

        if media_type == CFG_MEDIA_TYPE_VIDEO:
            filename: str = media_cfg.get(KEY_VIDEO, {}).get(KEY_FILENAME, "")
            filename_label: str = "media.video.filename"
        else:
            filename = media_cfg.get(KEY_IMAGE, {}).get(KEY_FILENAME, "")
            filename_label = "media.image.filename"

        if not filename:
            passed = False
            messages.append(f"MISSING: {filename_label} is empty or not set.")
        else:
            resolved = False
            for folder in folders:
                base = Path(folder)
                if not base.is_absolute():
                    base = self._profile_dir / base
                candidate = base / filename
                if candidate.exists():
                    resolved = True
                    messages.append(f"Media source OK: {candidate}")
                    break
            if not resolved:
                passed = False
                tried = [
                    str((Path(f) if Path(f).is_absolute() else self._profile_dir / f) / filename)
                    for f in folders
                ]
                messages.append(
                    f"NOT FOUND: '{filename}' not found in any media_sources folder. "
                    f"Tried: {tried}"
                )

        # --- mask_path — only required when shape == png_mask ---
        geo: dict = self._profile.get(KEY_GEOMETRY, {})
        shape: str = geo.get(KEY_SHAPE, "")
        if shape == CFG_SHAPE_PNG_MASK:
            mask_path: str | None = geo.get(KEY_MASK_SETTINGS, {}).get(KEY_MASK_PATH)
            if not mask_path:
                passed = False
                messages.append(
                    "mask_settings.mask_path required when shape=png_mask but is absent."
                )
            elif not (
                Path(mask_path) if Path(mask_path).is_absolute() else self._profile_dir / mask_path
            ).exists():
                passed = False
                messages.append(f"Mask file not found: {mask_path}")
            else:
                messages.append(f"Mask file OK: {mask_path}")

        if not messages:
            messages.append("No file paths to check.")

        return CheckResult(
            name="check_file_existence",
            passed=passed,
            messages=messages,
        )

    # ------------------------------------------------------------------
    # Report — runs all checks, returns aggregated ValidationReport
    # ------------------------------------------------------------------

    def report(self) -> ValidationReport:
        """
        Execute all three checks in sequence and return a ValidationReport.

        Checks are independent — a failure in one does not prevent the
        others from running, so the developer sees all issues at once.

        Returns:
            ValidationReport with .passed property and per-check detail.
        """
        vr = ValidationReport(profile_path=str(self._profile_path))
        vr.results.append(self.check_required_keys())
        vr.results.append(self.check_temporal_bounds())
        vr.results.append(self.check_file_existence())
        return vr


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def _print_report(vr: ValidationReport) -> None:
    """Render a ValidationReport to stdout in a readable format."""
    print("\nPySplashX — Profile Validation Report")
    print(f"Profile : {vr.profile_path}")
    print(f"Result  : {'PASS' if vr.passed else 'FAIL'}")
    print("-" * 60)
    for result in vr.results:
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] {result.name}")
        for msg in result.messages:
            print(f"         {msg}")
    print("-" * 60)
    if vr.passed:
        print("All checks passed.\n")
    else:
        print(f"{vr.failure_count} check(s) failed.\n")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="SplashKit V2 Lite — QC Validator")
    parser.add_argument(
        "--profile",
        default="pysplashx_profile.json",
        help="Path to pysplashx_profile.json (default: pysplashx_profile.json)",
    )
    args = parser.parse_args()

    try:
        validator = QCValidator(args.profile)
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        print(f"\n  ERROR: {exc}")
        sys.exit(1)

    report = validator.report()
    _print_report(report)
    sys.exit(0 if report.passed else 1)
