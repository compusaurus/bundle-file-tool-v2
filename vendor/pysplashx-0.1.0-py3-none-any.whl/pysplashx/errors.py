"""Stable public exceptions for PySplashX."""

from __future__ import annotations


class PySplashXError(Exception):
    """Base class for recoverable PySplashX failures."""


class ProfileNotFoundError(PySplashXError, FileNotFoundError):
    """Raised when a requested profile cannot be located."""


class ProfileValidationError(PySplashXError, ValueError):
    """Raised when a profile does not satisfy the public contract."""

    def __init__(self, issues: list[str] | tuple[str, ...]) -> None:
        self.issues = tuple(issues)
        super().__init__("Invalid PySplashX profile: " + "; ".join(self.issues))


class SplashDisabledError(PySplashXError):
    """Raised by the low-level runner when policy disables the splash."""


class MediaNotFoundError(PySplashXError, FileNotFoundError):
    """Raised when no configured media source contains the active asset."""


class LifecycleError(PySplashXError, RuntimeError):
    """Raised when standalone and host-owned lifecycle modes are mixed."""


class PlaybackError(PySplashXError, RuntimeError):
    """Raised when a media backend cannot load or play an asset."""
