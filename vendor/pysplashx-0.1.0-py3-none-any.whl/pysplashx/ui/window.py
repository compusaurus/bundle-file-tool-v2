# =============================================================================
# Module       : window.py
# Path         : splash_V2/src/ui/window.py
# Project      : SplashKit V2 Lite (Core Media Edition)
# Description  : PySide6 frameless splash window. Handles window shaping
#                (rect, oval, rounded, png_mask), transparency, scaling,
#                positioning, and close-on-click behaviour. Receives a
#                pre-resolved geometry dict from SplashOrchestrator.
# Version      : 2.2-Lite
# Schema Ver.  : 2.2
# Spec Ref.    : splash_kit_v_2_lite_core_specification.md §6, §7, §9
# Lifecycle    : Proposed
# Catalog Ref. : SplashWindow (3 methods)
#                (see deliverable_2_element_preservation_statement_r1.md §C.5)
# Author       : John (Lead Developer)
# Date         : 2025-12-11
# Framework    : PySide6 (resolved: Ringo, 2025-12-11)
# Governance   : George's Governance Standard for Maximum Compliance v2.0
# Dependencies : PySide6, splash_ids
# Notes        : show_image() is an additional rendering convenience used by
#                SplashOrchestrator for image media mode. It is not a
#                cataloged public API method — it is an internal helper
#                called only from orchestrator.run().
# =============================================================================

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QBitmap, QPainter, QPainterPath, QPixmap, QRegion
from PySide6.QtWidgets import QLabel, QWidget

from ..splash_ids import (
    CFG_POSITION_CENTER,
    CFG_SHAPE_OVAL,
    CFG_SHAPE_PNG_MASK,
    CFG_SHAPE_RECT,
    CFG_SHAPE_ROUNDED,
    KEY_ALWAYS_ON_TOP,
    KEY_CLOSE_ON_CLICK,
    KEY_IS_NATIVE,
    KEY_MASK_PATH,
    KEY_MASK_THRESHOLD,
    KEY_POSITION,
    KEY_RADIUS_PX,
    KEY_SCALE_PERCENT,
    KEY_SHAPE,
)

_log = logging.getLogger(__name__)


class SplashWindow(QWidget):
    """
    PySide6 splash window with frameless rendering, custom shapes,
    PNG masking, static image display, and close-on-click support.

    Receives geometry and runtime configuration dicts from
    SplashOrchestrator — it does not read splash_profile.json directly.
    """

    def __init__(
        self,
        geometry: dict[str, Any],
        runtime_cfg: dict[str, Any],
        parent: QWidget | None = None,
        on_close_requested: Callable[[], None] | None = None,
    ) -> None:
        """
        Initialise and configure the splash window.

        Args:
            geometry:    Resolved geometry dict from orchestrator.apply_geometry().
            runtime_cfg: Resolved runtime_behavior dict from the profile.
            parent:      Optional Qt parent widget.
        """
        is_native: bool = geometry.get(KEY_IS_NATIVE, False)
        flags = Qt.WindowType.Window

        if not is_native:
            flags |= Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowDoesNotAcceptFocus
        if runtime_cfg.get(KEY_ALWAYS_ON_TOP, True):
            flags |= Qt.WindowType.WindowStaysOnTopHint

        super().__init__(parent, flags)

        self._geometry_cfg = geometry
        self._close_on_click: bool = runtime_cfg.get(KEY_CLOSE_ON_CLICK, True)
        self._on_close_requested = on_close_requested or self.close
        self._image_label: QLabel | None = None

        if not is_native:
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self._apply_size_and_position()
        self.apply_shape(geometry)

        _log.debug(
            "SplashWindow created — shape: %s | is_native: %s | close_on_click: %s",
            geometry.get(KEY_SHAPE, CFG_SHAPE_RECT),
            is_native,
            self._close_on_click,
        )

    # ------------------------------------------------------------------
    # Cataloged public methods
    # ------------------------------------------------------------------

    def apply_shape(self, geometry: dict[str, Any]) -> None:
        """
        Apply the window shape defined by geometry.shape.

        Dispatches to the appropriate shaping strategy:
            rect     — no mask applied (native rectangular window)
            oval     — elliptical QRegion mask
            rounded  — QPainterPath-based rounded rectangle mask
            png_mask — PNG alpha channel mask via apply_mask()

        Args:
            geometry: Resolved geometry dict containing shape, radius_px,
                      mask_path, and mask_threshold keys.
        """
        # A mask is tied to the widget dimensions at the moment it is built.
        # Media metadata can resize this window later, so every application
        # starts clean and callers may safely rebuild it after a resize.
        self.clearMask()
        shape: str = geometry.get(KEY_SHAPE, CFG_SHAPE_RECT)

        if shape == CFG_SHAPE_RECT:
            _log.debug("Shape: rect — no mask applied.")
            return

        if shape == CFG_SHAPE_OVAL:
            region = QRegion(self.rect(), QRegion.RegionType.Ellipse)
            self.setMask(region)
            _log.debug("Shape: oval — ellipse region mask applied.")
            return

        if shape == CFG_SHAPE_ROUNDED:
            radius: int = geometry.get(KEY_RADIUS_PX, 0)
            path = QPainterPath()
            path.addRoundedRect(
                float(self.rect().x()),
                float(self.rect().y()),
                float(self.rect().width()),
                float(self.rect().height()),
                float(radius),
                float(radius),
            )
            bitmap = QBitmap(self.size())
            # QColor("black")/QColor("white") do not portably identify the
            # transparent and opaque bits of a depth-one QBitmap. On Windows
            # they inverted this mask and clipped out the entire splash body.
            bitmap.fill(Qt.GlobalColor.color0)
            painter = QPainter(bitmap)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.fillPath(path, Qt.GlobalColor.color1)
            painter.end()
            self.setMask(bitmap)
            _log.debug("Shape: rounded — radius %dpx mask applied.", radius)
            return

        if shape == CFG_SHAPE_PNG_MASK:
            self.apply_mask(geometry)
            return

        _log.warning("Unknown shape '%s' — falling back to rect.", shape)

    def apply_mask(self, geometry: dict[str, Any]) -> None:
        """
        Apply a PNG file as the window transparency mask.

        The PNG alpha channel is thresholded at mask_threshold: pixels with
        alpha >= threshold are opaque; pixels below are transparent.
        Only called when shape == png_mask.

        Args:
            geometry: Resolved geometry dict containing mask_path and
                      mask_threshold keys.

        Logs a warning and skips masking if mask_path is absent or the
        file does not exist — window remains rectangular rather than raising.
        """
        mask_path: str | None = geometry.get(KEY_MASK_PATH)
        threshold: int = geometry.get(KEY_MASK_THRESHOLD, 128)

        if not mask_path:
            _log.warning("apply_mask called but mask_path is not set — skipping.")
            return

        if not Path(mask_path).exists():
            _log.warning("Mask file not found: %s — skipping.", mask_path)
            return

        pixmap = QPixmap(mask_path)
        if pixmap.isNull():
            _log.warning("Failed to load mask pixmap: %s — skipping.", mask_path)
            return

        image = pixmap.toImage()
        bitmap = QBitmap(image.size())
        bitmap.fill(Qt.GlobalColor.color0)
        painter = QPainter(bitmap)
        for x in range(image.width()):
            for y in range(image.height()):
                if image.pixelColor(x, y).alpha() >= threshold:
                    painter.setPen(Qt.GlobalColor.color1)
                    painter.drawPoint(x, y)
        painter.end()

        self.setMask(bitmap)
        _log.debug("PNG mask applied: %s (threshold=%d).", mask_path, threshold)

    def refresh_shape(self) -> None:
        """Rebuild the current shape mask after a media-driven resize."""

        self.apply_shape(self._geometry_cfg)

    def on_click(self, event: Any) -> None:
        """
        Handle mouse press events.

        Closes the splash window when close_on_click is True.
        Ignores the event otherwise.

        Args:
            event: QMouseEvent passed by Qt's event system.
        """
        if self._close_on_click:
            _log.debug("Click detected — closing splash.")
            self._on_close_requested()

    # ------------------------------------------------------------------
    # Qt event override — routes to cataloged on_click()
    # ------------------------------------------------------------------

    def mousePressEvent(self, event: Any) -> None:  # type: ignore[override]
        self.on_click(event)

    # ------------------------------------------------------------------
    # Image display helper — internal, called only by orchestrator.run()
    # ------------------------------------------------------------------

    def show_image(self, source: Path, duration_ms: int) -> None:
        """
        Display a static image and schedule auto-close after duration_ms.

        Window is resized to the image's native aspect ratio scaled by
        scale_percent, then re-centered — matching the video BufferedMedia
        resize pattern so both media types render at native proportions.

        Args:
            source:      Path to the image file (PNG or JPG).
            duration_ms: Display duration in milliseconds before auto-close.
                         0 = display indefinitely until clicked or closed.
        """
        from PySide6.QtWidgets import QApplication  # deferred — same as _apply_size_and_position

        self._image_label = QLabel(self)
        pixmap = QPixmap(str(source))

        if pixmap.isNull():
            _log.warning("Failed to load image: %s", source)
            return

        # Resize window to image native dimensions × scale_percent, then re-center.
        # This prevents the pre-sized 16:9 window from distorting non-16:9 images.
        scale_percent: int = self._geometry_cfg.get(KEY_SCALE_PERCENT, 100)
        native_w: int = pixmap.width()
        native_h: int = pixmap.height()
        scale: float = scale_percent / 100.0
        win_w: int = int(native_w * scale)
        win_h: int = int(native_h * scale)

        self.resize(win_w, win_h)
        screen = QApplication.primaryScreen()
        if screen is not None:
            avail = screen.availableGeometry()
            self.move(
                avail.x() + (avail.width() - win_w) // 2,
                avail.y() + (avail.height() - win_h) // 2,
            )

        self.refresh_shape()

        # Scale pixmap to window size — KeepAspectRatio is clean since window
        # already matches the image's aspect ratio at this point.
        self._image_label.setPixmap(
            pixmap.scaled(
                win_w,
                win_h,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )
        self._image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._image_label.resize(win_w, win_h)

        if duration_ms > 0:
            QTimer.singleShot(duration_ms, self._on_close_requested)

        _log.debug(
            "Static image displayed — native: %dx%d | rendered: %dx%d | duration: %dms.",
            native_w,
            native_h,
            win_w,
            win_h,
            duration_ms,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _apply_size_and_position(self) -> None:
        """
        Compute window size from scale_percent and position on screen.
        Currently supports position=center only (spec §6).
        """
        from PySide6.QtWidgets import QApplication  # deferred to avoid circular import

        screen = QApplication.primaryScreen()
        if screen is None:
            _log.warning("No primary screen detected — defaulting to 800x600.")
            self.resize(800, 600)
            return

        screen_rect = screen.availableGeometry()
        scale: int = self._geometry_cfg.get(KEY_SCALE_PERCENT, 100)
        scale_factor: float = max(1, min(scale, 100)) / 100.0

        width: int = int(screen_rect.width() * scale_factor)
        height: int = int(screen_rect.height() * scale_factor)
        self.resize(width, height)

        position: str = self._geometry_cfg.get(KEY_POSITION, CFG_POSITION_CENTER)
        if position == CFG_POSITION_CENTER:
            x = screen_rect.x() + (screen_rect.width() - width) // 2
            y = screen_rect.y() + (screen_rect.height() - height) // 2
            self.move(x, y)

        _log.debug(
            "Window sized %dx%d (%d%%) at (%d, %d).",
            width,
            height,
            scale,
            self.x(),
            self.y(),
        )
