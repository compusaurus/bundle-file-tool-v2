# =============================================================================
# Module       : __init__.py
# Path         : splash_V2/src/ui/__init__.py
# Project      : SplashKit V2 Lite (Core Media Edition)
# Description  : Package initialiser for the ui subpackage. Exposes
#                SplashWindow and VideoEngine at the package level so
#                callers can import directly from src.ui.
# Version      : 2.2-Lite
# Schema Ver.  : 2.2
# Spec Ref.    : splash_kit_v_2_lite_core_specification.md §3
# Lifecycle    : Proposed
# Catalog Ref. : N/A — infrastructure file, no application elements
# Author       : John (Lead Developer)
# Date         : 2025-12-11
# Framework    : PySide6 (resolved: Ringo, 2025-12-11)
# Governance   : George's Governance Standard for Maximum Compliance v2.0
# Dependencies : ui.window, ui.video_engine
# =============================================================================

from .video_engine import VideoEngine
from .window import SplashWindow

__all__ = ["SplashWindow", "VideoEngine"]
