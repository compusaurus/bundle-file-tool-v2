# =============================================================================
# Module       : video_engine.py
# Path         : splash_V2/src/ui/video_engine.py
# Project      : SplashKit V2 Lite (Core Media Edition)
# Description  : PySide6 multimedia video player for splash playback.
#                Handles source loading, start position seeking, aspect ratio
#                application, and loop behavior execution (close/freeze/replay)
#                on reaching end_pos_ms.
# Version      : 2.2-Lite
# Schema Ver.  : 2.2
# Spec Ref.    : splash_kit_v_2_lite_core_specification.md §5, §9
# Lifecycle    : Proposed
# Catalog Ref. : VideoEngine (3 methods)
#                (see deliverable_2_element_preservation_statement_r1.md §C.6)
# Author       : John (Lead Developer)
# Date         : 2025-12-11
# Framework    : PySide6 (resolved: Ringo, 2025-12-11)
# Governance   : George's Governance Standard for Maximum Compliance v2.0
# Dependencies : PySide6, splash_ids, ui.window
# Notes        : stop() is an additional teardown helper called by
#                orchestrator.shutdown(). It is not a cataloged public API
#                method — it is an internal lifecycle method.
#                end_pos_ms == 0 is the sentinel for "play to natural end".
# =============================================================================

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import QApplication

from ..splash_ids import (
    CFG_ASPECT_EXPAND,
    CFG_ASPECT_FIT,
    CFG_ASPECT_IGNORE,
    CFG_LOOP_CLOSE,
    CFG_LOOP_FREEZE,
    CFG_LOOP_REPLAY,
)
from .window import SplashWindow

_log = logging.getLogger(__name__)


class VideoEngine:
    """
    PySide6 multimedia video player for SplashKit V2 Lite.

    Wraps QMediaPlayer and QVideoWidget to provide start-position seeking,
    aspect ratio control, and loop behavior dispatch on playback end.

    Owned by SplashOrchestrator — created in run(), released in shutdown().
    """

    def __init__(
        self,
        source: Path,
        start_pos_ms: int,
        end_pos_ms: int,
        loop_behavior: str,
        aspect_ratio_mode: str,
        scale_percent: int,
        window: SplashWindow,
        on_close_requested: Callable[[], None] | None = None,
    ) -> None:
        """
        Initialise the video engine and embed a QVideoWidget into the window.

        Args:
            source:        Resolved path to the video file.
            start_pos_ms:  Seek position in ms before playback begins.
            end_pos_ms:    Position in ms at which loop_behavior triggers.
                           0 = play to natural end of file.
            loop_behavior:      One of CFG_LOOP_CLOSE / CFG_LOOP_FREEZE / CFG_LOOP_REPLAY.
            aspect_ratio_mode:  One of CFG_ASPECT_EXPAND / CFG_ASPECT_FIT / CFG_ASPECT_IGNORE.
            scale_percent:      Integer 1-100; window is resized to video native
                                dimensions x (scale_percent / 100) on BufferedMedia.
            window:             The SplashWindow instance to render video into.
        """
        self._source = source
        self._start_pos_ms = start_pos_ms
        self._end_pos_ms = end_pos_ms
        self._loop_behavior = loop_behavior
        self._aspect_ratio_mode = aspect_ratio_mode
        self._scale_percent = scale_percent
        self._window = window
        self._on_close_requested = on_close_requested or window.close
        self._seeked_to_start = False

        # --- Qt multimedia components ---
        self._video_widget = QVideoWidget(window)
        self._video_widget.resize(window.size())
        self._video_widget.setAspectRatioMode(self._resolve_aspect_mode(aspect_ratio_mode))
        self._video_widget.show()

        self._audio_output = QAudioOutput()
        self._player = QMediaPlayer()
        self._player.setAudioOutput(self._audio_output)
        self._player.setVideoOutput(self._video_widget)

        # --- Signal connections ---
        self._player.playbackStateChanged.connect(self._on_playback_state_changed)
        self._player.mediaStatusChanged.connect(self._on_media_status_changed)
        self._player.positionChanged.connect(self._on_position_changed)
        self._player.errorOccurred.connect(self._on_error)

        _log.debug(
            "VideoEngine initialised — source: %s | start: %dms | end: %dms | loop: %s",
            source,
            start_pos_ms,
            end_pos_ms,
            loop_behavior,
        )

    # ------------------------------------------------------------------
    # Cataloged public methods
    # ------------------------------------------------------------------

    def load(self) -> None:
        """
        Set the media source on the player.

        Does not begin playback — call play() after load().
        Seeking to start_pos_ms is deferred until the player signals
        that it is in the Playing state, to ensure the seek is valid.
        """
        url = QUrl.fromLocalFile(str(self._source.resolve()))
        self._player.setSource(url)
        _log.debug("Media source set: %s", self._source)

    def play(self) -> None:
        """
        Begin video playback.

        The player will seek to start_pos_ms once it reaches the Playing
        state (handled in _on_playback_state_changed) to ensure the
        underlying media is ready before seeking.
        """
        self._player.play()
        _log.debug("Playback started.")

    def on_end_reached(self) -> None:
        """
        Execute the configured loop_behavior when end_pos_ms is reached
        or the media plays to its natural end.

        Dispatch:
            CFG_LOOP_CLOSE  — close the splash window
            CFG_LOOP_FREEZE — pause on the last frame
            CFG_LOOP_REPLAY — seek back to start_pos_ms and resume
        """
        _log.debug("End reached — executing loop_behavior: %s", self._loop_behavior)

        if self._loop_behavior == CFG_LOOP_CLOSE:
            self._on_close_requested()

        elif self._loop_behavior == CFG_LOOP_FREEZE:
            self._player.pause()

        elif self._loop_behavior == CFG_LOOP_REPLAY:
            self._player.setPosition(self._start_pos_ms)
            self._player.play()

        else:
            _log.warning(
                "Unknown loop_behavior '%s' — defaulting to close.",
                self._loop_behavior,
            )
            self._on_close_requested()

    # ------------------------------------------------------------------
    # Teardown helper — called by orchestrator.shutdown()
    # ------------------------------------------------------------------

    def stop(self) -> None:
        """
        Stop playback and release the media source.
        Called by SplashOrchestrator.shutdown() before the window is closed.
        """
        self._player.stop()
        self._player.setSource(QUrl())
        _log.debug("VideoEngine stopped and source released.")

    # ------------------------------------------------------------------
    # Private signal handlers
    # ------------------------------------------------------------------

    def _on_playback_state_changed(self, state: QMediaPlayer.PlaybackState) -> None:
        """
        Seek to start_pos_ms the first time the player enters Playing state.
        This deferred seek ensures the media is loaded and seekable.
        """
        if (
            state == QMediaPlayer.PlaybackState.PlayingState
            and not self._seeked_to_start
            and self._start_pos_ms > 0
        ):
            self._player.setPosition(self._start_pos_ms)
            self._seeked_to_start = True
            _log.debug("Seeked to start_pos_ms: %d", self._start_pos_ms)

    def _on_position_changed(self, position_ms: int) -> None:
        """
        Monitor playback position and trigger on_end_reached() when
        end_pos_ms is reached (only when end_pos_ms is non-zero).
        """
        if self._end_pos_ms > 0 and position_ms >= self._end_pos_ms:
            self._player.positionChanged.disconnect(self._on_position_changed)
            self.on_end_reached()

    def _on_media_status_changed(self, status: QMediaPlayer.MediaStatus) -> None:
        """
        Handle two media status events:

        BufferedMedia — video dimensions are now known. Resize the window to
            the video's native aspect ratio scaled by scale_percent, then
            re-center. This ensures no cropping or distortion regardless of
            the initial window size. Matches splash_gui.py resize behaviour.

        EndOfMedia — natural end of file (only when end_pos_ms == 0, i.e. no
            trim active). Delegates to on_end_reached() for loop_behavior
            dispatch. Guard prevents double-firing with _on_position_changed.
        """
        if status == QMediaPlayer.MediaStatus.BufferedMedia:
            video_size = self._player.videoSink().videoSize()
            if video_size.isValid():
                vid_w = video_size.width()
                vid_h = video_size.height()
                # Window was already sized to scale_percent of screen by apply_shape().
                # Fit video aspect ratio WITHIN the existing window bounds — no second
                # scale application. This corrects 16:9 cropping for square/portrait video.
                win_w = self._window.width()
                win_h = self._window.height()
                fit_scale = min(win_w / vid_w, win_h / vid_h)
                new_w = int(vid_w * fit_scale)
                new_h = int(vid_h * fit_scale)
                self._window.resize(new_w, new_h)
                self._video_widget.resize(new_w, new_h)

                # Re-center window on screen after resize
                screen = QApplication.primaryScreen().availableGeometry()
                self._window.move(
                    screen.x() + (screen.width() - new_w) // 2,
                    screen.y() + (screen.height() - new_h) // 2,
                )
                self._window.refresh_shape()
                _log.debug(
                    "Window fitted to video aspect ratio: %dx%d (from window %dx%d)",
                    new_w,
                    new_h,
                    win_w,
                    win_h,
                )

                # Apply start-position seek now that media dimensions are known
                if self._start_pos_ms > 0 and not self._seeked_to_start:
                    self._player.setPosition(self._start_pos_ms)
                    self._seeked_to_start = True

        elif status == QMediaPlayer.MediaStatus.EndOfMedia and self._end_pos_ms == 0:
            _log.debug("EndOfMedia status received — triggering on_end_reached().")
            self.on_end_reached()

    @staticmethod
    def _resolve_aspect_mode(mode: str) -> Qt.AspectRatioMode:
        """
        Map a CFG_ASPECT_* string constant to the corresponding
        Qt.AspectRatioMode enum value for QVideoWidget.

        Unmapped values default to KeepAspectRatioByExpanding (expand).
        """
        mapping = {
            CFG_ASPECT_EXPAND: Qt.AspectRatioMode.KeepAspectRatioByExpanding,
            CFG_ASPECT_FIT: Qt.AspectRatioMode.KeepAspectRatio,
            CFG_ASPECT_IGNORE: Qt.AspectRatioMode.IgnoreAspectRatio,
        }
        resolved = mapping.get(mode, Qt.AspectRatioMode.KeepAspectRatioByExpanding)
        if mode not in mapping:
            _log.warning("Unknown aspect_ratio_mode '%s' — defaulting to expand.", mode)
        return resolved

    def _on_error(self, error: QMediaPlayer.Error, error_string: str) -> None:
        """Log media player errors."""
        _log.error("QMediaPlayer error %s: %s", error, error_string)
