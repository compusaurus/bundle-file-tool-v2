# =============================================================================
# Module       : splash_ids.py
# Path         : splash_V2/src/splash_ids.py
# Project      : SplashKit V2 Lite (Core Media Edition)
# Description  : Configuration enum constants, profile key name registry,
#                valid value sets, and required key manifest for the Lite
#                splash profile. All application code must reference config
#                values and key names through this module — no raw string
#                literals in logic per Governance Standard S1.
# Version      : 2.2-Lite
# Schema Ver.  : 2.2
# Spec Ref.    : splash_kit_v_2_lite_core_specification.md §4–§8
# Lifecycle    : Proposed
# Catalog Ref. : SPL-ID-L-001 through SPL-ID-L-018 + key constants
#                (see deliverable_2_element_preservation_statement_r1.md)
# Author       : John (Lead Developer)
# Date         : 2025-12-11
# Framework    : PySide6 (resolved: Ringo, 2025-12-11)
# Governance   : George's Governance Standard for Maximum Compliance v2.0
#                S1 — Ref-First / No String Literals
# Dependencies : None (stdlib only; no Qt imports in this module)
# Notes        : Governance constants (hashing, seal, audit log, asset UIDs)
#                are intentionally absent. They belong in pyprojectmgr.
# =============================================================================

# =============================================================================
# SECTION 1 — MEDIA TYPE CONSTANTS
# Maps to: media.media_type
# =============================================================================

CFG_MEDIA_TYPE_VIDEO: str = "video"    # SPL-ID-L-001
CFG_MEDIA_TYPE_IMAGE: str = "image"   # SPL-ID-L-002

# =============================================================================
# SECTION 2 — ASPECT RATIO MODE CONSTANTS
# Maps to: media.video.aspect_ratio_mode
# =============================================================================

CFG_ASPECT_EXPAND: str = "expand"     # SPL-ID-L-003 — fill + crop to window edges
CFG_ASPECT_FIT: str = "fit"           # SPL-ID-L-004 — letterbox with bars
CFG_ASPECT_IGNORE: str = "ignore"     # SPL-ID-L-005 — stretch to fill (may distort)

# =============================================================================
# SECTION 3 — LOOP BEHAVIOR CONSTANTS
# Maps to: media.video.loop_behavior
# =============================================================================

CFG_LOOP_CLOSE: str = "close"         # SPL-ID-L-006 — auto-exit splash on end
CFG_LOOP_FREEZE: str = "freeze"       # SPL-ID-L-007 — pause on last frame
CFG_LOOP_REPLAY: str = "replay"       # SPL-ID-L-008 — loop from start_pos_ms

# =============================================================================
# SECTION 4 — GEOMETRY SHAPE CONSTANTS
# Maps to: geometry.shape
# =============================================================================

CFG_SHAPE_RECT: str = "rect"          # SPL-ID-L-009 — standard rectangle
CFG_SHAPE_OVAL: str = "oval"          # SPL-ID-L-010 — ellipse / oval window
CFG_SHAPE_ROUNDED: str = "rounded"   # SPL-ID-L-011 — rectangle with rounded corners
CFG_SHAPE_PNG_MASK: str = "png_mask"  # SPL-ID-L-012 — arbitrary PNG transparency mask

# =============================================================================
# SECTION 5 — POSITION CONSTANTS
# Maps to: geometry.position
# =============================================================================

CFG_POSITION_CENTER: str = "center"   # SPL-ID-L-013

# =============================================================================
# SECTION 6 — LOGGING LEVEL CONSTANTS
# Maps to: logging.level
# =============================================================================

CFG_LOG_LEVEL_DEBUG: str = "DEBUG"       # SPL-ID-L-014
CFG_LOG_LEVEL_INFO: str = "INFO"         # SPL-ID-L-015
CFG_LOG_LEVEL_WARNING: str = "WARNING"   # SPL-ID-L-016

# =============================================================================
# SECTION 7 — SCHEMA / VERSION CONSTANTS
# =============================================================================

SCHEMA_VERSION: str = "2.2"       # SPL-ID-L-017
PROFILE_VERSION: str = "2.1.0"    # SPL-ID-L-018

# =============================================================================
# SECTION 8 — PROFILE JSON KEY NAMES
# Use these when reading or writing profile keys programmatically.
# Prevents key typos and makes rename-refactoring safe across all modules.
# =============================================================================

# --- Top-level keys ---
KEY_PROFILE_META: str = "profile_meta"
KEY_ENABLED: str = "enabled"
KEY_MEDIA: str = "media"
KEY_GEOMETRY: str = "geometry"
KEY_RUNTIME_BEHAVIOR: str = "runtime_behavior"
KEY_LOGGING: str = "logging"
KEY_DOCUMENTATION: str = "_documentation"

# --- profile_meta keys ---
KEY_META_NAME: str = "name"
KEY_META_VERSION: str = "version"
KEY_META_SCHEMA_VERSION: str = "schema_version"

# --- media keys ---
KEY_MEDIA_TYPE: str = "media_type"
KEY_MEDIA_SOURCES: str = "media_sources"   # folder paths only — see design note below
KEY_VIDEO: str = "video"
KEY_IMAGE: str = "image"

# --- media.video and media.image keys ---
# Design: media_sources holds FOLDER paths. KEY_FILENAME holds the asset
# filename only. Resolution combines each folder + filename in sequence.
# KEY_PATH retained for mask_settings only (mask_path key name).
KEY_FILENAME: str = "filename"             # media.video.filename / media.image.filename
KEY_ASPECT_RATIO_MODE: str = "aspect_ratio_mode"
KEY_LOOP_BEHAVIOR: str = "loop_behavior"
KEY_TEMPORAL: str = "temporal"
KEY_START_POS_MS: str = "start_pos_ms"
KEY_END_POS_MS: str = "end_pos_ms"
KEY_STATIC_DURATION_MS: str = "static_duration_ms"

# --- geometry keys ---
KEY_SHAPE: str = "shape"
KEY_IS_NATIVE: str = "is_native"
KEY_SCALE_PERCENT: str = "scale_percent"
KEY_POSITION: str = "position"
KEY_ROUNDED_CORNERS: str = "rounded_corners"
KEY_RADIUS_PX: str = "radius_px"
KEY_MASK_SETTINGS: str = "mask_settings"
KEY_MASK_PATH: str = "mask_path"           # Lite spec §6: 'mask_path', not 'path'
KEY_MASK_THRESHOLD: str = "mask_threshold"

# --- logging keys ---
KEY_LOG_LEVEL: str = "level"               # Lite spec §8: 'level' string, not 'debug' bool
KEY_LOG_FILE: str = "log_file"

# --- runtime_behavior keys ---
KEY_CLOSE_ON_CLICK: str = "close_on_click"
KEY_ALWAYS_ON_TOP: str = "always_on_top"
KEY_HEARTBEAT_INTERVAL_MS: str = "heartbeat_interval_ms"

# =============================================================================
# SECTION 9 — VALID VALUE SETS
# Used by qc_validator.py for allowed-value checks.
# =============================================================================

VALID_MEDIA_TYPES: frozenset = frozenset({CFG_MEDIA_TYPE_VIDEO, CFG_MEDIA_TYPE_IMAGE})
VALID_ASPECT_MODES: frozenset = frozenset({CFG_ASPECT_EXPAND, CFG_ASPECT_FIT, CFG_ASPECT_IGNORE})
VALID_LOOP_BEHAVIORS: frozenset = frozenset({CFG_LOOP_CLOSE, CFG_LOOP_FREEZE, CFG_LOOP_REPLAY})
VALID_SHAPES: frozenset = frozenset({
    CFG_SHAPE_RECT, CFG_SHAPE_OVAL, CFG_SHAPE_ROUNDED, CFG_SHAPE_PNG_MASK
})
VALID_LOG_LEVELS: frozenset = frozenset({
    CFG_LOG_LEVEL_DEBUG, CFG_LOG_LEVEL_INFO, CFG_LOG_LEVEL_WARNING
})

# =============================================================================
# SECTION 10 — REQUIRED KEY MANIFEST
# Dot-notation paths verified by qc_validator.check_required_keys().
# =============================================================================

REQUIRED_KEYS: tuple = (
    "enabled",
    "media.media_type",
    "media.media_sources",
    "media.video.filename",
    "media.image.filename",
    "geometry.shape",
    "geometry.is_native",
    "geometry.scale_percent",
    "geometry.position",
    "runtime_behavior.close_on_click",
    "runtime_behavior.always_on_top",
    "runtime_behavior.heartbeat_interval_ms",
    "logging.level",
    "logging.log_file",
)
