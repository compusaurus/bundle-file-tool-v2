"""Immutable profile models and deterministic configuration resolution."""

from __future__ import annotations

import json
import os
from collections.abc import Mapping
from dataclasses import dataclass, field
from importlib.resources import files
from pathlib import Path
from typing import Any

from .errors import MediaNotFoundError, ProfileNotFoundError, ProfileValidationError

PROFILE_ENV_VAR = "PYSPLASHX_PROFILE_PATH"
PROFILE_FILENAME = "pysplashx_profile.json"


@dataclass(frozen=True)
class TemporalConfig:
    start_pos_ms: int
    end_pos_ms: int


@dataclass(frozen=True)
class VideoConfig:
    filename: str
    aspect_ratio_mode: str
    loop_behavior: str
    temporal: TemporalConfig


@dataclass(frozen=True)
class ImageConfig:
    filename: str
    static_duration_ms: int


@dataclass(frozen=True)
class MediaConfig:
    media_type: str
    media_sources: tuple[str, ...]
    video: VideoConfig
    image: ImageConfig


@dataclass(frozen=True)
class GeometryConfig:
    shape: str
    is_native: bool
    scale_percent: int
    position: str
    radius_px: int
    mask_path: str
    mask_threshold: int


@dataclass(frozen=True)
class RuntimeConfig:
    close_on_click: bool
    always_on_top: bool
    heartbeat_interval_ms: int


@dataclass(frozen=True)
class LoggingConfig:
    level: str
    log_file: str


@dataclass(frozen=True)
class InterfacePolicy:
    """Host-facing defaults; callers can still pass an explicit override."""

    native_enabled: bool
    web_enabled: bool

    def enabled_for(self, interface: str) -> bool:
        if interface == "native":
            return self.native_enabled
        if interface == "web":
            return self.web_enabled
        return False


@dataclass(frozen=True)
class SplashProfile:
    """Validated immutable representation of a PySplashX 2.2 profile."""

    name: str
    version: str
    schema_version: str
    enabled: bool
    media: MediaConfig
    geometry: GeometryConfig
    runtime: RuntimeConfig
    logging: LoggingConfig
    interfaces: InterfacePolicy
    base_dir: Path
    source_path: Path | None = None
    _raw: Mapping[str, Any] = field(default_factory=dict, repr=False, compare=False)

    def enabled_for(self, interface: str, override: bool | None = None) -> bool:
        """Resolve master enablement and the selected host-interface policy."""

        master_enabled = self.enabled if override is None else override
        return master_enabled and self.interfaces.enabled_for(interface)

    def resolve_path(self, configured: str) -> Path:
        """Resolve a profile path without consulting the process cwd."""

        path = Path(configured)
        return path if path.is_absolute() else (self.base_dir / path).resolve()

    def resolve_media_source(self) -> Path:
        """Return the first existing active media asset in configured order."""

        filename = (
            self.media.video.filename
            if self.media.media_type == "video"
            else self.media.image.filename
        )
        tried: list[str] = []
        for folder in self.media.media_sources:
            candidate = self.resolve_path(folder) / filename
            tried.append(str(candidate))
            if candidate.is_file():
                return candidate
        raise MediaNotFoundError(f"Media file {filename!r} was not found. Tried: {tried}")

    @property
    def resolved_mask_path(self) -> Path | None:
        if not self.geometry.mask_path:
            return None
        return self.resolve_path(self.geometry.mask_path)

    @property
    def resolved_log_path(self) -> Path:
        return self.resolve_path(self.logging.log_file)

    def as_dict(self) -> dict[str, Any]:
        """Return an independent JSON-compatible copy of the source profile."""

        return json.loads(json.dumps(self._raw))


_ROOT_KEYS = {
    "_documentation",
    "profile_meta",
    "enabled",
    "interfaces",
    "media",
    "geometry",
    "runtime_behavior",
    "logging",
}


def _mapping(value: Any, path: str, issues: list[str]) -> dict[str, Any]:
    if not isinstance(value, dict):
        issues.append(f"{path} must be an object")
        return {}
    return value


def _reject_unknown(
    value: Mapping[str, Any], allowed: set[str], path: str, issues: list[str]
) -> None:
    for key in sorted(set(value) - allowed):
        issues.append(f"{path}.{key} is not allowed")


def _string(value: Any, path: str, issues: list[str], *, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value):
        issues.append(f"{path} must be a non-empty string")
        return ""
    return value


def _boolean(value: Any, path: str, issues: list[str]) -> bool:
    if not isinstance(value, bool):
        issues.append(f"{path} must be a boolean")
        return False
    return value


def _integer(value: Any, path: str, issues: list[str], minimum: int, maximum: int) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        issues.append(f"{path} must be an integer")
        return minimum
    if not minimum <= value <= maximum:
        issues.append(f"{path} must be between {minimum} and {maximum}")
    return value


def _choice(value: str, choices: set[str], path: str, issues: list[str]) -> str:
    if value not in choices:
        issues.append(f"{path} must be one of {sorted(choices)}")
    return value


def profile_from_mapping(
    data: Mapping[str, Any], *, base_dir: Path, source_path: Path | None = None
) -> SplashProfile:
    """Validate raw profile data and construct the immutable public model."""

    issues: list[str] = []
    root = _mapping(data, "$", issues)
    _reject_unknown(root, _ROOT_KEYS, "$", issues)

    meta = _mapping(root.get("profile_meta"), "profile_meta", issues)
    _reject_unknown(meta, {"name", "version", "schema_version"}, "profile_meta", issues)
    name = _string(meta.get("name"), "profile_meta.name", issues)
    version = _string(meta.get("version"), "profile_meta.version", issues)
    schema_version = _choice(
        _string(meta.get("schema_version"), "profile_meta.schema_version", issues),
        {"2.2"},
        "profile_meta.schema_version",
        issues,
    )
    enabled = _boolean(root.get("enabled"), "enabled", issues)

    interfaces = _mapping(root.get("interfaces"), "interfaces", issues)
    _reject_unknown(interfaces, {"native", "web"}, "interfaces", issues)

    def interface_enabled(interface: str) -> bool:
        section = _mapping(interfaces.get(interface, {}), f"interfaces.{interface}", issues)
        _reject_unknown(section, {"enabled"}, f"interfaces.{interface}", issues)
        return _boolean(section.get("enabled", True), f"interfaces.{interface}.enabled", issues)

    native_enabled = interface_enabled("native")
    web_enabled = interface_enabled("web")

    media = _mapping(root.get("media"), "media", issues)
    _reject_unknown(media, {"media_type", "media_sources", "video", "image"}, "media", issues)
    media_type = _choice(
        _string(media.get("media_type"), "media.media_type", issues),
        {"image", "video"},
        "media.media_type",
        issues,
    )
    source_values = media.get("media_sources")
    media_sources: tuple[str, ...]
    if not isinstance(source_values, list) or not source_values:
        issues.append("media.media_sources must be a non-empty array")
        media_sources = ()
    else:
        media_sources = tuple(
            _string(value, f"media.media_sources[{index}]", issues)
            for index, value in enumerate(source_values)
        )

    video = _mapping(media.get("video"), "media.video", issues)
    _reject_unknown(
        video, {"filename", "aspect_ratio_mode", "loop_behavior", "temporal"}, "media.video", issues
    )
    temporal = _mapping(video.get("temporal"), "media.video.temporal", issues)
    _reject_unknown(temporal, {"start_pos_ms", "end_pos_ms"}, "media.video.temporal", issues)
    start = _integer(
        temporal.get("start_pos_ms"), "media.video.temporal.start_pos_ms", issues, 0, 86_400_000
    )
    end = _integer(
        temporal.get("end_pos_ms"), "media.video.temporal.end_pos_ms", issues, 0, 86_400_000
    )
    if end != 0 and end < start:
        issues.append("media.video.temporal.end_pos_ms must be 0 or at least start_pos_ms")
    video_config = VideoConfig(
        filename=_string(video.get("filename"), "media.video.filename", issues),
        aspect_ratio_mode=_choice(
            _string(video.get("aspect_ratio_mode"), "media.video.aspect_ratio_mode", issues),
            {"expand", "fit", "ignore"},
            "media.video.aspect_ratio_mode",
            issues,
        ),
        loop_behavior=_choice(
            _string(video.get("loop_behavior"), "media.video.loop_behavior", issues),
            {"close", "freeze", "replay"},
            "media.video.loop_behavior",
            issues,
        ),
        temporal=TemporalConfig(start, end),
    )

    image = _mapping(media.get("image"), "media.image", issues)
    _reject_unknown(image, {"filename", "static_duration_ms"}, "media.image", issues)
    image_config = ImageConfig(
        filename=_string(image.get("filename"), "media.image.filename", issues),
        static_duration_ms=_integer(
            image.get("static_duration_ms"),
            "media.image.static_duration_ms",
            issues,
            100,
            86_400_000,
        ),
    )

    geometry = _mapping(root.get("geometry"), "geometry", issues)
    _reject_unknown(
        geometry,
        {"shape", "is_native", "scale_percent", "position", "rounded_corners", "mask_settings"},
        "geometry",
        issues,
    )
    rounded = _mapping(geometry.get("rounded_corners"), "geometry.rounded_corners", issues)
    _reject_unknown(rounded, {"radius_px"}, "geometry.rounded_corners", issues)
    mask = _mapping(geometry.get("mask_settings"), "geometry.mask_settings", issues)
    _reject_unknown(mask, {"mask_path", "mask_threshold"}, "geometry.mask_settings", issues)
    shape = _choice(
        _string(geometry.get("shape"), "geometry.shape", issues),
        {"oval", "png_mask", "rect", "rounded"},
        "geometry.shape",
        issues,
    )
    mask_path = _string(
        mask.get("mask_path"), "geometry.mask_settings.mask_path", issues, allow_empty=True
    )
    if shape == "png_mask" and not mask_path:
        issues.append("geometry.mask_settings.mask_path is required for png_mask")
    geometry_config = GeometryConfig(
        shape=shape,
        is_native=_boolean(geometry.get("is_native"), "geometry.is_native", issues),
        scale_percent=_integer(
            geometry.get("scale_percent"), "geometry.scale_percent", issues, 1, 100
        ),
        position=_choice(
            _string(geometry.get("position"), "geometry.position", issues),
            {"center"},
            "geometry.position",
            issues,
        ),
        radius_px=_integer(
            rounded.get("radius_px"), "geometry.rounded_corners.radius_px", issues, 0, 1000
        ),
        mask_path=mask_path,
        mask_threshold=_integer(
            mask.get("mask_threshold"), "geometry.mask_settings.mask_threshold", issues, 0, 255
        ),
    )

    runtime = _mapping(root.get("runtime_behavior"), "runtime_behavior", issues)
    _reject_unknown(
        runtime,
        {"close_on_click", "always_on_top", "heartbeat_interval_ms"},
        "runtime_behavior",
        issues,
    )
    runtime_config = RuntimeConfig(
        close_on_click=_boolean(
            runtime.get("close_on_click"), "runtime_behavior.close_on_click", issues
        ),
        always_on_top=_boolean(
            runtime.get("always_on_top"), "runtime_behavior.always_on_top", issues
        ),
        heartbeat_interval_ms=_integer(
            runtime.get("heartbeat_interval_ms"),
            "runtime_behavior.heartbeat_interval_ms",
            issues,
            50,
            60_000,
        ),
    )

    logging_section = _mapping(root.get("logging"), "logging", issues)
    _reject_unknown(logging_section, {"level", "log_file"}, "logging", issues)
    logging_config = LoggingConfig(
        level=_choice(
            _string(logging_section.get("level"), "logging.level", issues),
            {"DEBUG", "INFO", "WARNING"},
            "logging.level",
            issues,
        ),
        log_file=_string(logging_section.get("log_file"), "logging.log_file", issues),
    )

    if issues:
        raise ProfileValidationError(issues)

    return SplashProfile(
        name=name,
        version=version,
        schema_version=schema_version,
        enabled=enabled,
        media=MediaConfig(media_type, media_sources, video_config, image_config),
        geometry=geometry_config,
        runtime=runtime_config,
        logging=logging_config,
        interfaces=InterfacePolicy(native_enabled, web_enabled),
        base_dir=base_dir.resolve(),
        source_path=source_path.resolve() if source_path else None,
        _raw=json.loads(json.dumps(root)),
    )


def _load_path(path: Path) -> SplashProfile:
    if not path.is_file():
        raise ProfileNotFoundError(f"Profile not found: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ProfileValidationError([f"invalid JSON at line {exc.lineno}: {exc.msg}"]) from exc
    return profile_from_mapping(data, base_dir=path.parent, source_path=path)


def load_profile(profile_path: str | Path | None = None) -> SplashProfile:
    """Load explicit, environment, local, or packaged configuration in order."""

    if profile_path is not None:
        return _load_path(Path(profile_path))

    environment_path = os.environ.get(PROFILE_ENV_VAR)
    if environment_path:
        return _load_path(Path(environment_path))

    local_path = Path.cwd() / PROFILE_FILENAME
    if local_path.is_file():
        return _load_path(local_path)

    resource = files("pysplashx").joinpath("profiles", "default.json")
    try:
        data = json.loads(resource.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:  # pragma: no cover - package corruption
        raise ProfileValidationError([f"packaged default is invalid JSON: {exc.msg}"]) from exc
    resource_path = Path(str(resource))
    return profile_from_mapping(
        data,
        base_dir=resource_path.parent,
        source_path=resource_path if resource_path.is_file() else None,
    )
