"""Single source of package and delivery-build identity."""

VERSION = "0.1.0"
BUILD = 13
__version__ = VERSION
