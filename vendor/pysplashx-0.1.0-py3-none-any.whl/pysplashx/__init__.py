"""PySplashX public package surface.

The Qt runtime is loaded lazily so importing :mod:`pysplashx` has no GUI,
logging, filesystem, timer, or multimedia side effects.
"""

from __future__ import annotations

from importlib import import_module
from importlib.resources import files
from importlib.resources.abc import Traversable
from typing import Any

from ._version import BUILD, VERSION, __version__

__all__ = [
    "BUILD",
    "VERSION",
    "LifecycleError",
    "MediaNotFoundError",
    "PlaybackError",
    "ProfileNotFoundError",
    "ProfileValidationError",
    "PySplashXError",
    "Splash",
    "SplashDisabledError",
    "SplashOrchestrator",
    "SplashProfile",
    "SplashResult",
    "SplashStatus",
    "WebSplashDescriptor",
    "__version__",
    "default_profile_resource",
    "load_profile",
    "profile_schema_resource",
    "web_component_resource",
    "web_splash_descriptor",
]


def default_profile_resource() -> Traversable:
    """Return the packaged canonical profile template."""

    return files(__package__).joinpath("profiles", "default.json")


def profile_schema_resource() -> Traversable:
    """Return the packaged JSON Schema 2.2 resource."""

    return files(__package__).joinpath("schemas", "pysplashx-profile-2.2.schema.json")


def web_component_resource() -> Traversable:
    """Return the packaged framework-neutral web component module."""

    return files(__package__).joinpath("web_assets", "pysplashx-splash.mjs")


def __getattr__(name: str) -> Any:
    """Load Qt-backed public objects only when callers request them."""

    exports = {
        "Splash": (".api", "Splash"),
        "SplashResult": (".api", "SplashResult"),
        "SplashStatus": (".api", "SplashStatus"),
        "SplashOrchestrator": (".core.orchestrator", "SplashOrchestrator"),
        "SplashProfile": (".profile", "SplashProfile"),
        "load_profile": (".profile", "load_profile"),
        "WebSplashDescriptor": (".web", "WebSplashDescriptor"),
        "web_splash_descriptor": (".web", "web_splash_descriptor"),
        "PySplashXError": (".errors", "PySplashXError"),
        "ProfileNotFoundError": (".errors", "ProfileNotFoundError"),
        "ProfileValidationError": (".errors", "ProfileValidationError"),
        "SplashDisabledError": (".errors", "SplashDisabledError"),
        "MediaNotFoundError": (".errors", "MediaNotFoundError"),
        "LifecycleError": (".errors", "LifecycleError"),
        "PlaybackError": (".errors", "PlaybackError"),
    }
    if name in exports:
        module_name, attribute = exports[name]
        value = getattr(import_module(module_name, __package__), attribute)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
