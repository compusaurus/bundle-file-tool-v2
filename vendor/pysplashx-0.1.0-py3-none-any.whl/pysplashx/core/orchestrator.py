"""Qt lifecycle controller adapted from the SplashKit V2 baseline."""

from __future__ import annotations

import logging
import os
import signal
from importlib.resources import files
from pathlib import Path
from types import FrameType
from typing import Any, cast

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from ..errors import LifecycleError, SplashDisabledError
from ..profile import (
    PROFILE_ENV_VAR,
    PROFILE_FILENAME,
    SplashProfile,
)
from ..profile import (
    load_profile as load_profile_model,
)
from ..splash_ids import CFG_MEDIA_TYPE_IMAGE, CFG_MEDIA_TYPE_VIDEO
from ..ui.video_engine import VideoEngine
from ..ui.window import SplashWindow

_log = logging.getLogger(__name__)


class SplashOrchestrator:
    """Own one splash instance without assuming ownership of the host process."""

    def __init__(
        self,
        profile_path: str | Path | None = None,
        *,
        profile: SplashProfile | None = None,
        enabled: bool | None = None,
    ) -> None:
        if profile_path is not None and profile is not None:
            raise ValueError("Pass profile_path or profile, not both")
        self._profile_path = Path(profile_path) if profile_path is not None else None
        self._profile_model = profile
        self._enabled_override = enabled
        self._app: QApplication | None = None
        self._owns_app = False
        self._window: SplashWindow | None = None
        self._video_engine: VideoEngine | None = None
        self._heartbeat_timer: QTimer | None = None
        self._previous_sigint_handler: Any = None
        self._log_handler: logging.Handler | None = None
        self._previous_log_level: int | None = None
        self._active = False

    def load_profile(self) -> SplashProfile:
        """Load and validate configuration without creating Qt objects or files."""

        if self._profile_model is None:
            self._profile_model = load_profile_model(self._profile_path)
        return self._profile_model

    def resolve_media_source(self) -> Path:
        """Resolve ordered media folders relative to the profile directory."""

        return self.load_profile().resolve_media_source()

    def apply_geometry(self) -> dict[str, Any]:
        """Return the normalized dictionary consumed by the V2 Qt window."""

        profile = self.load_profile()
        mask_path = profile.resolved_mask_path
        return {
            "shape": profile.geometry.shape,
            "is_native": profile.geometry.is_native,
            "scale_percent": profile.geometry.scale_percent,
            "position": profile.geometry.position,
            "radius_px": profile.geometry.radius_px,
            "mask_path": str(mask_path) if mask_path is not None else None,
            "mask_threshold": profile.geometry.mask_threshold,
        }

    def start(self) -> None:
        """Start non-blocking playback inside an existing host QApplication."""

        profile = self._enabled_profile()
        app_instance = QApplication.instance()
        if app_instance is None:
            raise LifecycleError(
                "start() requires an existing QApplication; use run() for standalone mode"
            )
        self._app = cast(QApplication, app_instance)
        self._owns_app = False
        try:
            self._start_ui(profile)
        except Exception:
            self.shutdown()
            raise

    def run(self) -> None:
        """Run standalone and block until the PySplashX-owned app exits."""

        profile = self._enabled_profile()
        if QApplication.instance() is not None:
            raise LifecycleError(
                "run() cannot own an existing QApplication; use start() in a host app"
            )

        self._app = QApplication([])
        self._owns_app = True
        self._install_standalone_signal_support(profile.runtime.heartbeat_interval_ms)
        try:
            self._start_ui(profile)
            self._app.exec()
        finally:
            self._restore_signal_support()
            self.shutdown()

    def close(self) -> None:
        """Close this splash and quit Qt only when this instance owns it."""

        if self._owns_app and self._app is not None:
            self._app.quit()
        self.shutdown()

    def shutdown(self) -> None:
        """Release only timers, media, and windows owned by this instance."""

        if self._heartbeat_timer is not None:
            self._heartbeat_timer.stop()
            self._heartbeat_timer = None
        if self._video_engine is not None:
            self._video_engine.stop()
            self._video_engine = None
        if self._window is not None:
            self._window.close()
            self._window = None
        if self._log_handler is not None:
            package_logger = logging.getLogger("pysplashx")
            package_logger.removeHandler(self._log_handler)
            self._log_handler.close()
            self._log_handler = None
            if self._previous_log_level is not None:
                package_logger.setLevel(self._previous_log_level)
                self._previous_log_level = None
        self._active = False
        self._app = None
        self._owns_app = False

    def _enabled_profile(self) -> SplashProfile:
        profile = self.load_profile()
        if not profile.enabled_for("native", self._enabled_override):
            raise SplashDisabledError("Splash disabled by native host policy")
        return profile

    def _start_ui(self, profile: SplashProfile) -> None:
        if self._active:
            raise LifecycleError("This splash instance is already active")

        media_path = profile.resolve_media_source()
        self._configure_logging(profile)
        geometry = self.apply_geometry()
        runtime_cfg = {
            "close_on_click": profile.runtime.close_on_click,
            "always_on_top": profile.runtime.always_on_top,
            "heartbeat_interval_ms": profile.runtime.heartbeat_interval_ms,
        }
        self._window = SplashWindow(
            geometry=geometry,
            runtime_cfg=runtime_cfg,
            on_close_requested=self._request_close,
        )

        if profile.media.media_type == CFG_MEDIA_TYPE_VIDEO:
            video = profile.media.video
            self._video_engine = VideoEngine(
                source=media_path,
                start_pos_ms=video.temporal.start_pos_ms,
                end_pos_ms=video.temporal.end_pos_ms,
                loop_behavior=video.loop_behavior,
                aspect_ratio_mode=video.aspect_ratio_mode,
                scale_percent=profile.geometry.scale_percent,
                window=self._window,
                on_close_requested=self._request_close,
            )
            self._video_engine.load()
        elif profile.media.media_type == CFG_MEDIA_TYPE_IMAGE:
            self._window.show_image(
                source=media_path,
                duration_ms=profile.media.image.static_duration_ms,
            )

        self._window.show()
        if self._video_engine is not None:
            self._video_engine.play()
        self._active = True
        mode = "standalone" if self._owns_app else "host"
        _log.info("PySplashX started in %s mode", mode)

    def _request_close(self) -> None:
        if self._owns_app and self._app is not None:
            self._app.quit()
            return
        self.shutdown()

    def _install_standalone_signal_support(self, interval_ms: int) -> None:
        self._heartbeat_timer = QTimer()
        self._heartbeat_timer.setInterval(interval_ms)
        self._heartbeat_timer.timeout.connect(lambda: None)
        self._heartbeat_timer.start()
        self._previous_sigint_handler = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, self._on_sigint)

    def _restore_signal_support(self) -> None:
        if self._previous_sigint_handler is not None:
            signal.signal(signal.SIGINT, self._previous_sigint_handler)
            self._previous_sigint_handler = None

    def _on_sigint(self, _signum: int, _frame: FrameType | None) -> None:
        self._request_close()

    def _configure_logging(self, profile: SplashProfile) -> None:
        """Attach one package-owned file handler after profile resolution."""

        package_logger = logging.getLogger("pysplashx")
        self._previous_log_level = package_logger.level
        package_logger.setLevel(getattr(logging, profile.logging.level, logging.INFO))
        log_path = profile.resolved_log_path
        log_path.parent.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(log_path, encoding="utf-8")
        handler.setFormatter(
            logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
        )
        package_logger.addHandler(handler)
        self._log_handler = handler

    @staticmethod
    def _resolve_profile_path(explicit: str | Path | None) -> Path:
        """Expose the documented path precedence for compatibility and tests."""

        if explicit is not None:
            return Path(explicit)
        environment_path = os.environ.get(PROFILE_ENV_VAR)
        if environment_path:
            return Path(environment_path)
        local_path = Path.cwd() / PROFILE_FILENAME
        if local_path.is_file():
            return local_path
        return Path(str(files("pysplashx").joinpath("profiles", "default.json")))
