"""Framework-neutral policy contract for web splash renderers."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .profile import SplashProfile


@dataclass(frozen=True)
class WebSplashDescriptor:
    """Data a host web renderer needs; this module emits no HTML or JavaScript."""

    enabled: bool
    media_type: str
    media_url: str
    autoplay: bool = True
    muted: bool = True
    plays_inline: bool = True
    skippable: bool = True
    respect_reduced_motion: bool = True
    once_per_session: bool = True
    max_duration_ms: int = 15_000
    custom_element: str = "pysplashx-splash"
    scale_percent: int = 45
    position: str = "center"
    shape: str = "rect"
    radius_px: int = 0
    aspect_ratio_mode: str = "fit"

    def as_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable copy for a host framework."""

        return asdict(self)


def web_splash_descriptor(
    profile: SplashProfile,
    media_url: str,
    *,
    enabled: bool | None = None,
) -> WebSplashDescriptor:
    """Build the safe default contract consumed by an application web UI."""

    if not media_url:
        raise ValueError("media_url must be non-empty")
    return WebSplashDescriptor(
        enabled=profile.enabled_for("web", enabled),
        media_type=profile.media.media_type,
        media_url=media_url,
        scale_percent=profile.geometry.scale_percent,
        position=profile.geometry.position,
        shape=profile.geometry.shape,
        radius_px=profile.geometry.radius_px,
        aspect_ratio_mode=profile.media.video.aspect_ratio_mode,
    )
