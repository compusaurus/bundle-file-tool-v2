const template = document.createElement("template");

template.innerHTML = `
  <style>
    :host {
      position: fixed;
      inset: 0;
      z-index: 2147483647;
      display: grid;
      place-items: center;
      background: var(--pysplashx-backdrop, transparent);
      color: #ffffff;
      pointer-events: none;
    }

    :host([hidden]) {
      display: none;
    }

    .media-frame {
      position: relative;
      display: grid;
      place-items: center;
      overflow: hidden;
      max-width: 100vw;
      max-height: 100vh;
      background: #05070b;
      box-shadow: 0 1.5rem 5rem rgba(0, 0, 0, 0.45);
      pointer-events: auto;
    }

    video {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: contain;
      background: #05070b;
    }

    button {
      position: absolute;
      right: max(1rem, env(safe-area-inset-right));
      bottom: max(1rem, env(safe-area-inset-bottom));
      min-width: 5rem;
      padding: 0.65rem 1rem;
      border: 1px solid rgba(255, 255, 255, 0.65);
      border-radius: 999px;
      background: rgba(0, 0, 0, 0.72);
      color: inherit;
      font: 600 0.95rem/1 system-ui, sans-serif;
      cursor: pointer;
    }

    button:focus-visible {
      outline: 3px solid #ffffff;
      outline-offset: 3px;
    }

    @media (prefers-reduced-motion: reduce) {
      video {
        display: none;
      }
    }
  </style>
  <div class="media-frame">
    <video aria-hidden="true" preload="auto"></video>
    <button type="button" aria-label="Skip startup video">Skip</button>
  </div>
`;

class PySplashXSplash extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.append(template.content.cloneNode(true));
    this.mediaFrame = this.shadowRoot.querySelector(".media-frame");
    this.video = this.shadowRoot.querySelector("video");
    this.skipButton = this.shadowRoot.querySelector("button");
    this.timeoutId = null;
    this.finished = false;
    this.onEnded = () => this.finish("ended");
    this.onError = () => this.finish("media-error");
    this.onSkip = () => this.finish("skipped");
    this.onLoadedMetadata = () => this.applyMediaGeometry();
    this.onResize = () => this.applyMediaGeometry();
    this.onKeyDown = (event) => {
      if (event.key === "Escape") {
        this.finish("skipped");
      }
    };
  }

  connectedCallback() {
    if (this.getAttribute("enabled")?.toLowerCase() === "false") {
      this.finish("disabled");
      return;
    }
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      this.finish("reduced-motion");
      return;
    }
    if (this.oncePerSession && this.wasShownThisSession()) {
      this.finish("already-shown");
      return;
    }

    const source = this.getAttribute("src");
    if (!source) {
      this.finish("missing-source");
      return;
    }

    this.applyShape();
    this.applyMediaGeometry();
    this.video.autoplay = true;
    this.video.muted = true;
    this.video.defaultMuted = true;
    this.video.playsInline = true;
    this.video.poster = this.getAttribute("poster") || "";
    this.video.src = source;
    this.video.addEventListener("ended", this.onEnded, { once: true });
    this.video.addEventListener("error", this.onError, { once: true });
    this.video.addEventListener("loadedmetadata", this.onLoadedMetadata);
    this.skipButton.addEventListener("click", this.onSkip);
    document.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("resize", this.onResize);
    this.markShownThisSession();

    const duration = Number.parseInt(this.getAttribute("max-duration-ms") || "15000", 10);
    const boundedDuration = Number.isFinite(duration) && duration > 0 ? duration : 15000;
    this.timeoutId = window.setTimeout(() => this.finish("timeout"), boundedDuration);

    try {
      const playback = this.video.play();
      if (playback && typeof playback.catch === "function") {
        playback.catch(() => this.finish("autoplay-blocked"));
      }
    } catch (_error) {
      this.finish("autoplay-blocked");
    }
  }

  disconnectedCallback() {
    this.cleanup();
  }

  get oncePerSession() {
    return this.getAttribute("once-per-session")?.toLowerCase() !== "false";
  }

  get sessionKey() {
    return this.getAttribute("session-key") || "pysplashx:shown";
  }

  wasShownThisSession() {
    try {
      return window.sessionStorage.getItem(this.sessionKey) === "1";
    } catch (_error) {
      return false;
    }
  }

  markShownThisSession() {
    if (!this.oncePerSession) {
      return;
    }
    try {
      window.sessionStorage.setItem(this.sessionKey, "1");
    } catch (_error) {
      // Storage can be unavailable in privacy-restricted contexts.
    }
  }

  boundedInteger(name, fallback, minimum, maximum) {
    const parsed = Number.parseInt(this.getAttribute(name) || "", 10);
    if (!Number.isFinite(parsed)) {
      return fallback;
    }
    return Math.min(maximum, Math.max(minimum, parsed));
  }

  applyShape() {
    const shape = (this.getAttribute("shape") || "rect").toLowerCase();
    const radius = this.boundedInteger("radius-px", 0, 0, 1000);
    if (shape === "oval") {
      this.mediaFrame.style.borderRadius = "50%";
    } else if (shape === "rounded") {
      this.mediaFrame.style.borderRadius = `${radius}px`;
    } else {
      // A native filesystem PNG mask has no portable browser URL. Both rect
      // and unsupported png_mask values therefore fail safely to a rectangle.
      this.mediaFrame.style.borderRadius = "0";
    }
  }

  applyMediaGeometry() {
    const scalePercent = this.boundedInteger("scale-percent", 45, 1, 100);
    const maximumWidth = Math.max(1, window.innerWidth * scalePercent / 100);
    const maximumHeight = Math.max(1, window.innerHeight * scalePercent / 100);
    const nativeWidth = this.video.videoWidth || 16;
    const nativeHeight = this.video.videoHeight || 9;
    const fitScale = Math.min(maximumWidth / nativeWidth, maximumHeight / nativeHeight);
    this.mediaFrame.style.width = `${Math.max(1, Math.floor(nativeWidth * fitScale))}px`;
    this.mediaFrame.style.height = `${Math.max(1, Math.floor(nativeHeight * fitScale))}px`;

    const aspectMode = (this.getAttribute("aspect-ratio-mode") || "fit").toLowerCase();
    this.video.style.objectFit = aspectMode === "expand"
      ? "cover"
      : aspectMode === "ignore" ? "fill" : "contain";
  }

  skip() {
    this.finish("skipped");
  }

  finish(reason) {
    if (this.finished) {
      return;
    }
    this.finished = true;
    this.cleanup();
    this.hidden = true;
    this.dispatchEvent(
      new CustomEvent("pysplashx-complete", {
        bubbles: true,
        composed: true,
        detail: { reason },
      }),
    );
  }

  cleanup() {
    if (this.timeoutId !== null) {
      window.clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }
    this.video.pause();
    this.video.removeEventListener("ended", this.onEnded);
    this.video.removeEventListener("error", this.onError);
    this.video.removeEventListener("loadedmetadata", this.onLoadedMetadata);
    this.skipButton.removeEventListener("click", this.onSkip);
    document.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("resize", this.onResize);
  }
}

if (!customElements.get("pysplashx-splash")) {
  customElements.define("pysplashx-splash", PySplashXSplash);
}
