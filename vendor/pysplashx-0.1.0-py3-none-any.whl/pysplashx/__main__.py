"""Module CLI for PySplashX."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from ._version import BUILD, VERSION


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pysplashx",
        description="Validate or run a PySplashX 2.2 splash profile.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"pysplashx {VERSION} (build {BUILD})",
    )
    commands = parser.add_subparsers(dest="command")
    validate = commands.add_parser("validate", help="validate a profile")
    validate.add_argument("profile", type=Path)
    run = commands.add_parser("run", help="run a splash profile")
    run.add_argument("profile", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    """Run the module CLI and return a process exit code."""

    parser = _parser()
    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        return 0

    if args.command == "validate":
        from .errors import PySplashXError
        from .profile import load_profile
        from .validation import QCValidator, _print_report

        try:
            load_profile(args.profile)
            report = QCValidator(args.profile).report()
        except (PySplashXError, json.JSONDecodeError) as exc:
            print(f"pysplashx: {exc}", file=sys.stderr)
            return 2
        _print_report(report)
        return 0 if report.passed else 1

    from .api import Splash
    from .errors import PySplashXError

    try:
        Splash.from_profile(args.profile).run()
    except (PySplashXError, json.JSONDecodeError) as exc:
        print(f"pysplashx: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
